# Definition of Done — ProjectPort

Test suite: **90 tests, 705 assertions, all passing** (`php artisan test`).

## FR coverage report

| FR id | implemented (y/n) | tests passing (y/n) | files |
|---|---|---|---|
| FR-01 User Registration | y | y | `app/Http/Controllers/Api/AuthController.php` (`register_user`), `app/Http/Requests/RegisterUserRequest.php`, `app/Services/EmailVerificationService.php` (`verify_email`), `app/Mail/VerifyEmailMail.php`, `resources/views/emails/verify_email.blade.php`, `tests/Feature/RegisterUserTest.php` |
| FR-02 Email Verification | y | y | `app/Http/Controllers/Api/AuthController.php` (`verify_email_address`, `resend_verification_email`), `app/Services/EmailVerificationService.php`, `database/migrations/0001_01_01_000000_create_users_table.php`, `tests/Feature/VerifyEmailTest.php` |
| FR-03 Login | y | y | `app/Http/Controllers/Api/AuthController.php` (`login_user`), `app/Http/Requests/LoginUserRequest.php`, `app/Services/JwtService.php`, `app/Services/RefreshTokenService.php`, `tests/Feature/LoginUserTest.php` |
| FR-04 Admin Approval | y | y | `app/Http/Controllers/Api/AdminRegistrationController.php` (`index`, `approve_registration`, `reject_registration`), `app/Http/Resources/RegistrationResource.php`, `app/Models/Registration.php`, `app/Http/Middleware/EnsureRole.php`, `database/seeders/DatabaseSeeder.php`, `tests/Feature/AdminApprovalTest.php` |
| FR-05 Student Profile | y | y | `app/Http/Controllers/Api/ProjectController.php` (`create_project`), `app/Services/SourceCodeStorageService.php` (`upload_source_code`), `app/Http/Requests/CreateProjectRequest.php`, `app/Http/Controllers/Api/StudentProfileController.php`, `app/Models/Project.php`, `tests/Feature/StudentProjectTest.php` |
| FR-06 Recruiter Search | y | y | `app/Http/Controllers/Api/SearchController.php` (`search_students`, `search_projects`), `app/Http/Requests/SearchRequest.php`, `app/Http/Controllers/Api/ProjectSourceCodeController.php`, `tests/Feature/RecruiterSearchTest.php`, `tests/Feature/ProjectSourceCodeTest.php` |

## Checklist

- [x] **Every functional requirement is implemented and each acceptance criterion passes as an automated test.** Each FR's "given/when/then" pairs map to named tests in the files above, including both the success and the error path.
- [x] **Every identifier in the Testable Signal Index exists verbatim in the codebase.** Enforced by `tests/Feature/TestableSignalIndexTest.php`, which word-boundary greps `app/`, `routes/` and `database/` for all ten signals.
- [x] **Every item in the Implementation Checklist is done.**
  - Refresh token rotation — `app/Services/RefreshTokenService.php`, asserted by `LoginUserTest::test_refresh_tokens_rotate_and_the_old_token_stops_working`.
  - CSRF token — not applicable and deliberately skipped: the JWT travels in the `Authorization` header (see Assumption 16).
  - Session invalidation on password or email change — `app/Http/Controllers/Api/CredentialsController.php` bumps `users.token_version` and revokes refresh tokens; asserted by `AuthorizationTest::test_a_password_change_invalidates_previously_issued_tokens`.
  - Multi-device logout — implemented without Redis (`cache_layer: none` is locked) via `token_version` + revoking every live refresh token. See Assumption 15.
- [x] **Every non-functional requirement threshold is met and asserted by a test where measurable.**
  - NFR-01 (< 2000 ms): `PerformanceTest::test_recruiter_search_responds_within_the_two_second_budget`, indexes asserted, `X-Response-Time-Ms` header + over-budget warning log.
  - NFR-02 (HTTPS + rate limits): `SecurityHeadersTest` (HSTS `max-age=31536000; includeSubDomains`), `RateLimitTest` (10/min auth, 100/min read, 429 in contract shape).
  - NFR-03: monitoring implemented (`RequestTiming`); load testing deferred — no deployment environment (Assumption 22).
  - NFR-04 (< 100 ms queries): composite indexes asserted in `PerformanceTest::test_indexes_exist_on_the_columns_the_hot_queries_filter_on`, slow-query alerting via `DB::whenQueryingForLongerThan`, pool bounds asserted.
- [x] **All error responses use the Error Response Contract.** Single renderer in `bootstrap/app.php`, single shape builder in `app/Support/ApiError.php`; `tests/TestCase::assertErrorContract` rejects any response carrying keys outside `error`/`message`/`field`, and is used by every error-path test (400, 401, 403, 404, 409, 422, 429, 500).
- [x] **No code exists that is not traceable to a functional requirement.** Every source file carries the FR, NFR, Data Model or Implementation Checklist item it serves; the unused Laravel scaffolding (cache/jobs/session/password-reset tables, example tests) was removed. `Project has_many purchases` was deliberately not built (Assumption 10).
- [x] **The Assumptions Log is filled in and delivered with the code** — `ASSUMPTIONS.md` (25 entries).

## Phase self-verification

| Phase | Checks |
|---|---|
| 1 Foundation | App boots (`php artisan route:list`), migrations run clean (`RefreshDatabase` on every test; `ErrorContractTest::test_migrations_created_every_table_in_the_data_model`), forced error returns the contract (`ErrorContractTest::test_unexpected_server_errors_use_the_contract_and_hide_stack_traces`). |
| 2 Auth | 401 for unauthenticated/expired/invalid tokens, 403 for wrong role and non-active accounts — `AuthorizationTest`. |
| 3 FR-01…FR-04 | `RegisterUserTest`, `VerifyEmailTest`, `LoginUserTest`, `AdminApprovalTest` (incl. the Student Registration journey end to end). |
| 4 FR-05, FR-06 | `StudentProjectTest`, `RecruiterSearchTest` (incl. the Recruiter Search journey end to end). |
| 5 Hardening | `SecurityHeadersTest`, `RateLimitTest`, `PerformanceTest`, `TestableSignalIndexTest`. |
