<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * FR-06: recruiters search for students and their projects by skills and keywords.
 */
class RecruiterSearchTest extends TestCase
{
    use RefreshDatabase;

    /** Given a valid search query … then a list of relevant students is displayed. */
    public function test_students_can_be_found_by_skill(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $match = User::factory()->student()->create([
            'name' => 'Ada Lovelace',
            'skills' => 'php, laravel, mysql',
        ]);
        User::factory()->student()->create(['name' => 'Bob Smith', 'skills' => 'cobol']);

        $response = $this->getJson('/api/search/students?q=laravel', $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertJsonPath('total', 1);
        $response->assertJsonPath('students.0.id', $match->id);
    }

    public function test_students_can_be_found_by_name_keyword(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $match = User::factory()->student()->create(['name' => 'Grace Hopper', 'skills' => 'cobol']);

        $response = $this->getJson('/api/search/students?q=Hopper', $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertJsonPath('students.0.id', $match->id);
    }

    /** Given a valid search query … then a list of relevant projects is displayed. */
    public function test_projects_can_be_found_by_keyword(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $student = User::factory()->student()->create(['skills' => 'php, laravel']);

        $match = Project::factory()->create(['user_id' => $student->id, 'name' => 'Ledger Explorer']);
        Project::factory()->create(['user_id' => $student->id, 'name' => 'Weather Widget']);

        $response = $this->getJson('/api/search/projects?q=Ledger', $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertJsonPath('total', 1);
        $response->assertJsonPath('projects.0.id', $match->id);
    }

    public function test_projects_can_be_found_by_the_owning_students_skills(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $student = User::factory()->student()->create(['skills' => 'rust, webassembly']);
        Project::factory()->create(['user_id' => $student->id, 'name' => 'Compiler Toy']);

        $response = $this->getJson('/api/search/projects?q=webassembly', $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertJsonPath('total', 1);
    }

    /** Given an invalid search query … then an error message is displayed. */
    public function test_a_missing_search_query_is_rejected(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $response = $this->getJson('/api/search/students', $this->authHeader($recruiter));

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'q');
    }

    public function test_a_too_short_search_query_is_rejected(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $this->assertErrorContract(
            $this->getJson('/api/search/projects?q=a', $this->authHeader($recruiter)),
            400,
            'VALIDATION_FAILED',
            'q',
        );
    }

    public function test_inactive_students_are_excluded_from_results(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $rejected = User::factory()->student()->inactive()->create(['skills' => 'laravel']);
        Project::factory()->create(['user_id' => $rejected->id, 'name' => 'Hidden Project']);

        $this->getJson('/api/search/students?q=laravel', $this->authHeader($recruiter))
            ->assertOk()
            ->assertJsonPath('total', 0);

        $this->getJson('/api/search/projects?q=Hidden', $this->authHeader($recruiter))
            ->assertOk()
            ->assertJsonPath('total', 0);
    }

    public function test_students_cannot_use_recruiter_search(): void
    {
        $student = User::factory()->student()->create();

        $this->assertErrorContract(
            $this->getJson('/api/search/students?q=laravel', $this->authHeader($student)),
            403,
            'FORBIDDEN',
        );
    }

    /** Recruiter Search journey: FR-06 search, then FR-05 open the student profile. */
    public function test_the_recruiter_search_journey_end_to_end(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $student = User::factory()->student()->create(['name' => 'Ada Lovelace', 'skills' => 'php, laravel']);
        Project::factory()->create(['user_id' => $student->id, 'name' => 'Ledger Explorer']);

        $search = $this->getJson('/api/search/students?q=laravel', $this->authHeader($recruiter));
        $search->assertOk();

        $foundId = $search->json('students.0.id');

        $profile = $this->getJson("/api/students/{$foundId}", $this->authHeader($recruiter));
        $profile->assertOk();
        $profile->assertJsonPath('student.name', 'Ada Lovelace');
        $profile->assertJsonPath('student.projects.0.name', 'Ledger Explorer');
    }
}
