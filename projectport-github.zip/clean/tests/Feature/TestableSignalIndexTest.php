<?php

namespace Tests\Feature;

use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

/**
 * Definition of Done: every identifier in the Testable Signal Index must appear
 * as a word-boundary match in the source code.
 */
class TestableSignalIndexTest extends TestCase
{
    /**
     * @return array<int, array{0: string}>
     */
    public static function signalProvider(): array
    {
        return array_map(fn (string $signal) => [$signal], [
            'register_user',
            'verify_email',
            'verify_email_address',
            'login_user',
            'approve_registration',
            'reject_registration',
            'create_project',
            'upload_source_code',
            'search_students',
            'search_projects',
        ]);
    }

    #[DataProvider('signalProvider')]
    public function test_signal_appears_verbatim_in_the_source(string $signal): void
    {
        $found = false;

        foreach ($this->sourceFiles() as $file) {
            if (preg_match('/\b'.preg_quote($signal, '/').'\b/', (string) file_get_contents($file)) === 1) {
                $found = true;
                break;
            }
        }

        $this->assertTrue($found, "Testable signal '{$signal}' does not appear in the source code.");
    }

    /**
     * @return array<int, string>
     */
    private function sourceFiles(): array
    {
        $files = [];

        foreach ([base_path('app'), base_path('routes'), base_path('database')] as $directory) {
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($directory));

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $files[] = $file->getPathname();
                }
            }
        }

        return $files;
    }
}
