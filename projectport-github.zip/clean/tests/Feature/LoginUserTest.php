<?php

namespace Tests\Feature;

use App\Models\RefreshToken;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * FR-03: users can log in with a valid email address and password.
 */
class LoginUserTest extends TestCase
{
    use RefreshDatabase;

    /** Given a valid email address and password … then the user is logged in. */
    public function test_valid_credentials_log_the_user_in(): void
    {
        $user = User::factory()->student()->create([
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $response = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $response->assertOk();
        $response->assertJsonPath('user.id', $user->id);
        $response->assertJsonStructure(['access_token', 'token_type', 'expires_in', 'refresh_token']);

        // The issued access token authenticates a protected route.
        $this->getJson('/api/students/me/profile', [
            'Authorization' => 'Bearer '.$response->json('access_token'),
        ])->assertOk();
    }

    /** Given an invalid email address or password … then an error message is displayed. */
    public function test_an_incorrect_password_is_rejected(): void
    {
        User::factory()->create(['email' => 'ada@example.com', 'password' => 'password123']);

        $response = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'wrong-password',
        ]);

        $this->assertErrorContract($response, 401, 'INVALID_CREDENTIALS');
    }

    public function test_an_unknown_email_address_is_rejected(): void
    {
        $response = $this->postJson('/api/auth/login', [
            'email' => 'nobody@example.com',
            'password' => 'password123',
        ]);

        $this->assertErrorContract($response, 401, 'INVALID_CREDENTIALS');
    }

    /** FR-03 validation rules: email format and password minimum length. */
    public function test_a_malformed_email_address_is_rejected(): void
    {
        $response = $this->postJson('/api/auth/login', [
            'email' => 'not-an-email',
            'password' => 'password123',
        ]);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'email');
    }

    public function test_a_password_shorter_than_eight_characters_is_rejected(): void
    {
        $response = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'short',
        ]);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'password');
    }

    /** FR-02: an unvetted account must confirm its address before logging in. */
    public function test_an_unverified_and_unapproved_account_cannot_log_in(): void
    {
        User::factory()->unverified()->pending()->create([
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $response = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $this->assertErrorContract($response, 422, 'EMAIL_NOT_VERIFIED');
    }

    /**
     * FR-04: an admin-approved account is never asked to confirm its email again,
     * including accounts that were approved before verification was settled.
     */
    public function test_an_approved_account_logs_in_without_confirming_its_email(): void
    {
        User::factory()->unverified()->student()->create([
            'email' => 'liam@example.com',
            'password' => 'password123',
            'status' => User::STATUS_ACTIVE,
        ]);

        $response = $this->postJson('/api/auth/login', [
            'email' => 'liam@example.com',
            'password' => 'password123',
        ]);

        $response->assertOk();
        $response->assertJsonPath('user.email', 'liam@example.com');
        $response->assertJsonStructure(['access_token', 'refresh_token']);
    }

    /** A rejected account stays locked out: rejection is not a way around verification. */
    public function test_a_rejected_unverified_account_cannot_log_in(): void
    {
        User::factory()->unverified()->inactive()->create([
            'email' => 'spam@example.com',
            'password' => 'password123',
        ]);

        $this->assertErrorContract(
            $this->postJson('/api/auth/login', [
                'email' => 'spam@example.com',
                'password' => 'password123',
            ]),
            422,
            'EMAIL_NOT_VERIFIED',
        );
    }

    /** Implementation Checklist: refresh token rotation. */
    public function test_refresh_tokens_rotate_and_the_old_token_stops_working(): void
    {
        User::factory()->student()->create([
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $login = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);

        $original = $login->json('refresh_token');

        $refreshed = $this->postJson('/api/auth/refresh', ['refresh_token' => $original]);
        $refreshed->assertOk();

        $rotated = $refreshed->json('refresh_token');
        $this->assertNotSame($original, $rotated);

        // The consumed token is revoked and can no longer be used.
        $this->assertErrorContract(
            $this->postJson('/api/auth/refresh', ['refresh_token' => $original]),
            401,
            'UNAUTHENTICATED',
        );

        $this->postJson('/api/auth/refresh', ['refresh_token' => $rotated])->assertOk();
        $this->assertSame(3, RefreshToken::count());
    }
}
