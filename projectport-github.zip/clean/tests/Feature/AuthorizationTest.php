<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Phase 2: jwt_stateless authentication and role authorization.
 */
class AuthorizationTest extends TestCase
{
    use RefreshDatabase;

    public function test_unauthenticated_requests_to_protected_routes_return_401(): void
    {
        $this->assertErrorContract($this->getJson('/api/students/me/profile'), 401, 'UNAUTHENTICATED');
        $this->assertErrorContract($this->getJson('/api/search/students?q=php'), 401, 'UNAUTHENTICATED');
    }

    public function test_a_malformed_token_returns_401(): void
    {
        $response = $this->getJson('/api/students/me/profile', ['Authorization' => 'Bearer not-a-jwt']);

        $this->assertErrorContract($response, 401, 'UNAUTHENTICATED');
    }

    public function test_an_expired_token_returns_401(): void
    {
        config()->set('projectport.jwt.expire_minutes', -1);

        $student = User::factory()->student()->create();

        $response = $this->getJson('/api/students/me/profile', $this->authHeader($student));

        $this->assertErrorContract($response, 401, 'TOKEN_EXPIRED');
    }

    public function test_authenticated_but_forbidden_requests_return_403(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $response = $this->getJson('/api/students/me/profile', $this->authHeader($recruiter));

        $this->assertErrorContract($response, 403, 'FORBIDDEN');
    }

    public function test_accounts_that_are_not_active_are_forbidden(): void
    {
        $student = User::factory()->student()->pending()->create();

        $response = $this->getJson('/api/students/me/profile', $this->authHeader($student));

        $this->assertErrorContract($response, 403, 'ACCOUNT_NOT_ACTIVE');
    }

    public function test_a_password_change_invalidates_previously_issued_tokens(): void
    {
        $student = User::factory()->student()->create(['password' => 'password']);
        $headers = $this->authHeader($student);

        $this->getJson('/api/students/me/profile', $headers)->assertOk();

        $this->patchJson('/api/me/credentials', [
            'current_password' => 'password',
            'password' => 'a-new-password',
        ], $headers)->assertOk();

        $this->assertErrorContract($this->getJson('/api/students/me/profile', $headers), 401, 'UNAUTHENTICATED');
    }
}
