<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * NFR-02: HTTPS-only connections (HSTS max-age=31536000, includeSubDomains).
 */
class SecurityHeadersTest extends TestCase
{
    use RefreshDatabase;

    public function test_responses_carry_the_hsts_header(): void
    {
        $response = $this->postJson('/api/auth/login', [
            'email' => 'nobody@example.com',
            'password' => 'password123',
        ]);

        $response->assertHeader(
            'Strict-Transport-Security',
            'max-age=31536000; includeSubDomains',
        );
    }

    public function test_authenticated_responses_carry_the_hsts_header(): void
    {
        $student = User::factory()->student()->create();

        $this->getJson('/api/students/me/profile', $this->authHeader($student))
            ->assertOk()
            ->assertHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    }

    public function test_password_hashes_are_never_exposed(): void
    {
        $student = User::factory()->student()->create();

        $response = $this->getJson('/api/students/me/profile', $this->authHeader($student));

        $response->assertOk();
        $this->assertStringNotContainsString('password', (string) $response->getContent());
    }
}
