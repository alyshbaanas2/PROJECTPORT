<?php

namespace Tests\Feature;

use App\Mail\VerifyEmailMail;
use App\Models\User;
use App\Services\EmailVerificationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

/**
 * FR-02: users verify their email address to complete registration.
 */
class VerifyEmailTest extends TestCase
{
    use RefreshDatabase;

    /** Given a valid verification token … then the user's email is verified. */
    public function test_a_valid_token_verifies_the_email_address(): void
    {
        Mail::fake();

        $user = User::factory()->unverified()->pending()->create();
        $token = app(EmailVerificationService::class)->verify_email($user);

        $response = $this->getJson('/api/auth/verify-email/'.$token);

        $response->assertOk();
        $response->assertJsonPath('user.email_verified', true);

        $user->refresh();
        $this->assertNotNull($user->email_verified_at);
        $this->assertNull($user->email_verification_token);
    }

    /** Given an invalid verification token … then an error message is displayed. */
    public function test_an_invalid_token_is_rejected(): void
    {
        $response = $this->getJson('/api/auth/verify-email/this-token-does-not-exist');

        $this->assertErrorContract($response, 400, 'INVALID_VERIFICATION_TOKEN', 'token');
    }

    public function test_an_expired_token_is_rejected(): void
    {
        Mail::fake();

        $user = User::factory()->unverified()->create();
        $token = app(EmailVerificationService::class)->verify_email($user);

        Carbon::setTestNow(Carbon::now()->addMinutes(
            (int) config('projectport.email_verification.token_ttl_minutes') + 1
        ));

        $response = $this->getJson('/api/auth/verify-email/'.$token);

        $this->assertErrorContract($response, 400, 'INVALID_VERIFICATION_TOKEN', 'token');
        $this->assertNull($user->refresh()->email_verified_at);

        Carbon::setTestNow();
    }

    public function test_a_verification_email_can_be_requested_again(): void
    {
        Mail::fake();

        $user = User::factory()->unverified()->create(['email' => 'ada@example.com']);

        $this->postJson('/api/auth/verify-email/resend', ['email' => 'ada@example.com'])->assertOk();

        Mail::assertSent(VerifyEmailMail::class, fn (VerifyEmailMail $mail) => $mail->hasTo('ada@example.com'));
        $this->assertNotNull($user->refresh()->email_verification_token);
    }

    public function test_resending_never_reveals_whether_an_address_is_registered(): void
    {
        Mail::fake();

        $unknown = $this->postJson('/api/auth/verify-email/resend', ['email' => 'nobody@example.com']);
        $unknown->assertOk();
        Mail::assertNothingSent();

        User::factory()->create(['email' => 'verified@example.com']);
        $verified = $this->postJson('/api/auth/verify-email/resend', ['email' => 'verified@example.com']);

        $verified->assertOk();
        // Same answer for an unknown address, an already verified one, and a real one.
        $this->assertSame($unknown->json('message'), $verified->json('message'));
        Mail::assertNothingSent();
    }

    public function test_resending_requires_a_valid_email_address(): void
    {
        $this->assertErrorContract(
            $this->postJson('/api/auth/verify-email/resend', ['email' => 'not-an-email']),
            400,
            'VALIDATION_FAILED',
            'email',
        );
    }

    public function test_a_verification_token_cannot_be_reused(): void
    {
        Mail::fake();

        $user = User::factory()->unverified()->create();
        $token = app(EmailVerificationService::class)->verify_email($user);

        $this->getJson('/api/auth/verify-email/'.$token)->assertOk();

        $this->assertErrorContract(
            $this->getJson('/api/auth/verify-email/'.$token),
            400,
            'INVALID_VERIFICATION_TOKEN',
            'token',
        );
    }
}
