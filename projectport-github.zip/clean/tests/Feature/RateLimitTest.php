<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\RateLimiter;
use Tests\TestCase;

/**
 * NFR-02: rate limiting — 10 req/min per IP on auth endpoints,
 * 100 req/min on read endpoints. Breaches use the Error Response Contract (429).
 */
class RateLimitTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        RateLimiter::clear('auth');
        RateLimiter::clear('read');
    }

    public function test_auth_endpoints_are_limited_to_ten_requests_per_minute(): void
    {
        $payload = ['email' => 'nobody@example.com', 'password' => 'password123'];

        for ($i = 0; $i < 10; $i++) {
            $this->postJson('/api/auth/login', $payload)->assertStatus(401);
        }

        $this->assertErrorContract(
            $this->postJson('/api/auth/login', $payload),
            429,
            'RATE_LIMIT_EXCEEDED',
        );
    }

    public function test_read_endpoints_are_limited_to_one_hundred_requests_per_minute(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $headers = $this->authHeader($recruiter);

        for ($i = 0; $i < 100; $i++) {
            $this->getJson('/api/search/students?q=laravel', $headers)->assertOk();
        }

        $this->assertErrorContract(
            $this->getJson('/api/search/students?q=laravel', $headers),
            429,
            'RATE_LIMIT_EXCEEDED',
        );
    }

    public function test_the_configured_limits_come_from_the_environment(): void
    {
        $this->assertSame(10, (int) config('projectport.rate_limits.auth_per_minute'));
        $this->assertSame(100, (int) config('projectport.rate_limits.read_per_minute'));
    }
}
