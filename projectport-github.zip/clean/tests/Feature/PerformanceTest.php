<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

/**
 * NFR-01: response time < 2000 ms for 90% of requests.
 * NFR-04: average query time < 100 ms, supported by indexes on queried columns.
 */
class PerformanceTest extends TestCase
{
    use RefreshDatabase;

    public function test_indexes_exist_on_the_columns_the_hot_queries_filter_on(): void
    {
        $userIndexes = collect(Schema::getIndexes('users'))->pluck('columns');
        $projectIndexes = collect(Schema::getIndexes('projects'))->pluck('columns');
        $registrationIndexes = collect(Schema::getIndexes('registrations'))->pluck('columns');

        // Composite index for the multi-column WHERE used by recruiter search.
        $this->assertTrue($userIndexes->contains(['role', 'status']));
        $this->assertTrue($userIndexes->contains(['email']));
        $this->assertTrue($userIndexes->contains(['email_verification_token']));
        $this->assertTrue($projectIndexes->contains(['user_id', 'created_at']));
        $this->assertTrue($projectIndexes->contains(['name']));
        $this->assertTrue($registrationIndexes->contains(['approved', 'created_at']));
    }

    public function test_recruiter_search_responds_within_the_two_second_budget(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $students = User::factory()->student()->count(50)->create(['skills' => 'php, laravel']);

        foreach ($students as $student) {
            Project::factory()->count(2)->create(['user_id' => $student->id]);
        }

        $startedAt = microtime(true);
        $response = $this->getJson('/api/search/students?q=laravel', $this->authHeader($recruiter));
        $durationMs = (microtime(true) - $startedAt) * 1000;

        $response->assertOk();
        $this->assertLessThan(
            (int) config('projectport.performance.response_budget_ms'),
            $durationMs,
            'Recruiter search exceeded the 2000 ms response budget.',
        );
    }

    public function test_every_response_reports_its_duration_for_monitoring(): void
    {
        $response = $this->getJson('/api/students/me/profile');

        $this->assertNotNull($response->headers->get('X-Response-Time-Ms'));
    }

    public function test_project_search_does_not_run_a_query_per_result(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $student = User::factory()->student()->create(['skills' => 'php']);
        Project::factory()->count(20)->create(['user_id' => $student->id, 'name' => 'Ledger Explorer']);

        DB::enableQueryLog();
        $this->getJson('/api/search/projects?q=Ledger', $this->authHeader($recruiter))->assertOk();
        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        // Eager loading keeps the query count flat regardless of result count.
        $this->assertLessThan(10, count($queries));
    }

    public function test_connection_pool_bounds_are_configured(): void
    {
        $this->assertSame(10, (int) config('database.connections.mysql.pool.min_connections'));
        $this->assertSame(50, (int) config('database.connections.mysql.pool.max_connections'));
    }
}
