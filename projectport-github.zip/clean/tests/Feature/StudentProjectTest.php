<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

/**
 * FR-05: students create and manage their profiles, including uploading
 * projects and source code.
 */
class StudentProjectTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Storage::fake(config('projectport.source_code.disk'));
    }

    private function archive(string $name = 'project.zip'): UploadedFile
    {
        return UploadedFile::fake()->createWithContent($name, "PK\x03\x04fake-archive-content");
    }

    /** Given a valid project … then the project is available on the student's profile. */
    public function test_a_valid_project_upload_appears_on_the_students_profile(): void
    {
        $student = User::factory()->student()->create();

        $response = $this->postJson('/api/students/me/projects', [
            'project_name' => 'Distributed Ledger Explorer',
            'source_code' => $this->archive(),
        ], $this->authHeader($student));

        $response->assertCreated();
        $response->assertJsonPath('project.name', 'Distributed Ledger Explorer');

        $project = Project::firstOrFail();
        $this->assertSame($student->id, $project->user_id);
        Storage::disk(config('projectport.source_code.disk'))->assertExists($project->source_code);

        $profile = $this->getJson('/api/students/me/profile', $this->authHeader($student));
        $profile->assertOk();
        $profile->assertJsonPath('student.projects.0.name', 'Distributed Ledger Explorer');
    }

    /** FR-05 validation rule: project_name minimum 5 characters. */
    public function test_a_project_name_shorter_than_five_characters_is_rejected(): void
    {
        $student = User::factory()->student()->create();

        $response = $this->postJson('/api/students/me/projects', [
            'project_name' => 'App',
            'source_code' => $this->archive(),
        ], $this->authHeader($student));

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'project_name');
        $this->assertSame(0, Project::count());
    }

    /** FR-05 validation rule: source_code must be a valid file type. */
    public function test_an_invalid_source_code_file_type_is_rejected(): void
    {
        $student = User::factory()->student()->create();

        $response = $this->postJson('/api/students/me/projects', [
            'project_name' => 'Malware Sample',
            'source_code' => UploadedFile::fake()->create('payload.exe', 12, 'application/x-msdownload'),
        ], $this->authHeader($student));

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'source_code');
        $this->assertSame(0, Project::count());
    }

    public function test_source_code_is_required(): void
    {
        $student = User::factory()->student()->create();

        $response = $this->postJson('/api/students/me/projects', [
            'project_name' => 'Missing Archive',
        ], $this->authHeader($student));

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'source_code');
    }

    public function test_a_student_can_manage_their_profile(): void
    {
        $student = User::factory()->student()->create(['name' => 'Old Name', 'skills' => 'php']);

        $response = $this->patchJson('/api/students/me/profile', [
            'name' => 'Ada Lovelace',
            'skills' => 'php, laravel, mysql',
        ], $this->authHeader($student));

        $response->assertOk();
        $response->assertJsonPath('student.name', 'Ada Lovelace');
        $this->assertSame('php, laravel, mysql', $student->refresh()->skills);
    }

    public function test_recruiters_cannot_upload_projects(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $response = $this->postJson('/api/students/me/projects', [
            'project_name' => 'Not My Project',
            'source_code' => $this->archive(),
        ], $this->authHeader($recruiter));

        $this->assertErrorContract($response, 403, 'FORBIDDEN');
    }

    public function test_a_project_is_only_stored_once_the_upload_is_valid(): void
    {
        $student = User::factory()->student()->create();

        $this->postJson('/api/students/me/projects', [
            'project_name' => 'Bad',
            'source_code' => $this->archive(),
        ], $this->authHeader($student));

        $this->assertSame(
            [],
            Storage::disk(config('projectport.source_code.disk'))->allFiles(),
        );
    }
}
