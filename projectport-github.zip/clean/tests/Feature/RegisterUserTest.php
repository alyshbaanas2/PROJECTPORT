<?php

namespace Tests\Feature;

use App\Mail\VerifyEmailMail;
use App\Models\Registration;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

/**
 * FR-01: users can register with a valid email address.
 */
class RegisterUserTest extends TestCase
{
    use RefreshDatabase;

    /** Given a valid email address … then the user receives a verification email. */
    public function test_a_valid_registration_sends_a_verification_email(): void
    {
        Mail::fake();

        $response = $this->postJson('/api/auth/register', [
            'email' => 'ada@example.com',
            'password' => 'password123',
            'role' => User::ROLE_STUDENT,
        ]);

        $response->assertCreated();
        $response->assertJsonPath('user.email', 'ada@example.com');

        $user = User::where('email', 'ada@example.com')->firstOrFail();
        $this->assertSame(User::STATUS_PENDING, $user->status);
        $this->assertNotNull($user->email_verification_token);

        Mail::assertSent(VerifyEmailMail::class, fn (VerifyEmailMail $mail) => $mail->hasTo('ada@example.com'));
    }

    /** FR-04: registering enqueues a pending registration for admin review. */
    public function test_registering_creates_a_pending_registration_record(): void
    {
        Mail::fake();

        $this->postJson('/api/auth/register', [
            'email' => 'grace@example.com',
            'password' => 'password123',
            'role' => User::ROLE_RECRUITER,
        ])->assertCreated();

        $registration = Registration::firstOrFail();
        $this->assertNull($registration->approved);
        $this->assertTrue($registration->isPending());
    }

    /** Given an invalid email address … then an error message is displayed. */
    public function test_an_invalid_email_address_is_rejected(): void
    {
        Mail::fake();

        $response = $this->postJson('/api/auth/register', [
            'email' => 'not-an-email',
            'password' => 'password123',
            'role' => User::ROLE_STUDENT,
        ]);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'email');
        $this->assertSame(0, User::count());
        Mail::assertNothingSent();
    }

    public function test_a_missing_email_address_is_rejected(): void
    {
        $response = $this->postJson('/api/auth/register', [
            'password' => 'password123',
            'role' => User::ROLE_STUDENT,
        ]);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'email');
    }

    /** FR-01 validation rule: email must be unique. */
    public function test_a_duplicate_email_address_is_rejected(): void
    {
        Mail::fake();
        User::factory()->create(['email' => 'ada@example.com']);

        $response = $this->postJson('/api/auth/register', [
            'email' => 'ada@example.com',
            'password' => 'password123',
            'role' => User::ROLE_STUDENT,
        ]);

        $this->assertErrorContract($response, 409, 'EMAIL_ALREADY_REGISTERED');
        Mail::assertNothingSent();
    }

    /** FR-03 validation rule: password minimum 8 characters. */
    public function test_a_short_password_is_rejected(): void
    {
        $response = $this->postJson('/api/auth/register', [
            'email' => 'ada@example.com',
            'password' => 'short',
            'role' => User::ROLE_STUDENT,
        ]);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'password');
    }
}
