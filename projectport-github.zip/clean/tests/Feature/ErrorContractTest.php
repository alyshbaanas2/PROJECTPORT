<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

/**
 * Phase 1: the Error Response Contract is the only error shape the app emits.
 */
class ErrorContractTest extends TestCase
{
    use RefreshDatabase;

    public function test_unexpected_server_errors_use_the_contract_and_hide_stack_traces(): void
    {
        Route::middleware('api')->get('/api/test-boom', function (): void {
            throw new \RuntimeException('database credentials leaked in this message');
        });

        $response = $this->withoutExceptionHandling(except: [\RuntimeException::class])
            ->getJson('/api/test-boom');

        $this->assertErrorContract($response, 500, 'INTERNAL_ERROR');
        $response->assertJsonMissing(['trace']);
        $this->assertStringNotContainsString('database credentials', (string) $response->getContent());
    }

    public function test_unknown_routes_return_the_contract_shape(): void
    {
        $this->assertErrorContract($this->getJson('/api/does-not-exist'), 404, 'NOT_FOUND');
    }

    public function test_validation_failures_include_the_offending_field(): void
    {
        $response = $this->postJson('/api/auth/register', []);

        $this->assertErrorContract($response, 400, 'VALIDATION_FAILED', 'email');
    }

    public function test_migrations_created_every_table_in_the_data_model(): void
    {
        foreach (['users', 'projects', 'registrations', 'refresh_tokens'] as $table) {
            $this->assertTrue(
                Schema::hasTable($table),
                "Missing table: {$table}",
            );
        }
    }
}
