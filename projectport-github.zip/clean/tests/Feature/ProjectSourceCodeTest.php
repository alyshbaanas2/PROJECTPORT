<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;
use ZipArchive;

/**
 * FR-05 / FR-06: reviewing the source code behind a project.
 */
class ProjectSourceCodeTest extends TestCase
{
    use RefreshDatabase;

    private string $disk;

    protected function setUp(): void
    {
        parent::setUp();

        $this->disk = (string) config('projectport.source_code.disk');
        Storage::fake($this->disk);
    }

    /** Upload a real zip through the API so the stored file is genuine. */
    private function publishProject(User $student, string $name = 'Distributed Ledger Explorer'): Project
    {
        $zipPath = tempnam(sys_get_temp_dir(), 'pp').'.zip';

        $zip = new ZipArchive;
        $zip->open($zipPath, ZipArchive::CREATE);
        $zip->addFromString('README.md', "# Ledger Explorer\n");
        $zip->addFromString('src/main.php', "<?php echo 'hello';\n");
        $zip->close();

        $this->postJson('/api/students/me/projects', [
            'project_name' => $name,
            'source_code' => new UploadedFile($zipPath, 'ledger.zip', 'application/zip', null, true),
        ], $this->authHeader($student))->assertCreated();

        return Project::where('name', $name)->firstOrFail();
    }

    public function test_a_recruiter_can_download_a_students_source_archive(): void
    {
        $student = User::factory()->student()->create();
        $project = $this->publishProject($student);
        $recruiter = User::factory()->recruiter()->create();

        $response = $this->get("/api/projects/{$project->id}/source-code", $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertDownload('distributed-ledger-explorer.zip');
    }

    public function test_a_recruiter_can_list_the_files_inside_an_archive(): void
    {
        $student = User::factory()->student()->create();
        $project = $this->publishProject($student);
        $recruiter = User::factory()->recruiter()->create();

        $response = $this->getJson("/api/projects/{$project->id}/source-code/contents", $this->authHeader($recruiter));

        $response->assertOk();
        $response->assertJsonPath('project.name', 'Distributed Ledger Explorer');
        $response->assertJsonPath('total_files', 2);
        $this->assertEqualsCanonicalizing(
            ['README.md', 'src/main.php'],
            array_column($response->json('files'), 'name'),
        );
    }

    public function test_a_student_can_open_their_own_project(): void
    {
        $student = User::factory()->student()->create();
        $project = $this->publishProject($student);

        $this->get("/api/projects/{$project->id}/source-code", $this->authHeader($student))->assertOk();
    }

    public function test_a_student_cannot_open_someone_elses_project(): void
    {
        $owner = User::factory()->student()->create();
        $project = $this->publishProject($owner);
        $other = User::factory()->student()->create();

        $this->assertErrorContract(
            $this->getJson("/api/projects/{$project->id}/source-code", $this->authHeader($other)),
            403,
            'FORBIDDEN',
        );
    }

    public function test_unauthenticated_requests_cannot_download_source_code(): void
    {
        $student = User::factory()->student()->create();
        $project = $this->publishProject($student);

        $this->assertErrorContract(
            $this->getJson("/api/projects/{$project->id}/source-code"),
            401,
            'UNAUTHENTICATED',
        );
    }

    /** Work belonging to a student who is not approved stays out of reach. */
    public function test_projects_of_inactive_students_are_not_downloadable(): void
    {
        $student = User::factory()->student()->create();
        $project = $this->publishProject($student);
        $student->forceFill(['status' => User::STATUS_INACTIVE])->save();

        $recruiter = User::factory()->recruiter()->create();

        $this->assertErrorContract(
            $this->getJson("/api/projects/{$project->id}/source-code", $this->authHeader($recruiter)),
            404,
            'NOT_FOUND',
        );
    }

    public function test_a_missing_archive_returns_404(): void
    {
        $student = User::factory()->student()->create();
        $project = Project::factory()->create(['user_id' => $student->id]);
        $recruiter = User::factory()->recruiter()->create();

        $this->assertErrorContract(
            $this->getJson("/api/projects/{$project->id}/source-code", $this->authHeader($recruiter)),
            404,
            'NOT_FOUND',
        );
    }

    public function test_a_non_zip_archive_reports_that_no_preview_exists(): void
    {
        $student = User::factory()->student()->create();

        $this->postJson('/api/students/me/projects', [
            'project_name' => 'Tarball Project',
            'source_code' => UploadedFile::fake()->createWithContent('src.tar', str_repeat('x', 64)),
        ], $this->authHeader($student))->assertCreated();

        $project = Project::where('name', 'Tarball Project')->firstOrFail();
        $recruiter = User::factory()->recruiter()->create();

        $this->assertErrorContract(
            $this->getJson("/api/projects/{$project->id}/source-code/contents", $this->authHeader($recruiter)),
            422,
            'PREVIEW_UNAVAILABLE',
        );
    }
}
