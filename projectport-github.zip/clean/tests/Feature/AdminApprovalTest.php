<?php

namespace Tests\Feature;

use App\Mail\VerifyEmailMail;
use App\Models\Registration;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

/**
 * FR-04: admins approve or reject student and recruiter registrations.
 */
class AdminApprovalTest extends TestCase
{
    use RefreshDatabase;

    public function test_the_queue_lists_pending_registrations_with_counts(): void
    {
        $admin = User::factory()->admin()->create();

        $pending = User::factory()->student()->pending()->create(['name' => 'Ada Lovelace']);
        Registration::factory()->create(['user_id' => $pending->id]);

        $decided = User::factory()->recruiter()->create();
        Registration::factory()->create(['user_id' => $decided->id, 'approved' => true]);

        $response = $this->getJson('/api/admin/registrations', $this->authHeader($admin));

        $response->assertOk();
        $response->assertJsonPath('state', 'pending');
        $response->assertJsonPath('total', 1);
        $response->assertJsonPath('registrations.0.state', 'pending');
        $response->assertJsonPath('registrations.0.user.name', 'Ada Lovelace');
        $response->assertJsonPath('counts.pending', 1);
        $response->assertJsonPath('counts.approved', 1);
    }

    public function test_the_queue_can_be_filtered_by_state_and_searched(): void
    {
        $admin = User::factory()->admin()->create();

        $approvedUser = User::factory()->student()->create(['email' => 'ada@example.com']);
        Registration::factory()->create(['user_id' => $approvedUser->id, 'approved' => true]);

        $rejectedUser = User::factory()->student()->inactive()->create(['email' => 'bob@example.com']);
        Registration::factory()->create(['user_id' => $rejectedUser->id, 'approved' => false]);

        $this->getJson('/api/admin/registrations?state=approved', $this->authHeader($admin))
            ->assertOk()
            ->assertJsonPath('total', 1)
            ->assertJsonPath('registrations.0.user.email', 'ada@example.com');

        $this->getJson('/api/admin/registrations?state=rejected', $this->authHeader($admin))
            ->assertOk()
            ->assertJsonPath('registrations.0.state', 'rejected');

        $this->getJson('/api/admin/registrations?state=all&q=bob', $this->authHeader($admin))
            ->assertOk()
            ->assertJsonPath('total', 1)
            ->assertJsonPath('registrations.0.user.email', 'bob@example.com');
    }

    public function test_an_invalid_queue_filter_is_rejected(): void
    {
        $admin = User::factory()->admin()->create();

        $this->assertErrorContract(
            $this->getJson('/api/admin/registrations?state=nonsense', $this->authHeader($admin)),
            400,
            'VALIDATION_FAILED',
            'state',
        );
    }

    public function test_non_admins_cannot_read_the_queue(): void
    {
        $recruiter = User::factory()->recruiter()->create();

        $this->assertErrorContract(
            $this->getJson('/api/admin/registrations', $this->authHeader($recruiter)),
            403,
            'FORBIDDEN',
        );
    }

    /** Given a pending registration, when the admin approves it, the account is active. */
    public function test_approving_a_pending_registration_activates_the_account(): void
    {
        $admin = User::factory()->admin()->create();
        $student = User::factory()->student()->pending()->create();
        $registration = Registration::factory()->create(['user_id' => $student->id]);

        $response = $this->postJson(
            "/api/admin/registrations/{$registration->id}/approve",
            [],
            $this->authHeader($admin),
        );

        $response->assertOk();
        $response->assertJsonPath('user.status', User::STATUS_ACTIVE);

        $this->assertTrue($student->refresh()->isActive());
        $this->assertTrue($registration->refresh()->approved);
        $this->assertSame($admin->id, $registration->admin_id);
        $this->assertNotNull($registration->decided_at);
    }

    /** Given a pending registration, when the admin rejects it, the account is inactive. */
    public function test_rejecting_a_pending_registration_deactivates_the_account(): void
    {
        $admin = User::factory()->admin()->create();
        $recruiter = User::factory()->recruiter()->pending()->create();
        $registration = Registration::factory()->create(['user_id' => $recruiter->id]);

        $response = $this->postJson(
            "/api/admin/registrations/{$registration->id}/reject",
            [],
            $this->authHeader($admin),
        );

        $response->assertOk();
        $response->assertJsonPath('user.status', User::STATUS_INACTIVE);

        $this->assertSame(User::STATUS_INACTIVE, $recruiter->refresh()->status);
        $this->assertFalse($registration->refresh()->approved);
    }

    /** Approving vouches for the address, so the approved user can sign in straight away. */
    public function test_approving_an_unverified_account_settles_email_verification(): void
    {
        $admin = User::factory()->admin()->create();
        $student = User::factory()->student()->pending()->unverified()->create([
            'email' => 'liam@example.com',
            'password' => 'password123',
            'email_verification_token' => hash('sha256', 'some-token'),
        ]);
        $registration = Registration::factory()->create(['user_id' => $student->id]);

        $this->postJson("/api/admin/registrations/{$registration->id}/approve", [], $this->authHeader($admin))
            ->assertOk()
            ->assertJsonPath('user.email_verified', true);

        $student->refresh();
        $this->assertNotNull($student->email_verified_at);
        $this->assertNull($student->email_verification_token);

        // The whole point: the approved account can now log in.
        $this->postJson('/api/auth/login', [
            'email' => 'liam@example.com',
            'password' => 'password123',
        ])->assertOk();
    }

    /** Rejecting must not hand out verification. */
    public function test_rejecting_an_unverified_account_leaves_it_unverified(): void
    {
        $admin = User::factory()->admin()->create();
        $student = User::factory()->student()->pending()->unverified()->create();
        $registration = Registration::factory()->create(['user_id' => $student->id]);

        $this->postJson("/api/admin/registrations/{$registration->id}/reject", [], $this->authHeader($admin))
            ->assertOk()
            ->assertJsonPath('user.email_verified', false);

        $this->assertNull($student->refresh()->email_verified_at);
    }

    public function test_a_registration_cannot_be_decided_twice(): void
    {
        $admin = User::factory()->admin()->create();
        $student = User::factory()->student()->pending()->create();
        $registration = Registration::factory()->create(['user_id' => $student->id]);

        $this->postJson("/api/admin/registrations/{$registration->id}/approve", [], $this->authHeader($admin))
            ->assertOk();

        $this->assertErrorContract(
            $this->postJson("/api/admin/registrations/{$registration->id}/reject", [], $this->authHeader($admin)),
            409,
            'REGISTRATION_ALREADY_DECIDED',
        );
    }

    public function test_non_admins_cannot_decide_registrations(): void
    {
        $recruiter = User::factory()->recruiter()->create();
        $registration = Registration::factory()->create();

        $this->assertErrorContract(
            $this->postJson("/api/admin/registrations/{$registration->id}/approve", [], $this->authHeader($recruiter)),
            403,
            'FORBIDDEN',
        );

        $this->assertNull($registration->refresh()->approved);
    }

    public function test_unauthenticated_requests_cannot_decide_registrations(): void
    {
        $registration = Registration::factory()->create();

        $this->assertErrorContract(
            $this->postJson("/api/admin/registrations/{$registration->id}/approve"),
            401,
            'UNAUTHENTICATED',
        );
    }

    public function test_an_unknown_registration_returns_404(): void
    {
        $admin = User::factory()->admin()->create();

        $this->assertErrorContract(
            $this->postJson('/api/admin/registrations/9999/approve', [], $this->authHeader($admin)),
            404,
            'NOT_FOUND',
        );
    }

    /** Student Registration journey: register → verify → login, then approval activates the account. */
    public function test_the_student_registration_journey_end_to_end(): void
    {
        Mail::fake();

        $this->postJson('/api/auth/register', [
            'email' => 'ada@example.com',
            'password' => 'password123',
            'role' => User::ROLE_STUDENT,
        ])->assertCreated();

        $token = null;
        Mail::assertSent(
            VerifyEmailMail::class,
            function (VerifyEmailMail $mail) use (&$token) {
                $token = $mail->token;

                return true;
            },
        );

        $this->getJson('/api/auth/verify-email/'.$token)->assertOk();

        $login = $this->postJson('/api/auth/login', [
            'email' => 'ada@example.com',
            'password' => 'password123',
        ]);
        $login->assertOk();

        $headers = ['Authorization' => 'Bearer '.$login->json('access_token')];

        // Still pending an admin decision: protected student features stay closed.
        $this->assertErrorContract($this->getJson('/api/students/me/profile', $headers), 403, 'ACCOUNT_NOT_ACTIVE');

        $admin = User::factory()->admin()->create();
        $registration = Registration::firstOrFail();

        $this->postJson("/api/admin/registrations/{$registration->id}/approve", [], $this->authHeader($admin))
            ->assertOk();

        $this->getJson('/api/students/me/profile', $headers)->assertOk();
    }
}
