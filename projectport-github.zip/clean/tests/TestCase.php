<?php

namespace Tests;

use App\Models\User;
use App\Services\JwtService;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Testing\TestResponse;

abstract class TestCase extends BaseTestCase
{
    /**
     * Authorization header for a user, using the stateless JWT issued by the app.
     *
     * @return array<string, string>
     */
    protected function authHeader(User $user): array
    {
        $token = app(JwtService::class)->issueAccessToken($user);

        return ['Authorization' => 'Bearer '.$token];
    }

    /**
     * Assert a response matches the Error Response Contract exactly.
     */
    protected function assertErrorContract(
        TestResponse $response,
        int $status,
        ?string $errorCode = null,
        ?string $field = null,
    ): void {
        $response->assertStatus($status);

        $payload = $response->json();

        $this->assertIsArray($payload);
        $this->assertArrayHasKey('error', $payload);
        $this->assertArrayHasKey('message', $payload);
        $this->assertIsString($payload['error']);
        $this->assertIsString($payload['message']);
        $this->assertMatchesRegularExpression('/^[A-Z][A-Z0-9_]*$/', $payload['error']);

        // No keys beyond the contract are permitted.
        $this->assertEmpty(array_diff(array_keys($payload), ['error', 'message', 'field']));

        if ($errorCode !== null) {
            $this->assertSame($errorCode, $payload['error']);
        }

        if ($field !== null) {
            $this->assertSame($field, $payload['field'] ?? null);
        }
    }
}
