# Setup After Cloning

This repo was slimmed down for GitHub. A few things are regenerated locally
and are NOT included in the repo (this is normal for any Laravel project):

1. Install PHP dependencies:
   composer install

2. Install JS dependencies:
   npm install

3. Create your local env file and generate an app key:
   cp .env.example .env
   php artisan key:generate

4. (If your app uses the database) run migrations:
   php artisan migrate

5. (If your app serves user-uploaded files) recreate the storage symlink:
   php artisan storage:link

That's it — the app will behave exactly as before once these are run.
