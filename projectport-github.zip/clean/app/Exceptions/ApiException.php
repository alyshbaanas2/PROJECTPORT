<?php

namespace App\Exceptions;

use App\Support\ApiError;
use Illuminate\Http\JsonResponse;
use RuntimeException;
use Throwable;

/**
 * The only exception type feature code throws for expected failures.
 * It renders itself using the Error Response Contract.
 */
class ApiException extends RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $status,
        public readonly ?string $field = null,
        ?Throwable $previous = null,
    ) {
        parent::__construct($message, $status, $previous);
    }

    /** 400 — validation failure (always carries a field). */
    public static function validation(string $message, string $field): self
    {
        return new self(ApiError::VALIDATION_FAILED, $message, 400, $field);
    }

    /** 401 — missing or expired JWT. */
    public static function unauthenticated(string $message = 'Authentication is required.', string $code = ApiError::UNAUTHENTICATED): self
    {
        return new self($code, $message, 401);
    }

    /** 403 — authenticated but not authorised for this resource. */
    public static function forbidden(string $message = 'You are not authorised to perform this action.'): self
    {
        return new self(ApiError::FORBIDDEN, $message, 403);
    }

    /** 404 — resource not found. */
    public static function notFound(string $message = 'Resource not found.'): self
    {
        return new self(ApiError::NOT_FOUND, $message, 404);
    }

    /** 409 — conflict. */
    public static function conflict(string $message, string $code = ApiError::CONFLICT): self
    {
        return new self($code, $message, 409);
    }

    /** 422 — business rule violation. */
    public static function businessRule(string $code, string $message): self
    {
        return new self($code, $message, 422);
    }

    public function render(): JsonResponse
    {
        return ApiError::response($this->errorCode, $this->getMessage(), $this->status, $this->field);
    }
}
