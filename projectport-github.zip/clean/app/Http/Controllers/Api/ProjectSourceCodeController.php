<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\User;
use App\Services\SourceCodeStorageService;
use App\Support\ApiError;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;
use ZipArchive;

/**
 * FR-05 / FR-06: recruiters reviewing a student's work need to open the source
 * code a student uploaded, not just its name.
 */
class ProjectSourceCodeController extends Controller
{
    public function __construct(private readonly SourceCodeStorageService $sourceCode) {}

    /** Download the uploaded source archive. */
    public function download(Request $request, Project $project): StreamedResponse
    {
        $this->authorizeAccess($request, $project);

        return Storage::disk($this->sourceCode->disk())->download(
            $project->source_code,
            $this->downloadName($project),
        );
    }

    /**
     * List what is inside the archive so a recruiter can review the work in the
     * browser before downloading it.
     */
    public function contents(Request $request, Project $project): JsonResponse
    {
        $this->authorizeAccess($request, $project);

        $path = Storage::disk($this->sourceCode->disk())->path($project->source_code);

        if (! str_ends_with(strtolower((string) $project->source_code), '.zip')) {
            throw ApiException::businessRule(
                ApiError::PREVIEW_UNAVAILABLE,
                'A file listing is only available for zip archives. Download the archive to review it.',
            );
        }

        $zip = new ZipArchive;

        if ($zip->open($path) !== true) {
            throw ApiException::businessRule(
                ApiError::PREVIEW_UNAVAILABLE,
                'This archive could not be opened.',
            );
        }

        $entries = [];

        for ($i = 0; $i < min($zip->numFiles, 500); $i++) {
            $entry = $zip->statIndex($i);

            if ($entry === false || str_ends_with($entry['name'], '/')) {
                continue;
            }

            $entries[] = [
                'name' => $entry['name'],
                'size' => (int) $entry['size'],
            ];
        }

        $total = $zip->numFiles;
        $zip->close();

        return new JsonResponse([
            'project' => ['id' => $project->id, 'name' => $project->name],
            'download_name' => $this->downloadName($project),
            'files' => $entries,
            'total_files' => $total,
            'truncated' => $total > 500,
        ]);
    }

    /**
     * Recruiters and admins may open any active student's work; a student may
     * only open their own.
     */
    private function authorizeAccess(Request $request, Project $project): void
    {
        /** @var User $viewer */
        $viewer = $request->user();

        if ($viewer->hasRole(User::ROLE_STUDENT) && $project->user_id !== $viewer->getKey()) {
            throw ApiException::forbidden('You can only open your own projects.');
        }

        $owner = $project->user;

        if (! $viewer->hasRole(User::ROLE_STUDENT) && ($owner === null || ! $owner->isActive())) {
            throw ApiException::notFound('Project not found.');
        }

        if ($project->source_code === null || ! $this->sourceCode->exists($project->source_code)) {
            throw ApiException::notFound('This project has no source archive available.');
        }
    }

    /** A human filename built from the project name, keeping the stored extension. */
    private function downloadName(Project $project): string
    {
        $extension = pathinfo((string) $project->source_code, PATHINFO_EXTENSION) ?: 'zip';

        return Str::slug($project->name).'.'.$extension;
    }
}
