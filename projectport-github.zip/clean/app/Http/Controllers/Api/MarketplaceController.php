<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProjectResource;
use App\Models\Comment;
use App\Models\Like;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Marketplace: public project feed with search/filter, likes, and comments.
 * Accessible to any authenticated user (student, recruiter, admin).
 */
class MarketplaceController extends Controller
{
    /**
     * GET /marketplace
     * Paginated list of all projects, newest first, with optional search.
     * Filters: q (name/skill keyword), skill (exact tag match).
     */
    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $q     = (string) $request->query('q', '');
        $skill = (string) $request->query('skill', '');
        $sort  = $request->query('sort', 'latest'); // latest | popular | most_commented

        $query = Project::with(['user', 'likes', 'comments.user'])
            ->whereHas('user', fn ($u) => $u->where('status', User::STATUS_ACTIVE));

        if ($q !== '') {
            $query->where(function ($q2) use ($q) {
                $q2->where('name', 'like', "%{$q}%")
                   ->orWhereHas('user', fn ($u) => $u->where('skills', 'like', "%{$q}%")
                       ->orWhere('name', 'like', "%{$q}%"));
            });
        }

        if ($skill !== '') {
            $query->whereHas('user', fn ($u) => $u->where('skills', 'like', "%{$skill}%"));
        }

        match ($sort) {
            'popular'       => $query->withCount('likes')->orderByDesc('likes_count'),
            'most_commented' => $query->withCount('comments')->orderByDesc('comments_count'),
            default          => $query->latest(),
        };

        $paginated = $query->paginate(12);

        // Tag each project with whether the current user has liked it.
        $likedIds = Like::where('user_id', $user->getKey())
            ->whereIn('project_id', $paginated->pluck('id'))
            ->pluck('project_id')
            ->flip();

        $projects = $paginated->getCollection()->map(function (Project $p) use ($likedIds) {
            $p->user_has_liked    = $likedIds->has($p->id);
            $p->likes_count_val   = $p->likes->count();
            $p->comments_count_val = $p->comments->count();

            return $p;
        });

        return new JsonResponse([
            'projects'     => ProjectResource::collection($projects),
            'current_page' => $paginated->currentPage(),
            'last_page'    => $paginated->lastPage(),
            'total'        => $paginated->total(),
        ]);
    }

    /**
     * POST /projects/{project}/like
     */
    public function like(Request $request, Project $project): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        Like::firstOrCreate([
            'user_id'    => $user->getKey(),
            'project_id' => $project->getKey(),
        ]);

        return new JsonResponse([
            'likes_count'   => $project->likes()->count(),
            'user_has_liked' => true,
        ]);
    }

    /**
     * DELETE /projects/{project}/like
     */
    public function unlike(Request $request, Project $project): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        Like::where('user_id', $user->getKey())
            ->where('project_id', $project->getKey())
            ->delete();

        return new JsonResponse([
            'likes_count'   => $project->likes()->count(),
            'user_has_liked' => false,
        ]);
    }

    /**
     * POST /projects/{project}/comments
     */
    public function addComment(Request $request, Project $project): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $data = $request->validate([
            'body' => ['required', 'string', 'min:1', 'max:1000'],
        ]);

        $comment = Comment::create([
            'user_id'    => $user->getKey(),
            'project_id' => $project->getKey(),
            'body'       => $data['body'],
        ]);

        $comment->load('user');

        return new JsonResponse([
            'comment' => [
                'id'         => $comment->id,
                'body'       => $comment->body,
                'created_at' => $comment->created_at->toIso8601String(),
                'user'       => [
                    'id'           => $comment->user->id,
                    'name'         => $comment->user->name,
                    'email'        => $comment->user->email,
                    'resume_photo' => $comment->user->resume_photo
                        ? \Illuminate\Support\Facades\Storage::disk(
                            (string) config('projectport.resume_photo.disk', 'public')
                        )->url($comment->user->resume_photo)
                        : null,
                ],
            ],
        ], 201);
    }

    /**
     * DELETE /comments/{comment}
     * Only the comment author may delete their own comment.
     */
    public function deleteComment(Request $request, Comment $comment): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        if ($comment->user_id !== $user->getKey()) {
            return new JsonResponse(['message' => 'Forbidden.'], 403);
        }

        $comment->delete();

        return new JsonResponse(['message' => 'Comment deleted.']);
    }
}
