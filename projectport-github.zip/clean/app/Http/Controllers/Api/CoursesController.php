<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\CourseProgress;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Courses: video-based learning with progress tracking, certification,
 * and an AI assistant that answers questions about the course topic.
 */
class CoursesController extends Controller
{
    // ── index ────────────────────────────────────────────────────────────

    /**
     * GET /courses
     * Return all courses grouped by topic, each enriched with the calling
     * user's progress (watched / certified).
     */
    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $courses = Course::orderBy('sort_order')->orderBy('title')->get();

        // Load this user's progress in one query.
        $progressMap = CourseProgress::where('user_id', $user->getKey())
            ->whereIn('course_id', $courses->pluck('id'))
            ->get()
            ->keyBy('course_id');

        $list = $courses->map(function (Course $c) use ($progressMap) {
            $progress = $progressMap->get($c->id);
            return [
                'id'           => $c->id,
                'title'        => $c->title,
                'description'  => $c->description,
                'topic'        => $c->topic,
                'youtube_url'  => $c->youtube_url,
                'youtube_id'   => $c->youtube_id,
                'watched'      => (bool) $progress?->watched,
                'certified'    => (bool) $progress?->certified,
                'certified_at' => $progress?->certified_at?->toIso8601String(),
            ];
        });

        // Group by topic for the UI.
        $grouped = $list->groupBy('topic')->map(fn ($items) => $items->values())->toArray();

        return new JsonResponse([
            'courses' => $list->values(),
            'grouped' => $grouped,
            'stats'   => [
                'total'      => $courses->count(),
                'watched'    => $progressMap->where('watched', true)->count(),
                'certified'  => $progressMap->where('certified', true)->count(),
            ],
        ]);
    }

    // ── mark watched ─────────────────────────────────────────────────────

    /**
     * POST /courses/{course}/progress
     * Mark the course as watched for the authenticated user.
     */
    public function markWatched(Request $request, Course $course): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $progress = CourseProgress::firstOrCreate(
            ['user_id' => $user->getKey(), 'course_id' => $course->getKey()],
            ['watched' => false, 'certified' => false],
        );

        $progress->watched = true;
        $progress->save();

        return new JsonResponse([
            'message'  => 'Course marked as watched.',
            'watched'  => true,
            'certified' => $progress->certified,
        ]);
    }

    // ── certify ──────────────────────────────────────────────────────────

    /**
     * POST /courses/{course}/certify
     * Issue a certificate after the student confirms they have watched the video.
     * Requires the course to be marked as watched first.
     */
    public function certify(Request $request, Course $course): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $progress = CourseProgress::firstOrCreate(
            ['user_id' => $user->getKey(), 'course_id' => $course->getKey()],
            ['watched' => false, 'certified' => false],
        );

        if (! $progress->watched) {
            return new JsonResponse([
                'message' => 'You must mark the course as watched before claiming a certificate.',
            ], 422);
        }

        if (! $progress->certified) {
            $progress->certified    = true;
            $progress->certified_at = now();
            $progress->save();
        }

        return new JsonResponse([
            'message'      => 'Certificate issued!',
            'certified'    => true,
            'certified_at' => $progress->certified_at->toIso8601String(),
            'certificate'  => [
                'student_name' => $user->name ?? $user->email,
                'course_title' => $course->title,
                'topic'        => $course->topic,
                'issued_at'    => $progress->certified_at->format('F j, Y'),
            ],
        ]);
    }

    // ── AI chat ──────────────────────────────────────────────────────────

    /**
     * POST /courses/{course}/ai-chat
     *
     * When OPENAI_API_KEY is set, proxies to GPT-4o-mini.
     * When no key is configured, falls back to a built-in keyword-based
     * knowledge engine so students always get a real answer.
     */
    public function aiChat(Request $request, Course $course): JsonResponse
    {
        $data = $request->validate([
            'question' => ['required', 'string', 'min:2', 'max:1000'],
        ]);

        $question = $data['question'];
        $apiKey   = config('services.openai.key');

        // ── OpenAI path ───────────────────────────────────────────────────
        if ($apiKey) {
            try {
                $systemPrompt = "You are an expert tutor specialising in {$course->topic}. "
                    . "The student is watching a course called \"{$course->title}\". "
                    . "Answer clearly and concisely. Keep answers under 300 words unless more is needed. "
                    . "Use code examples when they help.";

                $response = Http::withToken($apiKey)
                    ->timeout(30)
                    ->post('https://api.openai.com/v1/chat/completions', [
                        'model'      => 'gpt-4o-mini',
                        'max_tokens' => 600,
                        'messages'   => [
                            ['role' => 'system', 'content' => $systemPrompt],
                            ['role' => 'user',   'content' => $question],
                        ],
                    ]);

                if ($response->successful()) {
                    return new JsonResponse(['answer' => trim($response->json('choices.0.message.content') ?? '')]);
                }

                Log::warning('OpenAI API error', ['status' => $response->status()]);
                // Fall through to built-in engine on API failure.
            } catch (\Throwable $e) {
                Log::error('OpenAI request failed', ['error' => $e->getMessage()]);
                // Fall through to built-in engine.
            }
        }

        // ── Built-in knowledge engine (no API key needed) ─────────────────
        return new JsonResponse(['answer' => $this->builtInAnswer($question, $course->topic)]);
    }

    /**
     * A keyword-matched knowledge base that covers common questions across
     * all seeded course topics. Returns a detailed, formatted answer.
     */
    private function builtInAnswer(string $question, string $topic): string
    {
        $q = strtolower($question);

        $kb = [
            // ── Databases / MySQL ──────────────────────────────────────────
            'mysql server'          => "MySQL is a **relational database management system (RDBMS)**. It does not run inside a web server — it runs as its own background service/daemon.\n\n**How MySQL runs:**\n- On **Windows**: MySQL runs as a Windows Service called `MySQL80` (or similar). It is managed via Services or tools like XAMPP, WAMP, or Laragon.\n- On **Linux/macOS**: MySQL runs as a system daemon: `sudo systemctl start mysql`\n- On **XAMPP / Laragon**: The control panel starts MySQL for you alongside Apache.\n\n**Default port**: 3306\n\n**Popular tools to connect:**\n- phpMyAdmin (browser-based)\n- MySQL Workbench (desktop GUI)\n- TablePlus, DBeaver\n- Command line: `mysql -u root -p`\n\nYour PHP/Laravel app connects to this running MySQL service using the credentials in your `.env` file.",
            'run mysql'             => "MySQL is a **relational database management system (RDBMS)**. It does not run inside a web server — it runs as its own background service/daemon.\n\n**How MySQL runs:**\n- On **Windows**: MySQL runs as a Windows Service called `MySQL80` (or similar). It is managed via Services or tools like XAMPP, WAMP, or Laragon.\n- On **Linux/macOS**: MySQL runs as a system daemon: `sudo systemctl start mysql`\n- On **XAMPP / Laragon**: The control panel starts MySQL for you alongside Apache.\n\n**Default port**: 3306\n\n**Popular tools to connect:**\n- phpMyAdmin (browser-based)\n- MySQL Workbench (desktop GUI)\n- TablePlus, DBeaver\n- Command line: `mysql -u root -p`\n\nYour PHP/Laravel app connects to this running MySQL service using the credentials in your `.env` file.",
            'server is used'        => "MySQL is a **relational database management system (RDBMS)**. It does not run inside a web server — it runs as its own background service/daemon.\n\n**How MySQL runs:**\n- On **Windows**: MySQL runs as a Windows Service called `MySQL80` (or similar). It is managed via Services or tools like XAMPP, WAMP, or Laragon.\n- On **Linux/macOS**: MySQL runs as a system daemon: `sudo systemctl start mysql`\n- On **XAMPP / Laragon**: The control panel starts MySQL for you alongside Apache.\n\n**Default port**: 3306\n\n**Popular tools to connect:**\n- phpMyAdmin (browser-based)\n- MySQL Workbench (desktop GUI)\n- TablePlus, DBeaver\n- Command line: `mysql -u root -p`\n\nYour PHP/Laravel app connects to this running MySQL service using the credentials in your `.env` file.",
            'what is mysql'         => "**MySQL** is an open-source relational database management system (RDBMS). It stores data in tables with rows and columns, and uses **SQL (Structured Query Language)** to query and manage that data.\n\n**Key facts:**\n- Created by MySQL AB, now owned by Oracle\n- Used by Facebook, Twitter, YouTube, and millions of websites\n- Laravel uses MySQL (or compatible databases like MariaDB) as its primary database\n- Data is stored in `.ibd` files on disk, managed by the InnoDB storage engine by default\n\n**Basic SQL example:**\n```sql\nSELECT * FROM users WHERE active = 1 ORDER BY created_at DESC;\n```",
            'sql join'              => "**SQL JOINs** combine rows from two or more tables based on a related column.\n\n**Types:**\n```sql\n-- INNER JOIN: only matching rows\nSELECT u.name, p.title\nFROM users u\nINNER JOIN projects p ON p.user_id = u.id;\n\n-- LEFT JOIN: all from left + matching from right\nSELECT u.name, p.title\nFROM users u\nLEFT JOIN projects p ON p.user_id = u.id;\n\n-- RIGHT JOIN: all from right + matching from left\n-- FULL OUTER JOIN: all rows from both tables\n```\n\nIn Laravel you can use `->join()`, `->leftJoin()`, or simply define Eloquent relationships and use `->with()`.",
            'primary key'           => "A **primary key** is a column (or set of columns) that **uniquely identifies each row** in a table.\n\n**Rules:**\n- Must be unique — no two rows can have the same value\n- Cannot be NULL\n- Each table should have exactly one primary key\n\n**Example:**\n```sql\nCREATE TABLE users (\n    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,\n    email VARCHAR(255) NOT NULL\n);\n```\n\nIn Laravel migrations: `\$table->id()` creates an auto-incrementing `BIGINT UNSIGNED` primary key named `id`.",
            'foreign key'           => "A **foreign key** is a column that references the primary key of another table, creating a **relationship** between tables.\n\n```sql\nCREATE TABLE projects (\n    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,\n    user_id BIGINT UNSIGNED NOT NULL,\n    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\n);\n```\n\nIn Laravel migrations:\n```php\n\$table->foreignId('user_id')->constrained()->cascadeOnDelete();\n```\n\nThis means: if the parent user is deleted, all their projects are automatically deleted too.",
            'index'                 => "A **database index** is a data structure that speeds up `SELECT` queries on a column.\n\nWithout an index, MySQL scans every row (**full table scan**). With an index, it jumps directly to matching rows.\n\n```sql\nCREATE INDEX idx_email ON users(email);\n```\n\nIn Laravel:\n```php\n\$table->string('email')->index();\n// or unique:\n\$table->string('email')->unique();\n```\n\n**When to add indexes:** columns used in `WHERE`, `ORDER BY`, `JOIN ON`, or `GROUP BY` clauses.",
            'transaction'           => "A **database transaction** groups multiple SQL statements so they either **all succeed or all fail together** — ensuring data consistency.\n\n```sql\nSTART TRANSACTION;\n  UPDATE accounts SET balance = balance - 100 WHERE id = 1;\n  UPDATE accounts SET balance = balance + 100 WHERE id = 2;\nCOMMIT;  -- or ROLLBACK if something went wrong\n```\n\nIn Laravel:\n```php\nDB::transaction(function () {\n    User::create([...]);\n    Profile::create([...]);\n}); // auto-commits or rolls back on exception\n```",

            // ── Laravel ────────────────────────────────────────────────────
            'eloquent'              => "**Eloquent** is Laravel's built-in ORM (Object-Relational Mapper). It lets you interact with your database using PHP objects instead of raw SQL.\n\n```php\n// Get all active users\n\$users = User::where('status', 'active')->get();\n\n// Create a record\nUser::create(['name' => 'Alice', 'email' => 'alice@example.com']);\n\n// Relationships\n\$projects = User::find(1)->projects; // uses hasMany relationship\n```\n\nEach Eloquent model maps to a database table. By convention, a `User` model maps to the `users` table.",
            'middleware'            => "**Middleware** in Laravel is code that runs **before or after** an HTTP request reaches your controller.\n\n**Common uses:**\n- Authentication (check user is logged in)\n- Role checks (ensure user is admin)\n- Logging request timing\n- Adding response headers\n\n```php\n// Register in bootstrap/app.php or routes\nRoute::middleware(['auth', 'role:admin'])->group(function () {\n    Route::get('/admin', AdminController::class);\n});\n```\n\nCreate your own: `php artisan make:middleware CheckRole`",
            'migration'             => "**Migrations** are version-controlled database schema changes. They let you define your table structure in PHP and run it on any environment.\n\n```php\nSchema::create('projects', function (Blueprint \$table) {\n    \$table->id();\n    \$table->foreignId('user_id')->constrained()->cascadeOnDelete();\n    \$table->string('name');\n    \$table->timestamps();\n});\n```\n\n**Commands:**\n```bash\nphp artisan migrate          # run pending migrations\nphp artisan migrate:rollback # undo last batch\nphp artisan migrate:fresh    # drop all + re-run\n```",
            'dependency injection'  => "**Dependency Injection (DI)** is a design pattern where a class receives its dependencies from outside rather than creating them itself.\n\nLaravel's service container handles DI automatically:\n```php\nclass ProjectController extends Controller\n{\n    public function __construct(\n        private readonly ProjectService \$service  // injected automatically\n    ) {}\n\n    public function store(Request \$request): JsonResponse\n    {\n        return \$this->service->create(\$request->validated());\n    }\n}\n```\n\nBenefits: easier testing (swap real service for a mock), loose coupling, reusable code.",
            'route'                 => "**Routes** in Laravel define which URL maps to which controller action.\n\n```php\n// Basic routes\nRoute::get('/users', [UserController::class, 'index']);\nRoute::post('/users', [UserController::class, 'store']);\nRoute::patch('/users/{user}', [UserController::class, 'update']);\nRoute::delete('/users/{user}', [UserController::class, 'destroy']);\n\n// Route groups with middleware\nRoute::middleware('auth')->prefix('api')->group(function () {\n    Route::get('/profile', [ProfileController::class, 'show']);\n});\n```\n\nList all routes: `php artisan route:list`",
            'validation'            => "Laravel provides powerful **request validation**:\n\n```php\n// Inline in controller\n\$data = \$request->validate([\n    'name'  => ['required', 'string', 'max:255'],\n    'email' => ['required', 'email', 'unique:users'],\n    'age'   => ['nullable', 'integer', 'min:18'],\n]);\n\n// Or use a Form Request class\nphp artisan make:request StoreUserRequest\n```\n\nIf validation fails, Laravel automatically returns a 422 response with error messages. In your frontend, check the `errors` object in the response body.",

            // ── PHP ────────────────────────────────────────────────────────
            'trait'                 => "A **trait** in PHP is a way to reuse methods across multiple classes that don't share a parent class.\n\n```php\ntrait Timestamps {\n    public function createdAt(): string {\n        return date('Y-m-d', \$this->created_at);\n    }\n}\n\nclass User {\n    use Timestamps;\n}\n\nclass Project {\n    use Timestamps;  // same method, no inheritance needed\n}\n```\n\nLaravel uses traits extensively — `HasFactory`, `Notifiable`, `SoftDeletes` are all traits.",
            'interface'             => "An **interface** in PHP defines a contract — a set of methods a class must implement.\n\n```php\ninterface Storable {\n    public function save(): bool;\n    public function delete(): bool;\n}\n\nclass Project implements Storable {\n    public function save(): bool { /* ... */ }\n    public function delete(): bool { /* ... */ }\n}\n```\n\nInterfaces enable **polymorphism** — you can swap implementations without changing the code that uses them. Laravel's contracts (in `Illuminate\\Contracts`) are all interfaces.",
            'arrow function'        => "**Arrow functions** (PHP 7.4+) are a shorter syntax for closures that automatically capture variables from the outer scope:\n\n```php\n// Regular closure\n\$multiplier = 3;\n\$fn = function (\$n) use (\$multiplier) { return \$n * \$multiplier; };\n\n// Arrow function — captures \$multiplier automatically\n\$fn = fn(\$n) => \$n * \$multiplier;\n\n// Common in Laravel collections\n\$names = User::all()->map(fn(\$u) => \$u->name);\n```",

            // ── JavaScript ─────────────────────────────────────────────────
            'promise'               => "A **Promise** in JavaScript represents a value that will be available in the future (async operation).\n\n```js\nfetch('/api/users')\n  .then(res => res.json())\n  .then(data => console.log(data))\n  .catch(err => console.error(err));\n```\n\nModern code uses **async/await** instead:\n```js\nasync function loadUsers() {\n    try {\n        const res  = await fetch('/api/users');\n        const data = await res.json();\n        console.log(data);\n    } catch (err) {\n        console.error(err);\n    }\n}\n```",
            'event loop'            => "The **event loop** is what makes JavaScript non-blocking despite being single-threaded.\n\n**How it works:**\n1. JS runs synchronous code on the **call stack**\n2. Async operations (fetch, setTimeout) are handed to **Web APIs**\n3. When they complete, callbacks go to the **callback queue**\n4. The event loop moves them to the call stack when it's empty\n\n```js\nconsole.log('1');           // runs first\nsetTimeout(() => console.log('2'), 0);  // runs last\nconsole.log('3');           // runs second\n// Output: 1, 3, 2\n```",
            'closure'               => "A **closure** is a function that remembers the variables from its outer scope even after that scope has finished.\n\n```js\nfunction makeCounter() {\n    let count = 0;          // captured by the closure\n    return function() {\n        return ++count;\n    };\n}\n\nconst counter = makeCounter();\ncounter(); // 1\ncounter(); // 2  — count is remembered!\n```\n\nClosures are used everywhere in JS: event listeners, callbacks, module patterns, and React hooks.",

            // ── React ──────────────────────────────────────────────────────
            'hook'                  => "**React Hooks** let you use state and lifecycle features in function components.\n\n```jsx\nimport { useState, useEffect } from 'react';\n\nfunction Counter() {\n    const [count, setCount] = useState(0);  // state hook\n\n    useEffect(() => {\n        document.title = `Count: \${count}`;  // side effect\n    }, [count]);  // runs when count changes\n\n    return <button onClick={() => setCount(c => c + 1)}>{count}</button>;\n}\n```\n\n**Common hooks:** `useState`, `useEffect`, `useContext`, `useRef`, `useMemo`, `useCallback`.",
            'state'                 => "**State** in React is data that, when changed, causes the component to re-render.\n\n```jsx\nconst [user, setUser] = useState(null);\nconst [loading, setLoading] = useState(true);\n\nasync function loadUser() {\n    setLoading(true);\n    const data = await fetchUser();\n    setUser(data);\n    setLoading(false);\n}\n\nif (loading) return <Spinner />;\nreturn <div>{user.name}</div>;\n```\n\n**Rule:** never mutate state directly. Always call the setter function (`setUser`, `setLoading`).",

            // ── Python ─────────────────────────────────────────────────────
            'list comprehension'    => "**List comprehensions** are a concise way to create lists in Python:\n\n```python\n# Traditional loop\nsquares = []\nfor x in range(10):\n    squares.append(x ** 2)\n\n# List comprehension — same result, one line\nsquares = [x ** 2 for x in range(10)]\n\n# With condition\nevens = [x for x in range(20) if x % 2 == 0]\n\n# Dict comprehension\nuser_map = {u.id: u.name for u in users}\n```",
            'decorator'             => "A **decorator** in Python is a function that wraps another function to add behaviour.\n\n```python\nimport functools\n\ndef require_auth(func):\n    @functools.wraps(func)\n    def wrapper(*args, **kwargs):\n        if not current_user.is_authenticated:\n            raise PermissionError('Login required')\n        return func(*args, **kwargs)\n    return wrapper\n\n@require_auth\ndef delete_project(project_id):\n    Project.objects.get(id=project_id).delete()\n```\n\nDjango and Flask use decorators heavily: `@login_required`, `@app.route('/')`, `@property`.",

            // ── Git ────────────────────────────────────────────────────────
            'git rebase'            => "**`git rebase`** moves or replays your commits on top of another branch, creating a **linear history**.\n\n```bash\n# You're on feature branch, want to incorporate latest main\ngit checkout feature-branch\ngit rebase main\n# Your feature commits are replayed on top of main\n```\n\n**vs merge:** `merge` creates a merge commit and preserves branch history. `rebase` rewrites history for a cleaner log.\n\n**Golden rule:** never rebase commits that have been pushed to a shared remote branch.",
            'git reset'             => "**`git reset`** moves the HEAD pointer and optionally modifies the index/working tree.\n\n```bash\ngit reset --soft HEAD~1   # undo last commit, keep changes staged\ngit reset --mixed HEAD~1  # undo last commit, unstage changes (default)\ngit reset --hard HEAD~1   # undo last commit AND discard changes (destructive!)\n```\n\n**Safer alternative for shared branches:** `git revert HEAD` creates a new commit that undoes the previous one without rewriting history.",

            // ── Docker ────────────────────────────────────────────────────
            'dockerfile'            => "A **Dockerfile** is a script of instructions that builds a Docker image.\n\n```dockerfile\nFROM php:8.3-fpm\n\n# Install extensions\nRUN docker-php-ext-install pdo pdo_mysql\n\n# Set working directory\nWORKDIR /var/www\n\n# Copy source code\nCOPY . .\n\n# Install Composer dependencies\nRUN curl -sS https://getcomposer.org/installer | php && \\\n    php composer.phar install --no-dev\n\nEXPOSE 9000\nCMD [\"php-fpm\"]\n```\n\nBuild it: `docker build -t my-laravel-app .`\nRun it: `docker run -p 9000:9000 my-laravel-app`",
            'docker compose'        => "**Docker Compose** lets you define and run multi-container apps with a single YAML file.\n\n```yaml\n# docker-compose.yml\nservices:\n  app:\n    build: .\n    ports: [\"8000:8000\"]\n    depends_on: [db]\n    environment:\n      DB_HOST: db\n\n  db:\n    image: mysql:8\n    environment:\n      MYSQL_DATABASE: projectport\n      MYSQL_ROOT_PASSWORD: secret\n    volumes:\n      - db_data:/var/lib/mysql\n\nvolumes:\n  db_data:\n```\n\nStart everything: `docker compose up -d`\nStop: `docker compose down`",
        ];

        // Exact keyword match first (longest match wins).
        $best      = null;
        $bestLen   = 0;
        foreach ($kb as $keyword => $answer) {
            if (str_contains($q, $keyword) && strlen($keyword) > $bestLen) {
                $best    = $answer;
                $bestLen = strlen($keyword);
            }
        }

        if ($best) {
            return $best;
        }

        // Topic-level fallbacks — give useful pointers even for unknown questions.
        $topicFallbacks = [
            'Database' => "Great question about **{$topic}**! Here are some core concepts you might be asking about:\n\n- **Server**: MySQL runs as a background service (port 3306). Tools: XAMPP, Laragon, or `brew services start mysql`\n- **Queries**: `SELECT`, `INSERT`, `UPDATE`, `DELETE`\n- **Joins**: `INNER JOIN`, `LEFT JOIN` to combine tables\n- **Indexes**: speed up queries on frequently-searched columns\n- **Transactions**: `BEGIN` / `COMMIT` / `ROLLBACK` for atomic operations\n\nAsk me about any of these specifically and I'll give you a detailed answer!",
            'Laravel'  => "Here are key **Laravel** concepts related to your question:\n\n- **Routing**: `Route::get/post/patch/delete()` in `routes/api.php`\n- **Eloquent ORM**: interact with databases using PHP model classes\n- **Middleware**: code that runs before/after requests\n- **Migrations**: version-controlled database schema changes\n- **Validation**: `\$request->validate([...])` or Form Requests\n- **Artisan**: `php artisan make:model`, `migrate`, `route:list`\n\nTry asking about a specific concept for a detailed explanation with code!",
            'PHP'      => "Here are important **PHP** concepts that might answer your question:\n\n- **Classes & Objects**: OOP with `class`, `extends`, `implements`\n- **Traits**: reuse methods across unrelated classes\n- **Interfaces**: define contracts classes must fulfil\n- **Arrow functions**: `fn(\$x) => \$x * 2` (PHP 7.4+)\n- **Match expressions**: cleaner switch statements (PHP 8.0+)\n- **Nullsafe operator**: `\$user?->profile?->avatar` (PHP 8.0+)\n\nAsk me about any specific concept for code examples!",
            'JavaScript' => "Here are core **JavaScript** concepts that may help:\n\n- **Promises & async/await**: handle asynchronous operations\n- **Event loop**: how JS handles non-blocking I/O\n- **Closures**: functions that remember their outer scope\n- **Destructuring**: `const { name, email } = user;`\n- **Spread/rest**: `[...arr]`, `function(...args)`\n- **Modules**: `import` / `export`\n\nAsk about any specific topic for a detailed breakdown with examples!",
            'React'    => "Here are key **React** concepts relevant to your question:\n\n- **Hooks**: `useState`, `useEffect`, `useContext`, `useRef`\n- **Props**: pass data from parent to child components\n- **State**: data that triggers re-renders when changed\n- **Virtual DOM**: React's efficient update mechanism\n- **JSX**: HTML-like syntax compiled to `React.createElement()`\n- **Component lifecycle**: mount → update → unmount\n\nAsk about any specific concept for examples!",
            'Python'   => "Here are important **Python** concepts that might help:\n\n- **List comprehensions**: `[x**2 for x in range(10)]`\n- **Decorators**: `@login_required`, `@property`\n- **Generators**: memory-efficient iterators with `yield`\n- **Context managers**: `with open('file') as f:`\n- **Type hints**: `def greet(name: str) -> str:`\n- **Virtual environments**: `python -m venv venv`\n\nTry a more specific question for a detailed code example!",
            'Git'      => "Here are key **Git** concepts that may answer your question:\n\n- **Commit**: snapshot of your code — `git commit -m 'message'`\n- **Branch**: independent line of work — `git checkout -b feature`\n- **Merge**: combine branches — `git merge feature`\n- **Rebase**: replay commits on top of another branch\n- **Reset**: undo commits (`--soft`, `--mixed`, `--hard`)\n- **Stash**: temporarily save uncommitted changes — `git stash`\n\nAsk about a specific command for detailed examples!",
            'DevOps'   => "Here are core **DevOps / Docker** concepts:\n\n- **Dockerfile**: recipe to build a container image\n- **Docker Compose**: run multi-container apps with one YAML file\n- **Image vs Container**: image = blueprint, container = running instance\n- **Volumes**: persist data outside the container lifecycle\n- **Networking**: containers talk to each other by service name\n- **CI/CD**: automate build → test → deploy pipelines\n\nAsk about a specific concept for a working example!",
        ];

        if (isset($topicFallbacks[$topic])) {
            return $topicFallbacks[$topic];
        }

        return "I don't have a specific answer for that question in my knowledge base yet, but here's how to find it:\n\n"
            . "1. **Official docs**: search \"{$topic} " . substr($question, 0, 60) . "\" on the official documentation site\n"
            . "2. **MDN / php.net / laravel.com**: excellent references for web technologies\n"
            . "3. **Stack Overflow**: most common questions already have detailed answers\n\n"
            . "You can also enable the **OpenAI-powered AI** by adding `OPENAI_API_KEY=sk-...` to your `.env` file for unrestricted answers on any topic.";
    }
}
