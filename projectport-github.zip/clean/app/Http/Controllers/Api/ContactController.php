<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactRequest;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Recruiter → Student contact requests and student inbox.
 * Also handles project purchase enquiries.
 */
class ContactController extends Controller
{
    // ── helpers ──────────────────────────────────────────────────────────

    private function formatRequest(ContactRequest $r): array
    {
        return [
            'id'          => $r->id,
            'type'        => $r->type,
            'status'      => $r->status,
            'message'     => $r->message,
            'reply'       => $r->reply,
            'read_at'     => $r->read_at?->toIso8601String(),
            'replied_at'  => $r->replied_at?->toIso8601String(),
            'created_at'  => $r->created_at->toIso8601String(),
            'project'     => $r->project ? [
                'id'    => $r->project->id,
                'name'  => $r->project->name,
                'price' => $r->project->price,
            ] : null,
            'sender'    => $r->sender ? [
                'id'           => $r->sender->id,
                'name'         => $r->sender->name,
                'email'        => $r->sender->email,
                'role'         => $r->sender->role,
            ] : null,
            'recipient' => $r->recipient ? [
                'id'    => $r->recipient->id,
                'name'  => $r->recipient->name,
                'email' => $r->recipient->email,
            ] : null,
        ];
    }

    // ── send ─────────────────────────────────────────────────────────────

    /**
     * POST /contact
     * Any authenticated user can send a contact request to a student.
     * Recruiters use this to hire or enquire about a project purchase.
     */
    public function send(Request $request): JsonResponse
    {
        /** @var User $sender */
        $sender = $request->user();

        $data = $request->validate([
            'recipient_id' => ['required', 'integer', 'exists:users,id'],
            'project_id'   => ['nullable', 'integer', 'exists:projects,id'],
            'type'         => ['required', 'in:hire,purchase,general'],
            'message'      => ['required', 'string', 'min:10', 'max:2000'],
        ]);

        // Prevent contacting yourself.
        if ((int) $data['recipient_id'] === $sender->getKey()) {
            return new JsonResponse(['message' => 'You cannot send a contact request to yourself.'], 422);
        }

        $recipient = User::findOrFail($data['recipient_id']);

        // If type is purchase, make sure the project is actually for sale.
        if ($data['type'] === 'purchase' && isset($data['project_id'])) {
            $project = Project::find($data['project_id']);
            if (! $project || ! $project->for_sale) {
                return new JsonResponse(['message' => 'This project is not listed for sale.'], 422);
            }
        }

        $contactRequest = ContactRequest::create([
            'sender_id'    => $sender->getKey(),
            'recipient_id' => $data['recipient_id'],
            'project_id'   => $data['project_id'] ?? null,
            'type'         => $data['type'],
            'message'      => $data['message'],
            'status'       => ContactRequest::STATUS_PENDING,
        ]);

        $contactRequest->load(['sender', 'recipient', 'project']);

        return new JsonResponse([
            'message' => 'Contact request sent successfully.',
            'request' => $this->formatRequest($contactRequest),
        ], 201);
    }

    // ── inbox (student receives) ──────────────────────────────────────────

    /**
     * GET /contact/inbox
     * The authenticated user's received contact requests, newest first.
     */
    public function inbox(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $status = $request->query('status', 'all'); // all | pending | read | replied

        $query = ContactRequest::with(['sender', 'project'])
            ->where('recipient_id', $user->getKey())
            ->latest();

        if ($status !== 'all') {
            $query->where('status', $status);
        }

        $requests = $query->paginate(20);

        return new JsonResponse([
            'requests'     => $requests->getCollection()->map(fn ($r) => $this->formatRequest($r))->values(),
            'total'        => $requests->total(),
            'current_page' => $requests->currentPage(),
            'last_page'    => $requests->lastPage(),
            'unread_count' => ContactRequest::where('recipient_id', $user->getKey())
                ->where('status', ContactRequest::STATUS_PENDING)
                ->count(),
        ]);
    }

    // ── outbox (recruiter sent) ───────────────────────────────────────────

    /**
     * GET /contact/outbox
     * The authenticated user's sent contact requests.
     */
    public function outbox(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $requests = ContactRequest::with(['recipient', 'project'])
            ->where('sender_id', $user->getKey())
            ->latest()
            ->paginate(20);

        return new JsonResponse([
            'requests'     => $requests->getCollection()->map(fn ($r) => $this->formatRequest($r))->values(),
            'total'        => $requests->total(),
            'current_page' => $requests->currentPage(),
            'last_page'    => $requests->lastPage(),
        ]);
    }

    // ── mark read ─────────────────────────────────────────────────────────

    /**
     * PATCH /contact/{request}/read
     * Mark a received request as read.
     */
    public function markRead(Request $request, ContactRequest $contactRequest): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        if ($contactRequest->recipient_id !== $user->getKey()) {
            return new JsonResponse(['message' => 'Not found.'], 404);
        }

        if ($contactRequest->status === ContactRequest::STATUS_PENDING) {
            $contactRequest->status  = ContactRequest::STATUS_READ;
            $contactRequest->read_at = now();
            $contactRequest->save();
        }

        $contactRequest->load(['sender', 'project']);

        return new JsonResponse(['request' => $this->formatRequest($contactRequest)]);
    }

    // ── reply ─────────────────────────────────────────────────────────────

    /**
     * POST /contact/{request}/reply
     * The recipient student sends one reply to the contact request.
     */
    public function reply(Request $request, ContactRequest $contactRequest): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        if ($contactRequest->recipient_id !== $user->getKey()) {
            return new JsonResponse(['message' => 'Not found.'], 404);
        }

        $data = $request->validate([
            'reply' => ['required', 'string', 'min:5', 'max:2000'],
        ]);

        $contactRequest->reply       = $data['reply'];
        $contactRequest->status      = ContactRequest::STATUS_REPLIED;
        $contactRequest->replied_at  = now();
        $contactRequest->save();

        $contactRequest->load(['sender', 'recipient', 'project']);

        return new JsonResponse([
            'message' => 'Reply sent.',
            'request' => $this->formatRequest($contactRequest),
        ]);
    }

    // ── close ─────────────────────────────────────────────────────────────

    /**
     * DELETE /contact/{request}
     * Either party can close/delete the request.
     */
    public function close(Request $request, ContactRequest $contactRequest): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $isParty = $contactRequest->sender_id    === $user->getKey()
                || $contactRequest->recipient_id === $user->getKey();

        if (! $isParty) {
            return new JsonResponse(['message' => 'Not found.'], 404);
        }

        $contactRequest->delete();

        return new JsonResponse(['message' => 'Request closed.']);
    }
}
