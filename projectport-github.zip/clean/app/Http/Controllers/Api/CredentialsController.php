<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\EmailVerificationService;
use App\Services\RefreshTokenService;
use App\Support\ApiError;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Implementation Checklist: session invalidation on password change or email
 * change. Bumping token_version invalidates every issued access token and all
 * live refresh tokens are revoked, which also logs the user out of every device.
 */
class CredentialsController extends Controller
{
    public function __construct(
        private readonly RefreshTokenService $refreshTokens,
        private readonly EmailVerificationService $emailVerification,
    ) {}

    public function update(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $data = $request->validate([
            'current_password' => ['required', 'string'],
            'email' => ['sometimes', 'email:rfc'],
            'password' => ['sometimes', 'string', 'min:8'],
        ]);

        if (! Hash::check($data['current_password'], $user->password)) {
            throw ApiException::unauthenticated(
                'The current password is incorrect.',
                ApiError::INVALID_CREDENTIALS,
            );
        }

        $emailChanged = isset($data['email']) && $data['email'] !== $user->email;

        if ($emailChanged && User::where('email', $data['email'])->exists()) {
            throw ApiException::conflict(
                'That email address is already registered.',
                ApiError::EMAIL_ALREADY_REGISTERED,
            );
        }

        DB::transaction(function () use ($user, $data, $emailChanged): void {
            $attributes = ['token_version' => $user->token_version + 1];

            if ($emailChanged) {
                $attributes['email'] = $data['email'];
                // FR-02: a new address must be verified again.
                $attributes['email_verified_at'] = null;
            }

            if (isset($data['password'])) {
                $attributes['password'] = Hash::make($data['password']);
            }

            $user->forceFill($attributes)->save();

            $this->refreshTokens->revokeAllForUser($user);
        });

        if ($emailChanged) {
            $this->emailVerification->verify_email($user);
        }

        return new JsonResponse([
            'message' => 'Credentials updated. Please log in again.',
            'user' => new UserResource($user->refresh()),
        ]);
    }
}
