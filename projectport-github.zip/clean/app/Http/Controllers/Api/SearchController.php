<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\SearchRequest;
use App\Http\Resources\ProjectResource;
use App\Http\Resources\UserResource;
use App\Models\Project;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;

/**
 * FR-06: recruiters search for students and their projects by skills and keywords.
 */
class SearchController extends Controller
{
    /**
     * FR-06: search active students by name or skills keyword.
     */
    public function search_students(SearchRequest $request): JsonResponse
    {
        $query = (string) $request->validated()['q'];
        $perPage = (int) ($request->validated()['per_page'] ?? 15);

        $students = User::query()
            // NFR-01 / NFR-04: served by the users(role, status) composite index.
            ->where('role', User::ROLE_STUDENT)
            ->where('status', User::STATUS_ACTIVE)
            ->where(function (Builder $builder) use ($query): void {
                $builder
                    ->where('skills', 'like', '%'.$this->escapeLike($query).'%')
                    ->orWhere('name', 'like', '%'.$this->escapeLike($query).'%');
            })
            ->with(['projects' => fn ($projects) => $projects->latest()])
            ->orderBy('id')
            ->paginate($perPage);

        return new JsonResponse([
            'query' => $query,
            'students' => UserResource::collection($students->items()),
            'total' => $students->total(),
            'per_page' => $students->perPage(),
            'current_page' => $students->currentPage(),
        ]);
    }

    /**
     * FR-06: search the projects of active students by project name or by the
     * owning student's skills.
     */
    public function search_projects(SearchRequest $request): JsonResponse
    {
        $query = (string) $request->validated()['q'];
        $perPage = (int) ($request->validated()['per_page'] ?? 15);

        $escaped = $this->escapeLike($query);

        $projects = Project::query()
            ->whereHas('user', fn (Builder $builder) => $builder
                ->where('role', User::ROLE_STUDENT)
                ->where('status', User::STATUS_ACTIVE))
            ->where(function (Builder $builder) use ($escaped): void {
                $builder
                    ->where('name', 'like', '%'.$escaped.'%')
                    ->orWhereHas('user', fn (Builder $owner) => $owner
                        ->where('skills', 'like', '%'.$escaped.'%'));
            })
            ->with('user')
            ->orderBy('id')
            ->paginate($perPage);

        return new JsonResponse([
            'query' => $query,
            'projects' => ProjectResource::collection($projects->items()),
            'total' => $projects->total(),
            'per_page' => $projects->perPage(),
            'current_page' => $projects->currentPage(),
        ]);
    }

    /** Neutralise LIKE wildcards supplied by the caller. */
    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $value);
    }
}
