<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Http\Requests\LoginUserRequest;
use App\Http\Requests\RegisterUserRequest;
use App\Http\Resources\UserResource;
use App\Models\Registration;
use App\Models\User;
use App\Services\EmailVerificationService;
use App\Services\JwtService;
use App\Services\RefreshTokenService;
use App\Support\ApiError;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * FR-01 (register_user, verify_email), FR-02 (verify_email_address), FR-03 (login_user).
 */
class AuthController extends Controller
{
    public function __construct(
        private readonly EmailVerificationService $emailVerification,
        private readonly JwtService $jwt,
        private readonly RefreshTokenService $refreshTokens,
    ) {}

    /**
     * FR-01: register a user with a valid email address and send the
     * verification email.
     */
    public function register_user(RegisterUserRequest $request): JsonResponse
    {
        $data = $request->validated();

        // Error Response Contract: 409 when the resource already exists.
        if (User::where('email', $data['email'])->exists()) {
            throw ApiException::conflict(
                'That email address is already registered.',
                ApiError::EMAIL_ALREADY_REGISTERED,
            );
        }

        $user = DB::transaction(function () use ($data): User {
            $user = User::create([
                'email' => $data['email'],
                'password' => $data['password'],
                'role' => $data['role'],
                'name' => $data['name'] ?? null,
                'status' => User::STATUS_PENDING,
            ]);

            // FR-04: the admin approval queue is fed by this record.
            Registration::create([
                'user_id' => $user->getKey(),
                'approved' => null,
            ]);

            return $user;
        });

        // FR-01: "then the user receives a verification email".
        $this->emailVerification->verify_email($user);

        return new JsonResponse([
            'message' => 'Registration received. Check your inbox for the verification email.',
            'user' => new UserResource($user),
        ], 201);
    }

    /**
     * FR-02: verify the email address behind a verification link.
     */
    public function verify_email_address(string $token): JsonResponse
    {
        $user = $this->emailVerification->consume($token);

        return new JsonResponse([
            'message' => 'Email address verified.',
            'user' => new UserResource($user),
        ]);
    }

    /**
     * FR-01 / FR-02: send the verification email again.
     *
     * Always answers the same way so the endpoint cannot be used to discover
     * which email addresses are registered.
     */
    public function resend_verification_email(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email:rfc'],
        ]);

        $user = User::where('email', $data['email'])->first();

        if ($user !== null && ! $user->hasVerifiedEmail()) {
            $this->emailVerification->verify_email($user);
        }

        return new JsonResponse([
            'message' => 'If that address needs verifying, a new verification email is on its way.',
        ]);
    }

    /**
     * FR-03: log a user in with a valid email address and password.
     */
    public function login_user(LoginUserRequest $request): JsonResponse
    {
        $data = $request->validated();

        $user = User::where('email', $data['email'])->first();

        if ($user === null || ! Hash::check($data['password'], $user->password)) {
            throw ApiException::unauthenticated(
                'The email address or password is incorrect.',
                ApiError::INVALID_CREDENTIALS,
            );
        }

        // FR-02: registration is only complete once the email is verified — unless
        // an admin has already approved the account (FR-04). An approved account has
        // been vetted by a human, so it is never asked to confirm its address again.
        if (! $user->hasVerifiedEmail() && ! $user->isActive()) {
            throw ApiException::businessRule(
                ApiError::EMAIL_NOT_VERIFIED,
                'Verify your email address before logging in.',
            );
        }

        return new JsonResponse([
            'message' => 'Logged in.',
            'user' => new UserResource($user),
            ...$this->tokenPayload($user),
        ]);
    }

    /**
     * Implementation Checklist: refresh token rotation — the presented refresh
     * token is invalidated and replaced on every use.
     */
    public function refresh(Request $request): JsonResponse
    {
        $presented = (string) $request->input('refresh_token', '');

        if ($presented === '') {
            throw ApiException::validation('A refresh token is required.', 'refresh_token');
        }

        ['user' => $user, 'refresh_token' => $rotated] = $this->refreshTokens->rotate($presented);

        return new JsonResponse([
            'message' => 'Token refreshed.',
            'access_token' => $this->jwt->issueAccessToken($user),
            'token_type' => 'Bearer',
            'expires_in' => $this->jwt->accessTokenTtlSeconds(),
            'refresh_token' => $rotated,
        ]);
    }

    /** Revoke every refresh token held by the authenticated user. */
    public function logout(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $this->refreshTokens->revokeAllForUser($user);

        return new JsonResponse(['message' => 'Logged out.']);
    }

    /**
     * @return array<string, mixed>
     */
    private function tokenPayload(User $user): array
    {
        return [
            'access_token' => $this->jwt->issueAccessToken($user),
            'token_type' => 'Bearer',
            'expires_in' => $this->jwt->accessTokenTtlSeconds(),
            'refresh_token' => $this->refreshTokens->issue($user),
        ];
    }
}
