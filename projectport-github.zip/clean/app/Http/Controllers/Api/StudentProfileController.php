<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\ResumePhotoStorageService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * FR-05: students create and manage their profiles.
 * Recruiter Search journey step 2: recruiters open a student's profile.
 */
class StudentProfileController extends Controller
{
    public function __construct(private readonly ResumePhotoStorageService $resumePhoto) {}

    /** FR-05: the authenticated student's own profile, including uploaded projects. */
    public function show(Request $request): JsonResponse
    {
        /** @var User $student */
        $student = $request->user();

        $student->load(['projects' => fn ($query) => $query->latest()]);

        return new JsonResponse(['student' => new UserResource($student)]);
    }

    /** FR-05: update the profile fields a student manages, including an optional resume photo. */
    public function update(Request $request): JsonResponse
    {
        /** @var User $student */
        $student = $request->user();

        $data = $request->validate([
            'name'         => ['sometimes', 'string', 'max:255'],
            'skills'       => ['sometimes', 'nullable', 'string', 'max:2000'],
            'resume_photo' => [
                'sometimes',
                'nullable',
                'image',
                'extensions:'.implode(',', (array) config('projectport.resume_photo.allowed_extensions')),
                'max:'.(int) config('projectport.resume_photo.max_kilobytes'),
            ],
        ]);

        // Handle resume photo upload separately — it is not a plain scalar value.
        if ($request->hasFile('resume_photo')) {
            $data['resume_photo'] = $this->resumePhoto->store($student, $request->file('resume_photo'));
        } elseif (array_key_exists('resume_photo', $data) && $data['resume_photo'] === null) {
            // Explicit null means the student wants to remove their photo.
            if ($student->resume_photo) {
                $this->resumePhoto->delete($student->resume_photo);
            }
            $data['resume_photo'] = null;
        } else {
            // Field not present — leave the stored value untouched.
            unset($data['resume_photo']);
        }

        $student->fill($data)->save();

        $student->load(['projects' => fn ($query) => $query->latest()]);

        return new JsonResponse([
            'message' => 'Profile updated.',
            'student' => new UserResource($student),
        ]);
    }

    /**
     * FR-05 / FR-06: a student profile as seen from a search result.
     */
    public function showStudent(User $student): JsonResponse
    {
        if (! $student->hasRole(User::ROLE_STUDENT) || ! $student->isActive()) {
            throw ApiException::notFound('Student not found.');
        }

        $student->load(['projects' => fn ($query) => $query->latest()]);

        return new JsonResponse(['student' => new UserResource($student)]);
    }
}
