<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Http\Resources\RegistrationResource;
use App\Http\Resources\UserResource;
use App\Models\Registration;
use App\Models\User;
use App\Support\ApiError;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * FR-04: admins approve or reject student and recruiter registrations.
 */
class AdminRegistrationController extends Controller
{
    /**
     * FR-04: the queue an admin decides on — pending registrations by default,
     * filterable by state and searchable by name or email.
     */
    public function index(Request $request): JsonResponse
    {
        $filters = $request->validate([
            'state' => ['sometimes', 'in:pending,approved,rejected,all'],
            'q' => ['sometimes', 'nullable', 'string', 'max:100'],
            'per_page' => ['sometimes', 'integer', 'min:1', 'max:50'],
        ]);

        $state = $filters['state'] ?? 'pending';
        $search = trim((string) ($filters['q'] ?? ''));

        $registrations = Registration::query()
            // NFR-01 / NFR-04: served by the registrations(approved, created_at) index.
            ->when($state === 'pending', fn ($query) => $query->whereNull('approved'))
            ->when($state === 'approved', fn ($query) => $query->where('approved', true))
            ->when($state === 'rejected', fn ($query) => $query->where('approved', false))
            ->when($search !== '', fn ($query) => $query->whereHas(
                'user',
                fn ($user) => $user
                    ->where('email', 'like', '%'.$this->escapeLike($search).'%')
                    ->orWhere('name', 'like', '%'.$this->escapeLike($search).'%'),
            ))
            ->with(['user', 'admin'])
            ->latest('id')
            ->paginate((int) ($filters['per_page'] ?? 15));

        return new JsonResponse([
            'state' => $state,
            'registrations' => RegistrationResource::collection($registrations->items()),
            'total' => $registrations->total(),
            'per_page' => $registrations->perPage(),
            'current_page' => $registrations->currentPage(),
            'last_page' => $registrations->lastPage(),
            'counts' => [
                'pending' => Registration::whereNull('approved')->count(),
                'approved' => Registration::where('approved', true)->count(),
                'rejected' => Registration::where('approved', false)->count(),
                'students' => User::where('role', User::ROLE_STUDENT)->count(),
                'recruiters' => User::where('role', User::ROLE_RECRUITER)->count(),
            ],
        ]);
    }

    /**
     * FR-04: approving a pending registration makes the user's account active.
     */
    public function approve_registration(Request $request, Registration $registration): JsonResponse
    {
        $user = $this->decide($request, $registration, approved: true, status: User::STATUS_ACTIVE);

        return new JsonResponse([
            'message' => 'Registration approved.',
            'user' => new UserResource($user),
        ]);
    }

    /**
     * FR-04: rejecting a pending registration makes the user's account inactive.
     */
    public function reject_registration(Request $request, Registration $registration): JsonResponse
    {
        $user = $this->decide($request, $registration, approved: false, status: User::STATUS_INACTIVE);

        return new JsonResponse([
            'message' => 'Registration rejected.',
            'user' => new UserResource($user),
        ]);
    }

    private function decide(Request $request, Registration $registration, bool $approved, string $status): User
    {
        // Error Response Contract: 409 on a concurrent / repeated state change.
        if (! $registration->isPending()) {
            throw ApiException::conflict(
                'This registration has already been decided.',
                ApiError::REGISTRATION_ALREADY_DECIDED,
            );
        }

        /** @var User $admin */
        $admin = $request->user();

        return DB::transaction(function () use ($registration, $approved, $status, $admin): User {
            $registration->update([
                'approved' => $approved,
                'admin_id' => $admin->getKey(),
                'decided_at' => Carbon::now(),
            ]);

            $user = $registration->user;
            $attributes = ['status' => $status];

            // FR-02 / FR-04: an admin approving an account has vetted the person
            // behind that address, so approval also settles email verification.
            // Without this the approved user is active but still locked out of login.
            if ($approved && ! $user->hasVerifiedEmail()) {
                $attributes['email_verified_at'] = Carbon::now();
                $attributes['email_verification_token'] = null;
                $attributes['email_verification_expires_at'] = null;
            }

            $user->forceFill($attributes)->save();

            return $user->refresh();
        });
    }

    /** Neutralise LIKE wildcards supplied by the caller. */
    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $value);
    }
}
