<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateProjectRequest;
use App\Http\Requests\UpdateProjectRequest;
use App\Http\Resources\ProjectResource;
use App\Models\Project;
use App\Models\User;
use App\Services\ScreenshotStorageService;
use App\Services\SourceCodeStorageService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/**
 * FR-05: students upload projects and source code onto their profile.
 */
class ProjectController extends Controller
{
    public function __construct(
        private readonly SourceCodeStorageService $sourceCode,
        private readonly ScreenshotStorageService $screenshots,
    ) {}

    /**
     * FR-05: create a project for the authenticated student, storing the
     * uploaded source code archive and any optional screenshots alongside it.
     */
    public function create_project(CreateProjectRequest $request): JsonResponse
    {
        /** @var User $student */
        $student = $request->user();

        $data = $request->validated();

        $storedPath = $this->sourceCode->upload_source_code($student, $request->file('source_code'));

        $screenshotPaths = [];
        if ($request->hasFile('screenshots')) {
            $screenshotPaths = $this->screenshots->storeMany(
                $student,
                $request->file('screenshots'),
            );
        }

        $project = Project::create([
            'user_id'     => $student->getKey(),
            'name'        => $data['project_name'],
            'source_code' => $storedPath,
            'screenshots' => $screenshotPaths ?: null,
        ]);

        return new JsonResponse([
            'message' => 'Project uploaded.',
            'project' => new ProjectResource($project),
        ], 201);
    }

    /**
     * FR-05: update a project's name and/or replace its screenshots.
     * Only the owning student may update their own project.
     */
    public function update_project(UpdateProjectRequest $request, Project $project): JsonResponse
    {
        /** @var User $student */
        $student = $request->user();

        // Ownership check — students may only edit their own projects.
        if ($project->user_id !== $student->getKey()) {
            return new JsonResponse(['message' => 'Not found.'], 404);
        }

        $data = $request->validated();

        if (isset($data['project_name'])) {
            $project->name = $data['project_name'];
        }

        // When new screenshots are uploaded, delete the old ones and replace them.
        if ($request->hasFile('screenshots')) {
            $this->screenshots->deleteForProject($project);
            $project->screenshots = $this->screenshots->storeMany(
                $student,
                $request->file('screenshots'),
            );
        } elseif (array_key_exists('screenshots', $data) && $data['screenshots'] === null) {
            // Explicit null clears all screenshots.
            $this->screenshots->deleteForProject($project);
            $project->screenshots = null;
        }

        $project->save();

        return new JsonResponse([
            'message' => 'Project updated.',
            'project' => new ProjectResource($project),
        ]);
    }

    /**
     * FR-05: delete a project and all its stored files.
     * Only the owning student may delete their own project.
     */
    public function delete_project(Request $request, Project $project): JsonResponse
    {
        /** @var User $student */
        $student = $request->user();

        if ($project->user_id !== $student->getKey()) {
            return new JsonResponse(['message' => 'Not found.'], 404);
        }

        // Remove all screenshots from storage before deleting the record.
        $this->screenshots->deleteForProject($project);

        // Remove the source code archive.
        if ($project->source_code && $this->sourceCode->exists($project->source_code)) {
            Storage::disk($this->sourceCode->disk())->delete($project->source_code);
        }

        $project->delete();

        return new JsonResponse(['message' => 'Project deleted.'], 200);
    }
}
