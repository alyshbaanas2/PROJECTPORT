<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * NFR-02: enforce HTTPS-only connections and emit
 * `Strict-Transport-Security: max-age=31536000; includeSubDomains`.
 */
class ForceHttps
{
    public function handle(Request $request, Closure $next): Response
    {
        /** @var Response $response */
        $response = $next($request);

        if ((bool) config('projectport.security.force_https')) {
            $maxAge = (int) config('projectport.security.hsts_max_age');
            $response->headers->set(
                'Strict-Transport-Security',
                "max-age={$maxAge}; includeSubDomains"
            );
        }

        return $response;
    }
}
