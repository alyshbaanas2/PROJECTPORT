<?php

namespace App\Http\Middleware;

use App\Exceptions\ApiException;
use App\Models\User;
use App\Support\ApiError;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Authorization for protected routes: the authenticated user must hold one of
 * the listed roles (FR-04 admin, FR-05 student, FR-06 recruiter) and hold an
 * active account. Failures return 403 in the Error Response Contract shape.
 */
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user instanceof User) {
            throw ApiException::unauthenticated('An access token is required.');
        }

        // FR-04: only accounts an admin has approved may use protected features.
        if (! $user->isActive()) {
            throw new ApiException(ApiError::ACCOUNT_NOT_ACTIVE, 'Your account is not active.', 403);
        }

        if ($roles !== [] && ! in_array($user->role, $roles, true)) {
            throw ApiException::forbidden('You are not authorised to perform this action.');
        }

        return $next($request);
    }
}
