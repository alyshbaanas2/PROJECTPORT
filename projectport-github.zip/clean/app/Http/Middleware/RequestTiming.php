<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * NFR-01 / NFR-03: monitoring and alerting. Every response carries its duration
 * and any request that exceeds the configured budget (2000 ms) is logged at
 * warning level so an alert can be raised on it.
 */
class RequestTiming
{
    public function handle(Request $request, Closure $next): Response
    {
        $startedAt = microtime(true);

        /** @var Response $response */
        $response = $next($request);

        $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
        $budgetMs = (int) config('projectport.performance.response_budget_ms');

        $response->headers->set('X-Response-Time-Ms', (string) $durationMs);

        if ($durationMs > $budgetMs) {
            Log::warning('Response time budget exceeded', [
                'method' => $request->getMethod(),
                'path' => $request->path(),
                'duration_ms' => $durationMs,
                'budget_ms' => $budgetMs,
            ]);
        }

        return $response;
    }
}
