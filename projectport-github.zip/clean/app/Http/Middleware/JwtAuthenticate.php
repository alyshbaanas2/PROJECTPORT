<?php

namespace App\Http\Middleware;

use App\Exceptions\ApiException;
use App\Models\User;
use App\Services\JwtService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Architecture Decision: auth_strategy = jwt_stateless.
 *
 * Reads the bearer token from the Authorization header (so no CSRF token is
 * required — Implementation Checklist item 2), verifies it, and binds the
 * authenticated user onto the request. Any failure returns 401 in the
 * Error Response Contract shape.
 */
class JwtAuthenticate
{
    public function __construct(private readonly JwtService $jwt) {}

    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->bearerToken();

        if ($token === null || $token === '') {
            throw ApiException::unauthenticated('An access token is required.');
        }

        $claims = $this->jwt->verifyAccessToken($token);

        $user = User::find($claims['sub'] ?? null);

        if ($user === null) {
            throw ApiException::unauthenticated('The access token is invalid.');
        }

        // Implementation Checklist: a password or email change bumps token_version,
        // which invalidates every token issued before the change.
        if ((int) ($claims['tv'] ?? -1) !== (int) $user->token_version) {
            throw ApiException::unauthenticated('The access token is no longer valid.');
        }

        $request->setUserResolver(fn () => $user);

        return $next($request);
    }
}
