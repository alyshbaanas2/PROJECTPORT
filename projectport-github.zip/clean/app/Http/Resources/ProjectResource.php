<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/**
 * Public representation of a Project. FR-05, FR-06, Marketplace.
 */
class ProjectResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $screenshotDisk = (string) config('projectport.screenshots.disk', 'public');
        $resumeDisk     = (string) config('projectport.resume_photo.disk', 'public');

        return [
            'id'          => $this->id,
            'name'        => $this->name,
            'user_id'     => $this->user_id,
            'source_code' => $this->source_code,
            'screenshots' => collect($this->screenshots ?? [])
                ->map(fn (string $path) => Storage::disk($screenshotDisk)->url($path))
                ->values()
                ->all(),
            'created_at'  => $this->created_at?->toIso8601String(),

            // Marketplace: likes.
            'likes_count'   => $this->likes_count_val  ?? ($this->relationLoaded('likes')  ? $this->likes->count()  : 0),
            'user_has_liked' => $this->user_has_liked ?? false,

            // Marketplace: comment count + latest comments with author info.
            'comments_count' => $this->comments_count_val ?? ($this->relationLoaded('comments') ? $this->comments->count() : 0),
            'comments' => $this->relationLoaded('comments')
                ? $this->comments->map(fn ($c) => [
                    'id'         => $c->id,
                    'body'       => $c->body,
                    'created_at' => $c->created_at?->toIso8601String(),
                    'user' => $c->relationLoaded('user') ? [
                        'id'           => $c->user->id,
                        'name'         => $c->user->name,
                        'email'        => $c->user->email,
                        'resume_photo' => $c->user->resume_photo
                            ? Storage::disk($resumeDisk)->url($c->user->resume_photo)
                            : null,
                    ] : null,
                ])->values()->all()
                : [],

            'student' => new UserResource($this->whenLoaded('user')),
        ];
    }
}
