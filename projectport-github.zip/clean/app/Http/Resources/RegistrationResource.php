<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * A registration in the admin queue. FR-04.
 */
class RegistrationResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'approved' => $this->approved,
            'state' => match ($this->approved) {
                null => 'pending',
                true => 'approved',
                false => 'rejected',
            },
            'decided_at' => $this->decided_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'user' => new UserResource($this->whenLoaded('user')),
            'admin' => new UserResource($this->whenLoaded('admin')),
        ];
    }
}
