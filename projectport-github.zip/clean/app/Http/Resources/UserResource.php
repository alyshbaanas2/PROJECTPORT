<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/**
 * Public representation of a User. Never exposes password or verification token.
 * FR-01, FR-03, FR-04, FR-05, FR-06.
 */
class UserResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $disk = (string) config('projectport.resume_photo.disk', 'public');

        return [
            'id'           => $this->id,
            'email'        => $this->email,
            'role'         => $this->role,
            'status'       => $this->status,
            'name'         => $this->name,
            'skills'       => $this->skills,
            // Full public URL when a photo is stored; null otherwise.
            'resume_photo' => $this->resume_photo
                ? Storage::disk($disk)->url($this->resume_photo)
                : null,
            'email_verified' => $this->hasVerifiedEmail(),
            'projects'       => ProjectResource::collection($this->whenLoaded('projects')),
        ];
    }
}
