<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * FR-01 validation rules: email — required, valid email format, unique.
 */
class RegisterUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email:rfc'],
            // FR-03 validation rules: password — required, minimum 8 characters.
            'password' => ['required', 'string', 'min:8'],
            'role' => ['required', Rule::in([User::ROLE_STUDENT, User::ROLE_RECRUITER])],
            'name' => ['nullable', 'string', 'max:255'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'email.required' => 'An email address is required.',
            'email.email' => 'A valid email address is required.',
            'password.required' => 'A password is required.',
            'password.min' => 'The password must be at least 8 characters.',
            'role.required' => 'A role is required.',
            'role.in' => 'The role must be either student or recruiter.',
        ];
    }
}
