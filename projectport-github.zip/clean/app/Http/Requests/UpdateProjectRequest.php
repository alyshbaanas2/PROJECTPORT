<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * FR-05: validation rules for updating an existing project.
 *  - project_name: optional rename, min 5 chars
 *  - screenshots:  optional replacement set of images
 */
class UpdateProjectRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $maxCount = (int) config('projectport.screenshots.max_count', 5);
        $maxKb    = (int) config('projectport.screenshots.max_kilobytes', 5120);
        $exts     = implode(',', (array) config('projectport.screenshots.allowed_extensions'));

        return [
            'project_name'     => ['sometimes', 'string', 'min:5', 'max:255'],
            'screenshots'      => ['sometimes', 'nullable', 'array', "max:{$maxCount}"],
            'screenshots.*'    => ['image', "extensions:{$exts}", "max:{$maxKb}"],
            // Selling fields.
            'for_sale'         => ['sometimes', 'boolean'],
            'price'            => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:99999'],
            'sale_description' => ['sometimes', 'nullable', 'string', 'max:1000'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'project_name.min'         => 'The project name must be at least 5 characters.',
            'screenshots.array'        => 'Screenshots must be provided as a list of files.',
            'screenshots.max'          => 'You may upload at most '.config('projectport.screenshots.max_count').' screenshots per project.',
            'screenshots.*.image'      => 'Each screenshot must be a valid image file.',
            'screenshots.*.extensions' => 'Screenshots must be jpg, jpeg, png, gif, or webp.',
            'screenshots.*.max'        => 'Each screenshot must not exceed '.config('projectport.screenshots.max_kilobytes').' KB.',
        ];
    }
}
