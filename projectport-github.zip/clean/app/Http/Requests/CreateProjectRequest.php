<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * FR-05 validation rules:
 *  - project_name: required, minimum 5 characters
 *  - source_code: required, valid file type
 */
class CreateProjectRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $maxCount  = (int) config('projectport.screenshots.max_count', 5);
        $maxKb     = (int) config('projectport.screenshots.max_kilobytes', 5120);
        $exts      = implode(',', (array) config('projectport.screenshots.allowed_extensions'));

        return [
            'project_name' => ['required', 'string', 'min:5', 'max:255'],
            'source_code' => [
                'required',
                'file',
                'mimetypes:'.implode(',', [
                    'application/zip',
                    'application/x-zip-compressed',
                    'application/x-tar',
                    'application/gzip',
                    'application/x-gzip',
                    'application/x-rar-compressed',
                    'application/vnd.rar',
                    'application/x-7z-compressed',
                    'application/octet-stream',
                ]),
                'extensions:'.implode(',', (array) config('projectport.source_code.allowed_extensions')),
                'max:'.(int) config('projectport.source_code.max_kilobytes'),
            ],
            // screenshots is optional; when present it must be an array of image files.
            'screenshots'   => ['sometimes', 'nullable', 'array', "max:{$maxCount}"],
            'screenshots.*' => ['image', "extensions:{$exts}", "max:{$maxKb}"],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'project_name.required'    => 'A project name is required.',
            'project_name.min'         => 'The project name must be at least 5 characters.',
            'source_code.required'     => 'A source code archive is required.',
            'source_code.file'         => 'The source code must be an uploaded file.',
            'source_code.mimetypes'    => 'The source code must be a valid archive file.',
            'source_code.extensions'   => 'The source code must be a valid archive file.',
            'source_code.max'          => 'The source code archive is too large.',
            'screenshots.array'        => 'Screenshots must be provided as a list of files.',
            'screenshots.max'          => 'You may upload at most '.config('projectport.screenshots.max_count').' screenshots per project.',
            'screenshots.*.image'      => 'Each screenshot must be a valid image file.',
            'screenshots.*.extensions' => 'Screenshots must be jpg, jpeg, png, gif, or webp.',
            'screenshots.*.max'        => 'Each screenshot must not exceed '.config('projectport.screenshots.max_kilobytes').' KB.',
        ];
    }
}
