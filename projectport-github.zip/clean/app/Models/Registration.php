<?php

namespace App\Models;

use Database\Factories\RegistrationFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Data Model: Registration (user_id, approved) — belongs_to user, belongs_to admin.
 * FR-01 (created at registration), FR-04 (approved / rejected by an admin).
 */
#[Fillable(['user_id', 'approved', 'admin_id', 'decided_at'])]
class Registration extends Model
{
    /** @use HasFactory<RegistrationFactory> */
    use HasFactory;

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'approved' => 'boolean',
            'decided_at' => 'datetime',
        ];
    }

    /** Data Model: Registration belongs_to user. */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** Data Model: Registration belongs_to admin. */
    public function admin(): BelongsTo
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    /** FR-04: no admin decision has been recorded yet. */
    public function isPending(): bool
    {
        return $this->approved === null;
    }
}
