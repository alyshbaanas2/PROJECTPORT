<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * Data Model: User (email, password, role).
 * has_many projects, belongs_to registrations.
 */
#[Fillable([
    'email',
    'password',
    'role',
    'status',
    'name',
    'skills',
    'resume_photo',
    'email_verified_at',
    'email_verification_token',
    'email_verification_expires_at',
    'token_version',
])]
#[Hidden(['password', 'email_verification_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    public const ROLE_ADMIN = 'admin';

    public const ROLE_STUDENT = 'student';

    public const ROLE_RECRUITER = 'recruiter';

    public const ROLES = [self::ROLE_ADMIN, self::ROLE_STUDENT, self::ROLE_RECRUITER];

    /** FR-04: account states an admin decision moves the user between. */
    public const STATUS_PENDING = 'pending';

    public const STATUS_ACTIVE = 'active';

    public const STATUS_INACTIVE = 'inactive';

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'email_verification_expires_at' => 'datetime',
            'password' => 'hashed',
            'token_version' => 'integer',
        ];
    }

    /** Data Model: User has_many projects. */
    public function projects(): HasMany
    {
        return $this->hasMany(Project::class);
    }

    /** Data Model: User belongs_to registrations (one registration record per user). */
    public function registration(): HasOne
    {
        return $this->hasOne(Registration::class);
    }

    public function refreshTokens(): HasMany
    {
        return $this->hasMany(RefreshToken::class);
    }

    /** Contact requests this user received (as a student). */
    public function contactRequestsReceived(): HasMany
    {
        return $this->hasMany(ContactRequest::class, 'recipient_id');
    }

    /** Contact requests this user sent (as a recruiter). */
    public function contactRequestsSent(): HasMany
    {
        return $this->hasMany(ContactRequest::class, 'sender_id');
    }

    /** FR-02: the account has completed email verification. */
    public function hasVerifiedEmail(): bool
    {
        return $this->email_verified_at !== null;
    }

    /** FR-04: the account was approved by an admin. */
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function hasRole(string $role): bool
    {
        return $this->role === $role;
    }
}
