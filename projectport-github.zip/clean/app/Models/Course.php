<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['title', 'description', 'youtube_url', 'topic', 'sort_order'])]
class Course extends Model
{
    public function progress(): HasMany
    {
        return $this->hasMany(CourseProgress::class);
    }

    /**
     * Extract the YouTube video ID from various URL formats.
     * Handles: watch?v=ID, youtu.be/ID, embed/ID, or bare ID.
     */
    public function getYoutubeIdAttribute(): string
    {
        $url = $this->youtube_url;

        if (preg_match('/(?:v=|\/embed\/|youtu\.be\/)([A-Za-z0-9_\-]{11})/', $url, $m)) {
            return $m[1];
        }

        // Assume the stored value is already a bare ID.
        return $url;
    }
}
