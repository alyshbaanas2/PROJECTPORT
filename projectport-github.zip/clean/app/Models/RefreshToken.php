<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

/**
 * Implementation Checklist: refresh token rotation.
 * Stores only a SHA-256 hash of the issued refresh token.
 */
#[Fillable(['user_id', 'token_hash', 'expires_at', 'revoked_at', 'replaced_by_id'])]
class RefreshToken extends Model
{
    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'expires_at' => 'datetime',
            'revoked_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function isUsable(): bool
    {
        return $this->revoked_at === null && $this->expires_at->isAfter(Carbon::now());
    }
}
