<?php

namespace App\Providers;

use App\Support\ApiError;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        $this->configureRateLimiting();
        $this->configureHttps();
        $this->configureQueryMonitoring();
    }

    /**
     * NFR-02: 10 req/min per IP on auth endpoints, 100 req/min on read endpoints.
     * Breaches return 429 in the Error Response Contract shape.
     */
    private function configureRateLimiting(): void
    {
        $tooManyRequests = fn () => response()->json(
            ApiError::payload(ApiError::RATE_LIMIT_EXCEEDED, 'Too many requests. Please retry later.'),
            429,
        );

        RateLimiter::for('auth', fn (Request $request) => Limit::perMinute(
            (int) config('projectport.rate_limits.auth_per_minute')
        )->by($request->ip())->response($tooManyRequests));

        RateLimiter::for('read', fn (Request $request) => Limit::perMinute(
            (int) config('projectport.rate_limits.read_per_minute')
        )->by($request->ip())->response($tooManyRequests));
    }

    /** NFR-02: HTTPS-only connections. */
    private function configureHttps(): void
    {
        if ((bool) config('projectport.security.force_https')) {
            URL::forceScheme('https');
        }
    }

    /** NFR-04: alert on queries slower than the 100 ms average target. */
    private function configureQueryMonitoring(): void
    {
        $budgetMs = (int) config('projectport.performance.query_budget_ms');

        DB::whenQueryingForLongerThan($budgetMs, function ($connection) use ($budgetMs): void {
            Log::warning('Query time budget exceeded', [
                'connection' => $connection->getName(),
                'budget_ms' => $budgetMs,
            ]);
        });
    }
}
