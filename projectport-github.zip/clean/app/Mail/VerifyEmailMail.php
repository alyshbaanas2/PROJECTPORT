<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * FR-01: "the user receives a verification email".
 */
class VerifyEmailMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly User $user,
        public readonly string $token,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(subject: 'Verify your ProjectPort email address');
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.verify_email',
            with: [
                'verificationUrl' => rtrim((string) config('app.url'), '/').'/api/auth/verify-email/'.$this->token,
            ],
        );
    }
}
