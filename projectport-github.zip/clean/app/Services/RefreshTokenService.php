<?php

namespace App\Services;

use App\Exceptions\ApiException;
use App\Models\RefreshToken;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

/**
 * Implementation Checklist: refresh token rotation — a new refresh token is
 * issued on every use and the token it replaces is invalidated immediately.
 */
class RefreshTokenService
{
    /** Issue a brand new refresh token and return the plaintext value. */
    public function issue(User $user): string
    {
        $plain = Str::random(64);

        RefreshToken::create([
            'user_id' => $user->getKey(),
            'token_hash' => $this->hash($plain),
            'expires_at' => Carbon::now()->addDays((int) config('projectport.jwt.refresh_expire_days')),
        ]);

        return $plain;
    }

    /**
     * Rotate a refresh token: validate it, revoke it, and issue its replacement.
     *
     * @return array{user: User, refresh_token: string}
     *
     * @throws ApiException 401 when the presented token is unknown, revoked or expired.
     */
    public function rotate(string $plain): array
    {
        $existing = RefreshToken::where('token_hash', $this->hash($plain))->first();

        if ($existing === null || ! $existing->isUsable()) {
            throw ApiException::unauthenticated('The refresh token is invalid or has expired.');
        }

        $user = $existing->user;

        $replacementPlain = Str::random(64);

        $replacement = RefreshToken::create([
            'user_id' => $user->getKey(),
            'token_hash' => $this->hash($replacementPlain),
            'expires_at' => Carbon::now()->addDays((int) config('projectport.jwt.refresh_expire_days')),
        ]);

        $existing->update([
            'revoked_at' => Carbon::now(),
            'replaced_by_id' => $replacement->getKey(),
        ]);

        return ['user' => $user, 'refresh_token' => $replacementPlain];
    }

    /** Revoke every live refresh token for a user (logout / credential change). */
    public function revokeAllForUser(User $user): void
    {
        $user->refreshTokens()->whereNull('revoked_at')->update(['revoked_at' => Carbon::now()]);
    }

    private function hash(string $plain): string
    {
        return hash('sha256', $plain);
    }
}
