<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * FR-05: store and manage a student's resume/profile picture on the public
 * disk so it can be served via a stable public URL.
 */
class ResumePhotoStorageService
{
    /**
     * Store a resume photo and return its relative path on the public disk.
     * Automatically deletes the previous photo if one exists.
     */
    public function store(User $student, UploadedFile $file): string
    {
        // Remove the old photo before saving the new one.
        if ($student->resume_photo) {
            $this->delete($student->resume_photo);
        }

        $directory = trim((string) config('projectport.resume_photo.directory'), '/').'/'.$student->getKey();

        $filename = Str::uuid()->toString().'.'.strtolower($file->getClientOriginalExtension());

        return $file->storeAs($directory, $filename, [
            'disk' => (string) config('projectport.resume_photo.disk'),
        ]);
    }

    /**
     * Delete a resume photo by its stored relative path.
     */
    public function delete(string $path): void
    {
        Storage::disk($this->disk())->delete($path);
    }

    /**
     * Return the public URL for a stored resume photo path.
     */
    public function url(string $path): string
    {
        return Storage::disk($this->disk())->url($path);
    }

    public function disk(): string
    {
        return (string) config('projectport.resume_photo.disk');
    }
}
