<?php

namespace App\Services;

use App\Models\Project;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * FR-05: store and manage project screenshot images on the public disk
 * so they can be served via a stable public URL.
 */
class ScreenshotStorageService
{
    /**
     * Store one screenshot and return its relative path on the public disk.
     */
    public function store(User $student, UploadedFile $file): string
    {
        $directory = trim((string) config('projectport.screenshots.directory'), '/').'/'.$student->getKey();

        $filename = Str::uuid()->toString().'.'.strtolower($file->getClientOriginalExtension());

        return $file->storeAs($directory, $filename, [
            'disk' => (string) config('projectport.screenshots.disk'),
        ]);
    }

    /**
     * Store multiple screenshots and return their relative paths.
     *
     * @param  UploadedFile[]  $files
     * @return string[]
     */
    public function storeMany(User $student, array $files): array
    {
        return array_map(fn (UploadedFile $file) => $this->store($student, $file), $files);
    }

    /**
     * Delete a single screenshot by its stored relative path.
     */
    public function delete(string $path): void
    {
        Storage::disk($this->disk())->delete($path);
    }

    /**
     * Delete all screenshots belonging to a project.
     */
    public function deleteForProject(Project $project): void
    {
        foreach ((array) ($project->screenshots ?? []) as $path) {
            $this->delete($path);
        }
    }

    /**
     * Return the public URL for a stored screenshot path.
     */
    public function url(string $path): string
    {
        return Storage::disk($this->disk())->url($path);
    }

    public function disk(): string
    {
        return (string) config('projectport.screenshots.disk');
    }
}
