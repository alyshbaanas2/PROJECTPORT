<?php

namespace App\Services;

use App\Exceptions\ApiException;
use App\Models\User;
use App\Support\ApiError;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use UnexpectedValueException;

/**
 * Architecture Decision: auth_strategy = jwt_stateless.
 *
 * Issues and verifies signed, stateless access tokens. No server-side session
 * state is consulted beyond the user's token_version, which lets a password or
 * email change invalidate every previously issued token
 * (Implementation Checklist: session invalidation on password or email change).
 */
class JwtService
{
    /** Issue a signed access token for the given user. */
    public function issueAccessToken(User $user): string
    {
        $issuedAt = Carbon::now();
        $expiresAt = $issuedAt->copy()->addMinutes($this->expireMinutes());

        $claims = [
            'iss' => (string) config('app.url'),
            'sub' => (string) $user->getKey(),
            'jti' => (string) Str::uuid(),
            'iat' => $issuedAt->getTimestamp(),
            'exp' => $expiresAt->getTimestamp(),
            'email' => $user->email,
            'role' => $user->role,
            'tv' => (int) $user->token_version,
        ];

        return JWT::encode($claims, $this->secret(), $this->algorithm());
    }

    /**
     * Verify a token and return its claims.
     *
     * @return array<string, mixed>
     *
     * @throws ApiException 401 when the token is missing, malformed or expired.
     */
    public function verifyAccessToken(string $token): array
    {
        try {
            $claims = (array) JWT::decode($token, new Key($this->secret(), $this->algorithm()));
        } catch (ExpiredException) {
            throw ApiException::unauthenticated('The access token has expired.', ApiError::TOKEN_EXPIRED);
        } catch (UnexpectedValueException) {
            throw ApiException::unauthenticated('The access token is invalid.');
        }

        return $claims;
    }

    /** Seconds until an issued access token expires. */
    public function accessTokenTtlSeconds(): int
    {
        return $this->expireMinutes() * 60;
    }

    private function secret(): string
    {
        $secret = (string) config('projectport.jwt.secret');

        if ($secret === '') {
            throw new ApiException(ApiError::INTERNAL_ERROR, 'An unexpected error occurred.', 500);
        }

        return $secret;
    }

    private function algorithm(): string
    {
        return (string) config('projectport.jwt.algorithm');
    }

    private function expireMinutes(): int
    {
        return (int) config('projectport.jwt.expire_minutes');
    }
}
