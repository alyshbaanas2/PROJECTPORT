<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * FR-05 (upload_source_code).
 *
 * Architecture Decision file_storage = none, so archives are written to the
 * application's local disk rather than an object store.
 */
class SourceCodeStorageService
{
    /**
     * Store an uploaded source code archive and return its stored path.
     */
    public function upload_source_code(User $student, UploadedFile $file): string
    {
        $directory = trim((string) config('projectport.source_code.directory'), '/').'/'.$student->getKey();

        $filename = Str::uuid()->toString().'.'.strtolower($file->getClientOriginalExtension());

        return $file->storeAs($directory, $filename, [
            'disk' => (string) config('projectport.source_code.disk'),
        ]);
    }

    public function disk(): string
    {
        return (string) config('projectport.source_code.disk');
    }

    public function exists(string $path): bool
    {
        return Storage::disk($this->disk())->exists($path);
    }
}
