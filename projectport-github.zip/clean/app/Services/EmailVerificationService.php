<?php

namespace App\Services;

use App\Exceptions\ApiException;
use App\Mail\VerifyEmailMail;
use App\Models\User;
use App\Support\ApiError;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

/**
 * FR-01 (verify_email) and FR-02 (verify_email_address).
 *
 * Issues single-use, expiring verification tokens and consumes them. Only the
 * SHA-256 hash of a token is persisted.
 */
class EmailVerificationService
{
    /**
     * FR-01: generate a verification token for the user and send the
     * verification email that carries it.
     */
    public function verify_email(User $user): string
    {
        $plainToken = Str::random(64);

        $user->forceFill([
            'email_verification_token' => $this->hash($plainToken),
            'email_verification_expires_at' => Carbon::now()->addMinutes(
                (int) config('projectport.email_verification.token_ttl_minutes')
            ),
        ])->save();

        Mail::to($user->email)->send(new VerifyEmailMail($user, $plainToken));

        return $plainToken;
    }

    /**
     * FR-02: consume a verification token and mark the email as verified.
     *
     * @throws ApiException 400 when the token is unknown or expired.
     */
    public function consume(string $plainToken): User
    {
        $user = User::where('email_verification_token', $this->hash($plainToken))->first();

        if ($user === null
            || $user->email_verification_expires_at === null
            || $user->email_verification_expires_at->isBefore(Carbon::now())) {
            throw new ApiException(
                ApiError::INVALID_VERIFICATION_TOKEN,
                'The verification token is invalid or has expired.',
                400,
                'token',
            );
        }

        $user->forceFill([
            'email_verified_at' => Carbon::now(),
            'email_verification_token' => null,
            'email_verification_expires_at' => null,
        ])->save();

        return $user;
    }

    private function hash(string $plainToken): string
    {
        return hash('sha256', $plainToken);
    }
}
