<?php

namespace App\Support;

use Illuminate\Http\JsonResponse;

/**
 * Error Response Contract.
 *
 * Every error response produced by this application has exactly this shape:
 *
 *   {"error": "SNAKE_CASE_CODE", "message": "human readable", "field": "optional field name"}
 *
 * No other error shape is permitted anywhere in the codebase.
 */
final class ApiError
{
    public const VALIDATION_FAILED = 'VALIDATION_FAILED';

    public const UNAUTHENTICATED = 'UNAUTHENTICATED';

    public const INVALID_CREDENTIALS = 'INVALID_CREDENTIALS';

    public const TOKEN_EXPIRED = 'TOKEN_EXPIRED';

    public const FORBIDDEN = 'FORBIDDEN';

    public const NOT_FOUND = 'NOT_FOUND';

    public const CONFLICT = 'CONFLICT';

    public const EMAIL_ALREADY_REGISTERED = 'EMAIL_ALREADY_REGISTERED';

    public const INVALID_VERIFICATION_TOKEN = 'INVALID_VERIFICATION_TOKEN';

    public const EMAIL_NOT_VERIFIED = 'EMAIL_NOT_VERIFIED';

    public const ACCOUNT_NOT_ACTIVE = 'ACCOUNT_NOT_ACTIVE';

    public const REGISTRATION_ALREADY_DECIDED = 'REGISTRATION_ALREADY_DECIDED';

    public const PREVIEW_UNAVAILABLE = 'PREVIEW_UNAVAILABLE';

    public const RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED';

    public const METHOD_NOT_ALLOWED = 'METHOD_NOT_ALLOWED';

    public const INTERNAL_ERROR = 'INTERNAL_ERROR';

    /**
     * Build a contract-shaped JSON error response.
     *
     * The "field" key is present only for validation errors (HTTP 400).
     */
    public static function response(string $error, string $message, int $status, ?string $field = null): JsonResponse
    {
        return new JsonResponse(self::payload($error, $message, $field), $status);
    }

    /**
     * @return array{error: string, message: string, field?: string}
     */
    public static function payload(string $error, string $message, ?string $field = null): array
    {
        $payload = [
            'error' => $error,
            'message' => $message,
        ];

        if ($field !== null) {
            $payload['field'] = $field;
        }

        return $payload;
    }
}
