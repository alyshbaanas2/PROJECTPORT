<?php

use App\Exceptions\ApiException;
use App\Http\Middleware\EnsureRole;
use App\Http\Middleware\ForceHttps;
use App\Http\Middleware\JwtAuthenticate;
use App\Http\Middleware\RequestTiming;
use App\Support\ApiError;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // NFR-02: HTTPS-only + HSTS. NFR-01/NFR-03: response time monitoring.
        $middleware->append(ForceHttps::class);
        $middleware->append(RequestTiming::class);

        $middleware->alias([
            'jwt.auth' => JwtAuthenticate::class,
            'role' => EnsureRole::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // This application is API-only: every error is rendered as JSON using
        // the Error Response Contract.
        $exceptions->shouldRenderJsonWhen(fn (Request $request) => true);

        $exceptions->render(function (Throwable $e, Request $request) {
            return match (true) {
                $e instanceof ApiException => $e->render(),

                // Framework control flow (e.g. the rate limiter's 429) already
                // carries a contract-shaped response.
                $e instanceof HttpResponseException => $e->getResponse(),

                // 400 — validation failure (include the offending field).
                $e instanceof ValidationException => ApiError::response(
                    ApiError::VALIDATION_FAILED,
                    (string) collect($e->errors())->flatten()->first(),
                    400,
                    (string) array_key_first($e->errors()),
                ),

                // 401 — missing or expired JWT.
                $e instanceof AuthenticationException => ApiError::response(
                    ApiError::UNAUTHENTICATED,
                    'Authentication is required.',
                    401,
                ),

                // 403 — authenticated but not authorised.
                $e instanceof AuthorizationException => ApiError::response(
                    ApiError::FORBIDDEN,
                    'You are not authorised to perform this action.',
                    403,
                ),

                // 404 — resource not found.
                $e instanceof ModelNotFoundException,
                $e instanceof NotFoundHttpException => ApiError::response(
                    ApiError::NOT_FOUND,
                    'Resource not found.',
                    404,
                ),

                $e instanceof MethodNotAllowedHttpException => ApiError::response(
                    ApiError::METHOD_NOT_ALLOWED,
                    'This method is not allowed for the requested resource.',
                    405,
                ),

                // 429 — rate limit exceeded (NFR-02).
                $e instanceof TooManyRequestsHttpException => ApiError::response(
                    ApiError::RATE_LIMIT_EXCEEDED,
                    'Too many requests. Please retry later.',
                    429,
                ),

                // 500 — unexpected server error; never expose stack traces.
                default => ApiError::response(
                    ApiError::INTERNAL_ERROR,
                    'An unexpected error occurred.',
                    500,
                ),
            };
        });
    })->create();
