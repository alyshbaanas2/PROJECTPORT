<!-- FR-01: verification email body. Responsive width for desktop and mobile (NFR-03). -->
<div style="max-width:600px;width:100%;margin:0 auto;font-family:system-ui,-apple-system,'Segoe UI',sans-serif;line-height:1.5;">
    <h1 style="font-size:20px;">Verify your email address</h1>

    <p>Welcome to ProjectPort. Confirm this email address to complete your registration.</p>

    <p>
        <a href="{{ $verificationUrl }}"
           style="display:inline-block;padding:12px 20px;background:#1e40af;color:#ffffff;text-decoration:none;border-radius:6px;">
            Verify email address
        </a>
    </p>

    <p style="word-break:break-all;font-size:13px;color:#475569;">
        If the button does not work, open this link: {{ $verificationUrl }}
    </p>

    <p style="font-size:13px;color:#475569;">
        This link expires in {{ (int) config('projectport.email_verification.token_ttl_minutes') }} minutes.
    </p>
</div>
