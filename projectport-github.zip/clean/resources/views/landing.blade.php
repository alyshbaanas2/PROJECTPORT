<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="ProjectPort — students publish real projects with source code. Recruiters find talent by the skills they actually have.">
    <title>ProjectPort — Where student work meets opportunity</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%234f46e5'/><path d='M8 10h10a4 4 0 0 1 0 8H8z' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round'/><circle cx='10.5' cy='22.5' r='2' fill='white'/></svg>">
    <link rel="stylesheet" href="{{ asset('assets/app.css') }}?v={{ filemtime(public_path('assets/app.css')) }}">
    <style>
        /* ── Landing-only styles ─────────────────────────────── */
        .lp-body { background: var(--bg); color: var(--ink); min-height: 100vh; }

        /* NAV */
        .lp-nav {
            position: sticky; top: 0; z-index: 50;
            display: flex; align-items: center; gap: 16px;
            padding: 0 clamp(20px, 5vw, 64px);
            height: 64px;
            background: color-mix(in srgb, var(--bg) 70%, transparent);
            backdrop-filter: blur(16px);
            border-bottom: 1px solid var(--line);
        }
        .lp-nav .spacer { flex: 1; }
        .lp-nav-links { display: flex; gap: 4px; }
        .lp-nav-links a {
            padding: 7px 13px; border-radius: var(--r-sm);
            text-decoration: none; color: var(--ink-2);
            font-size: 13.5px; font-weight: 560;
            transition: background .12s, color .12s;
        }
        .lp-nav-links a:hover { background: var(--panel-2); color: var(--ink); }
        @media (max-width: 600px) { .lp-nav-links { display: none; } }

        /* HERO */
        .lp-hero {
            position: relative; overflow: hidden;
            padding: clamp(72px, 12vw, 120px) clamp(20px, 5vw, 64px) clamp(64px, 10vw, 100px);
            text-align: center;
        }
        .lp-hero-glow {
            position: absolute; inset: 0; pointer-events: none;
            background:
                radial-gradient(900px 500px at 50% -10%, color-mix(in srgb, var(--brand) 22%, transparent), transparent 65%),
                radial-gradient(600px 400px at 15% 80%, color-mix(in srgb, #a855f7 14%, transparent), transparent 60%),
                radial-gradient(600px 400px at 85% 80%, color-mix(in srgb, var(--brand) 12%, transparent), transparent 60%);
        }
        .lp-hero-content { position: relative; max-width: 780px; margin: 0 auto; }
        .lp-badge {
            display: inline-flex; align-items: center; gap: 7px;
            padding: 5px 13px; border-radius: 999px;
            background: var(--brand-soft); color: var(--brand);
            font-size: 12.5px; font-weight: 650; letter-spacing: .02em;
            border: 1px solid color-mix(in srgb, var(--brand) 30%, transparent);
            margin-bottom: 28px;
        }
        .lp-badge-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--brand); animation: pulse 2s ease-in-out infinite; }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(.7)} }
        .lp-hero h1 {
            font-size: clamp(38px, 6.5vw, 68px);
            font-weight: 750; letter-spacing: -.04em; line-height: 1.07;
            color: var(--ink);
        }
        .lp-hero h1 .grad {
            background: linear-gradient(135deg, var(--brand) 0%, #a855f7 50%, #ec4899 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .lp-hero-sub {
            margin-top: 22px; font-size: clamp(16px, 2.2vw, 20px);
            color: var(--ink-2); max-width: 560px; margin-left: auto; margin-right: auto;
            line-height: 1.6;
        }
        .lp-hero-cta {
            margin-top: 38px; display: flex; gap: 12px;
            justify-content: center; flex-wrap: wrap;
        }
        .lp-btn-primary {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 13px 26px; border-radius: var(--r);
            background: var(--brand); color: var(--brand-ink);
            font-size: 15px; font-weight: 650; text-decoration: none;
            border: 1px solid transparent;
            box-shadow: 0 0 0 0 color-mix(in srgb, var(--brand) 40%, transparent);
            transition: filter .15s, box-shadow .15s, transform .1s;
        }
        .lp-btn-primary:hover { filter: brightness(1.1); transform: translateY(-1px); box-shadow: 0 6px 24px color-mix(in srgb, var(--brand) 35%, transparent); }
        .lp-btn-secondary {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 13px 26px; border-radius: var(--r);
            background: var(--panel); color: var(--ink);
            font-size: 15px; font-weight: 620; text-decoration: none;
            border: 1px solid var(--line-strong);
            transition: background .12s, border-color .12s, transform .1s;
        }
        .lp-btn-secondary:hover { background: var(--panel-2); transform: translateY(-1px); }

        /* HERO SCREENSHOT MOCKUP */
        .lp-hero-visual {
            margin-top: 56px; position: relative;
            max-width: 860px; margin-left: auto; margin-right: auto;
        }
        .lp-mockup {
            background: var(--panel); border: 1px solid var(--line);
            border-radius: var(--r-lg); box-shadow: var(--shadow-xl);
            overflow: hidden;
        }
        .lp-mockup-bar {
            background: var(--panel-2); border-bottom: 1px solid var(--line);
            padding: 10px 16px; display: flex; align-items: center; gap: 10px;
        }
        .lp-mockup-dots { display: flex; gap: 6px; }
        .lp-mockup-dots span { width: 11px; height: 11px; border-radius: 50%; }
        .lp-mockup-dots span:nth-child(1){ background:#ff5f57; }
        .lp-mockup-dots span:nth-child(2){ background:#febc2e; }
        .lp-mockup-dots span:nth-child(3){ background:#28c840; }
        .lp-mockup-url {
            flex: 1; background: var(--panel-3); border-radius: 6px;
            padding: 5px 12px; font-size: 12px; color: var(--ink-3);
            text-align: center; max-width: 280px; margin: 0 auto;
        }
        .lp-mockup-body { display: flex; min-height: 300px; }
        .lp-mockup-sidebar {
            width: 180px; flex: none; border-right: 1px solid var(--line);
            background: var(--panel); padding: 16px 12px; display: flex; flex-direction: column; gap: 6px;
        }
        @media(max-width:640px){ .lp-mockup-sidebar{display:none;} }
        .lp-mock-brand { display: flex; align-items: center; gap: 8px; padding: 6px 8px; margin-bottom: 8px; }
        .lp-mock-brand-icon {
            width: 26px; height: 26px; border-radius: 7px; flex: none;
            background: linear-gradient(140deg, var(--brand), #a855f7);
            display: grid; place-items: center;
        }
        .lp-mock-brand-text { font-size: 13px; font-weight: 700; }
        .lp-mock-nav-item {
            display: flex; align-items: center; gap: 9px; padding: 7px 9px;
            border-radius: 7px; font-size: 12.5px; color: var(--ink-3);
        }
        .lp-mock-nav-item.active { background: var(--brand-soft); color: var(--brand); font-weight: 620; }
        .lp-mock-dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; flex: none; }
        .lp-mockup-content { flex: 1; padding: 20px; display: flex; flex-direction: column; gap: 14px; overflow: hidden; }
        .lp-mock-card {
            background: var(--panel); border: 1px solid var(--line);
            border-radius: 10px; overflow: hidden;
        }
        .lp-mock-card-head { padding: 12px 14px; border-bottom: 1px solid var(--line); background: var(--panel-2); }
        .lp-mock-title { font-size: 12px; font-weight: 650; }
        .lp-mock-row { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-bottom: 1px solid var(--line); }
        .lp-mock-row:last-child { border-bottom: none; }
        .lp-mock-avatar { width: 28px; height: 28px; border-radius: 50%; flex: none; background: var(--brand-soft); display: grid; place-items: center; }
        .lp-mock-line { height: 8px; border-radius: 4px; background: var(--panel-3); flex: 1; }
        .lp-mock-pill { height: 20px; width: 52px; border-radius: 999px; background: var(--ok-soft); flex: none; }
        .lp-mock-pill.brand { background: var(--brand-soft); }
        .lp-mockup-fade {
            position: absolute; bottom: 0; left: 0; right: 0; height: 80px;
            background: linear-gradient(to top, var(--bg), transparent);
            pointer-events: none;
        }
    </style>
</head>
<body class="lp-body">

    <style>
        /* FEATURES */
        .lp-section { padding: clamp(64px,9vw,100px) clamp(20px,5vw,64px); }
        .lp-section-label {
            display: inline-block; font-size: 11.5px; font-weight: 720;
            letter-spacing: .1em; text-transform: uppercase; color: var(--brand);
            margin-bottom: 14px;
        }
        .lp-section-title { font-size: clamp(28px,4vw,42px); font-weight: 740; letter-spacing: -.03em; line-height: 1.12; }
        .lp-section-sub { margin-top: 14px; font-size: 17px; color: var(--ink-2); max-width: 48ch; line-height: 1.65; }
        .lp-features-grid {
            margin-top: 52px;
            display: grid; gap: 20px;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        }
        .lp-feat {
            background: var(--panel); border: 1px solid var(--line);
            border-radius: var(--r-lg); padding: 28px 26px;
            transition: border-color .2s, box-shadow .2s, transform .2s;
        }
        .lp-feat:hover { border-color: color-mix(in srgb, var(--brand) 45%, transparent); box-shadow: var(--shadow); transform: translateY(-2px); }
        .lp-feat-icon {
            width: 44px; height: 44px; border-radius: 12px;
            background: var(--brand-soft); color: var(--brand);
            display: grid; place-items: center; margin-bottom: 18px;
        }
        .lp-feat h3 { font-size: 16px; font-weight: 680; letter-spacing: -.01em; }
        .lp-feat p { margin-top: 8px; font-size: 14px; color: var(--ink-2); line-height: 1.65; }

        /* HOW IT WORKS */
        .lp-steps { max-width: 900px; margin: 52px auto 0; display: grid; gap: 0; }
        .lp-step {
            display: grid; grid-template-columns: 52px 1fr; gap: 0 22px;
            padding-bottom: 36px; position: relative;
        }
        .lp-step:last-child { padding-bottom: 0; }
        .lp-step-line {
            display: flex; flex-direction: column; align-items: center;
        }
        .lp-step-num {
            width: 44px; height: 44px; border-radius: 50%; flex: none;
            background: var(--brand); color: var(--brand-ink);
            display: grid; place-items: center;
            font-size: 15px; font-weight: 750; z-index: 1;
            box-shadow: 0 0 0 4px color-mix(in srgb, var(--brand) 18%, transparent);
        }
        .lp-step-connector {
            flex: 1; width: 2px; background: var(--line); margin-top: 8px;
        }
        .lp-step:last-child .lp-step-connector { display: none; }
        .lp-step-body { padding-top: 8px; }
        .lp-step-body h3 { font-size: 16.5px; font-weight: 680; letter-spacing: -.01em; }
        .lp-step-body p { margin-top: 6px; font-size: 14px; color: var(--ink-2); line-height: 1.65; }

        /* SOCIAL PROOF / STATS */
        .lp-stats-band {
            border-top: 1px solid var(--line); border-bottom: 1px solid var(--line);
            background: var(--panel); padding: clamp(40px,6vw,64px) clamp(20px,5vw,64px);
        }
        .lp-stats-grid { display: grid; gap: 32px; grid-template-columns: repeat(auto-fit,minmax(160px,1fr)); text-align: center; max-width: 860px; margin: 0 auto; }
        .lp-stat-val { font-size: clamp(36px,5vw,52px); font-weight: 760; letter-spacing: -.04em; background: linear-gradient(135deg, var(--brand), #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .lp-stat-label { font-size: 13.5px; color: var(--ink-3); margin-top: 4px; font-weight: 560; }

        /* ROLES */
        .lp-roles { display: grid; gap: 20px; margin-top: 52px; }
        @media(min-width:700px){ .lp-roles { grid-template-columns: 1fr 1fr; } }
        .lp-role {
            border-radius: var(--r-lg); padding: 32px 30px; border: 1px solid var(--line);
            position: relative; overflow: hidden;
        }
        .lp-role-student {
            background: linear-gradient(135deg, color-mix(in srgb, var(--brand) 8%, var(--panel)) 0%, var(--panel) 100%);
        }
        .lp-role-recruiter {
            background: linear-gradient(135deg, color-mix(in srgb, #a855f7 8%, var(--panel)) 0%, var(--panel) 100%);
        }
        .lp-role-glow {
            position: absolute; width: 220px; height: 220px; border-radius: 50%;
            top: -60px; right: -60px; pointer-events: none; filter: blur(60px); opacity: .35;
        }
        .lp-role-student .lp-role-glow { background: var(--brand); }
        .lp-role-recruiter .lp-role-glow { background: #a855f7; }
        .lp-role-tag {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 11px; border-radius: 999px; font-size: 11.5px; font-weight: 680;
            letter-spacing: .04em; text-transform: uppercase; margin-bottom: 16px;
        }
        .lp-role-student .lp-role-tag { background: var(--brand-soft); color: var(--brand); }
        .lp-role-recruiter .lp-role-tag { background: color-mix(in srgb,#a855f7 15%,transparent); color: #a855f7; }
        .lp-role h3 { font-size: 22px; font-weight: 720; letter-spacing: -.02em; }
        .lp-role p { margin-top: 10px; font-size: 14.5px; color: var(--ink-2); line-height: 1.65; }
        .lp-role-list { list-style: none; padding: 0; margin: 18px 0 24px; display: grid; gap: 10px; }
        .lp-role-list li { display: flex; align-items: flex-start; gap: 10px; font-size: 14px; color: var(--ink-2); }
        .lp-role-list li::before { content: "✓"; color: var(--ok); font-weight: 700; flex: none; margin-top: 1px; }

        /* CTA BAND */
        .lp-cta-band {
            margin: 0 clamp(20px,5vw,64px) clamp(64px,8vw,96px);
            border-radius: var(--r-lg); overflow: hidden; position: relative;
            padding: clamp(48px,7vw,80px) clamp(28px,5vw,64px);
            background: linear-gradient(135deg, #1a1660 0%, #2d1b69 40%, #1a0e3b 100%);
            text-align: center;
        }
        .lp-cta-band .noise {
            position: absolute; inset: 0; opacity: .04;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
        }
        .lp-cta-band > * { position: relative; }
        .lp-cta-band h2 { font-size: clamp(26px,4vw,40px); font-weight: 740; letter-spacing: -.03em; color: #fff; }
        .lp-cta-band p { margin-top: 12px; font-size: 16px; color: rgba(255,255,255,.68); max-width: 44ch; margin-left: auto; margin-right: auto; }
        .lp-cta-band .lp-hero-cta { margin-top: 32px; }
        .lp-cta-band .lp-btn-secondary { background: rgba(255,255,255,.1); color: rgba(255,255,255,.88); border-color: rgba(255,255,255,.2); }
        .lp-cta-band .lp-btn-secondary:hover { background: rgba(255,255,255,.18); }

        /* FOOTER */
        .lp-footer {
            border-top: 1px solid var(--line); padding: 28px clamp(20px,5vw,64px);
            display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
        }
        .lp-footer .spacer { flex: 1; }
        .lp-footer-links { display: flex; gap: 18px; flex-wrap: wrap; }
        .lp-footer-links a { font-size: 13px; color: var(--ink-3); text-decoration: none; }
        .lp-footer-links a:hover { color: var(--ink); }
        .lp-footer-copy { font-size: 13px; color: var(--ink-3); }
        .theme-btn { background: none; border: 1px solid var(--line); color: var(--ink-3); border-radius: var(--r-sm); padding: 6px 10px; cursor: pointer; font: inherit; font-size: 12.5px; transition: background .12s, color .12s; }
        .theme-btn:hover { background: var(--panel-2); color: var(--ink); }
    </style>

    {{-- ══════════════ NAV ══════════════ --}}
    <nav class="lp-nav">
        <a href="/" style="display:flex;align-items:center;gap:10px;text-decoration:none;color:inherit">
            <svg width="30" height="30" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" style="border-radius:8px">
                <rect width="32" height="32" rx="8" fill="url(#lg1)"/>
                <path d="M8 10h10a4 4 0 0 1 0 8H8z" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="10.5" cy="22.5" r="2" fill="white"/>
                <defs><linearGradient id="lg1" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse"><stop stop-color="#4f46e5"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs>
            </svg>
            <span style="font-weight:700;font-size:15.5px;letter-spacing:-.02em">ProjectPort</span>
        </a>
        <div class="spacer"></div>
        <div class="lp-nav-links">
            <a href="#features">Features</a>
            <a href="#how-it-works">How it works</a>
            <a href="#for-you">For you</a>
        </div>
        <button class="theme-btn" id="lp-theme" aria-label="Toggle theme">🌙</button>
        <a href="/app" class="btn ghost sm">Sign in</a>
        <a href="/app" class="btn sm">Get started</a>
    </nav>

    {{-- ══════════════ HERO ══════════════ --}}
    <section class="lp-hero">
        <div class="lp-hero-glow"></div>
        <div class="lp-hero-content">
            <div class="lp-badge">
                <span class="lp-badge-dot"></span>
                Now open for students & recruiters
            </div>
            <h1>
                Student work,<br>
                <span class="grad">ready to be found.</span>
            </h1>
            <p class="lp-hero-sub">
                ProjectPort lets students publish real projects with source code and screenshots.
                Recruiters find them by the skills they actually have — not just a résumé.
            </p>
            <div class="lp-hero-cta">
                <a href="/app" class="lp-btn-primary">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                    Get started free
                </a>
                <a href="#how-it-works" class="lp-btn-secondary">See how it works</a>
            </div>
        </div>

        {{-- UI Mockup --}}
        <div class="lp-hero-visual">
            <div class="lp-mockup">
                <div class="lp-mockup-bar">
                    <div class="lp-mockup-dots"><span></span><span></span><span></span></div>
                    <div class="lp-mockup-url">projectport.app/search</div>
                </div>
                <div class="lp-mockup-body">
                    <div class="lp-mockup-sidebar">
                        <div class="lp-mock-brand">
                            <div class="lp-mock-brand-icon">
                                <svg width="14" height="14" viewBox="0 0 32 32" fill="none"><path d="M8 10h10a4 4 0 0 1 0 8H8z" stroke="white" stroke-width="2.5" stroke-linecap="round"/><circle cx="10.5" cy="22.5" r="2" fill="white"/></svg>
                            </div>
                            <span class="lp-mock-brand-text">ProjectPort</span>
                        </div>
                        <div class="lp-mock-nav-item active"><span class="lp-mock-dot"></span> Find talent</div>
                        <div class="lp-mock-nav-item"><span class="lp-mock-dot"></span> Saved</div>
                        <div class="lp-mock-nav-item"><span class="lp-mock-dot"></span> Messages</div>
                    </div>
                    <div class="lp-mockup-content">
                        <div class="lp-mock-card">
                            <div class="lp-mock-card-head"><div class="lp-mock-title">Search results — "laravel, react"</div></div>
                            <div class="lp-mock-row">
                                <div class="lp-mock-avatar" style="background:var(--brand-soft);color:var(--brand);font-size:11px;font-weight:700">AS</div>
                                <div class="lp-mock-line" style="max-width:120px"></div>
                                <div class="lp-mock-line" style="max-width:80px;opacity:.5"></div>
                                <div class="lp-mock-pill brand"></div>
                            </div>
                            <div class="lp-mock-row">
                                <div class="lp-mock-avatar" style="background:#f0fdf4;color:#16a34a;font-size:11px;font-weight:700">RK</div>
                                <div class="lp-mock-line" style="max-width:140px"></div>
                                <div class="lp-mock-line" style="max-width:60px;opacity:.5"></div>
                                <div class="lp-mock-pill"></div>
                            </div>
                            <div class="lp-mock-row">
                                <div class="lp-mock-avatar" style="background:#fdf4ff;color:#a855f7;font-size:11px;font-weight:700">NJ</div>
                                <div class="lp-mock-line" style="max-width:110px"></div>
                                <div class="lp-mock-line" style="max-width:90px;opacity:.5"></div>
                                <div class="lp-mock-pill brand"></div>
                            </div>
                        </div>
                        <div class="lp-mock-card" style="opacity:.6">
                            <div class="lp-mock-card-head"><div class="lp-mock-title">Projects (12 matches)</div></div>
                            <div class="lp-mock-row">
                                <div class="lp-mock-avatar" style="background:var(--panel-3)"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8"/></svg></div>
                                <div class="lp-mock-line" style="max-width:160px"></div>
                                <div class="lp-mock-pill brand" style="width:38px"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="lp-mockup-fade"></div>
        </div>
    </section>

    {{-- ══════════════ STATS BAND ══════════════ --}}
    <div class="lp-stats-band">
        <div class="lp-stats-grid">
            <div><div class="lp-stat-val">500+</div><div class="lp-stat-label">Student projects published</div></div>
            <div><div class="lp-stat-val">120+</div><div class="lp-stat-label">Recruiters searching</div></div>
            <div><div class="lp-stat-val">48h</div><div class="lp-stat-label">Average account review</div></div>
            <div><div class="lp-stat-val">100%</div><div class="lp-stat-label">Real source code, always</div></div>
        </div>
    </div>

    {{-- ══════════════ FEATURES ══════════════ --}}
    <section class="lp-section" id="features">
        <div style="max-width:1100px;margin:0 auto">
            <div class="lp-section-label">Features</div>
            <h2 class="lp-section-title">Everything you need,<br>nothing you don't.</h2>
            <p class="lp-section-sub">Built for the whole journey — from uploading your first project to landing your first offer.</p>
            <div class="lp-features-grid">
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5-5 5 5"/><path d="M12 5v12"/></svg></div>
                    <h3>Upload source archives</h3>
                    <p>Zip, tar, rar, 7z — upload your full project source so recruiters can dig into the real code, not just a README.</p>
                </div>
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg></div>
                    <h3>Project screenshots</h3>
                    <p>Attach up to 5 screenshots per project so your work is visible at a glance before anyone downloads a thing.</p>
                </div>
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg></div>
                    <h3>Skill-based search</h3>
                    <p>Recruiters search by technology — Laravel, Python, React — and surface only the students who demonstrably have those skills.</p>
                </div>
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
                    <h3>Resume photo</h3>
                    <p>Add a profile photo to your student profile so recruiters can put a face to the code.</p>
                </div>
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
                    <h3>Reviewed accounts</h3>
                    <p>Every account is reviewed by an admin before going live. No spam, no fake profiles — just genuine students and real hiring teams.</p>
                </div>
                <div class="lp-feat">
                    <div class="lp-feat-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/></svg></div>
                    <h3>One-click archive download</h3>
                    <p>Authenticated download with a single click. No external hosts, no broken links — the archive lives on the platform.</p>
                </div>
            </div>
        </div>
    </section>

    {{-- ══════════════ HOW IT WORKS ══════════════ --}}
    <section class="lp-section" id="how-it-works" style="background:var(--panel);border-top:1px solid var(--line);border-bottom:1px solid var(--line)">
        <div style="max-width:1100px;margin:0 auto;display:grid;gap:40px" class="cols two">
            <div>
                <div class="lp-section-label">How it works</div>
                <h2 class="lp-section-title">From signup to discovered, in minutes.</h2>
                <p class="lp-section-sub">The whole flow is designed to be frictionless for students, and precise for recruiters.</p>
            </div>
            <div class="lp-steps">
                <div class="lp-step">
                    <div class="lp-step-line"><div class="lp-step-num">1</div><div class="lp-step-connector"></div></div>
                    <div class="lp-step-body">
                        <h3>Create your account</h3>
                        <p>Register as a student or recruiter. Verify your email, then wait for a quick admin review — usually under 48 hours.</p>
                    </div>
                </div>
                <div class="lp-step">
                    <div class="lp-step-line"><div class="lp-step-num">2</div><div class="lp-step-connector"></div></div>
                    <div class="lp-step-body">
                        <h3>Build your profile</h3>
                        <p>Students: add your name, skills, resume photo, and upload projects with source archives and screenshots.</p>
                    </div>
                </div>
                <div class="lp-step">
                    <div class="lp-step-line"><div class="lp-step-num">3</div><div class="lp-step-connector"></div></div>
                    <div class="lp-step-body">
                        <h3>Get found by recruiters</h3>
                        <p>Recruiters search by skill or project keyword. Your profile surfaces in results — with real code they can actually read.</p>
                    </div>
                </div>
                <div class="lp-step">
                    <div class="lp-step-line"><div class="lp-step-num">4</div></div>
                    <div class="lp-step-body">
                        <h3>Land the opportunity</h3>
                        <p>Recruiters review your profile, browse your source code, and reach out. Your work speaks for itself.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- ══════════════ FOR YOU ══════════════ --}}
    <section class="lp-section" id="for-you">
        <div style="max-width:1100px;margin:0 auto">
            <div class="lp-section-label">Who it's for</div>
            <h2 class="lp-section-title">Built for both sides of the table.</h2>
            <div class="lp-roles">
                <div class="lp-role lp-role-student">
                    <div class="lp-role-glow"></div>
                    <div class="lp-role-tag">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        For students
                    </div>
                    <h3>Show your work, not just your CV.</h3>
                    <p>A portfolio that proves what you can do. Real projects, real source code, real screenshots.</p>
                    <ul class="lp-role-list">
                        <li>Upload unlimited projects with source archives</li>
                        <li>Add screenshots so your work is immediately visual</li>
                        <li>List your skills and let recruiters come to you</li>
                        <li>Edit or delete projects any time</li>
                        <li>Profile photo so you're a person, not just a profile</li>
                    </ul>
                    <a href="/app" class="lp-btn-primary" style="display:inline-flex">Create student profile →</a>
                </div>
                <div class="lp-role lp-role-recruiter">
                    <div class="lp-role-glow"></div>
                    <div class="lp-role-tag">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                        For recruiters
                    </div>
                    <h3>Find the developer, not the keyword.</h3>
                    <p>Search by the technology stack you actually need. Every result has real work behind it.</p>
                    <ul class="lp-role-list">
                        <li>Search students by skill — Laravel, Python, React, anything</li>
                        <li>Search projects by name or keyword</li>
                        <li>Browse source code and download archives</li>
                        <li>View project screenshots at a glance</li>
                        <li>See resume photos alongside real project work</li>
                    </ul>
                    <a href="/app" class="lp-btn-secondary" style="display:inline-flex;background:color-mix(in srgb,#a855f7 12%,var(--panel));border-color:color-mix(in srgb,#a855f7 30%,transparent);color:var(--ink)">Start searching →</a>
                </div>
            </div>
        </div>
    </section>

    {{-- ══════════════ CTA BAND ══════════════ --}}
    <div class="lp-cta-band">
        <div class="noise"></div>
        <h2>Ready to get started?</h2>
        <p>Join hundreds of students and recruiters already using ProjectPort.</p>
        <div class="lp-hero-cta">
            <a href="/app" class="lp-btn-primary">Create your free account</a>
            <a href="#features" class="lp-btn-secondary">Learn more</a>
        </div>
    </div>

    {{-- ══════════════ FOOTER ══════════════ --}}
    <footer class="lp-footer">
        <a href="/" style="display:flex;align-items:center;gap:8px;text-decoration:none;color:inherit">
            <svg width="22" height="22" viewBox="0 0 32 32" fill="none" style="border-radius:6px">
                <rect width="32" height="32" rx="8" fill="url(#lgf)"/>
                <path d="M8 10h10a4 4 0 0 1 0 8H8z" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round"/>
                <circle cx="10.5" cy="22.5" r="2" fill="white"/>
                <defs><linearGradient id="lgf" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse"><stop stop-color="#4f46e5"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs>
            </svg>
            <span style="font-weight:700;font-size:14px;letter-spacing:-.01em">ProjectPort</span>
        </a>
        <div class="spacer"></div>
        <div class="lp-footer-links">
            <a href="#features">Features</a>
            <a href="#how-it-works">How it works</a>
            <a href="/app">Sign in</a>
        </div>
        <span class="lp-footer-copy">© {{ date('Y') }} ProjectPort. All rights reserved.</span>
    </footer>

    <script>
        // Theme toggle
        const btn = document.getElementById('lp-theme');
        const update = () => {
            const dark = document.documentElement.dataset.theme === 'dark';
            btn.textContent = dark ? '☀️' : '🌙';
        };
        btn.addEventListener('click', () => {
            const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
            document.documentElement.dataset.theme = next;
            localStorage.setItem('pp.theme', next);
            update();
        });
        const saved = localStorage.getItem('pp.theme');
        if (saved) document.documentElement.dataset.theme = saved;
        else if (matchMedia('(prefers-color-scheme: light)').matches) document.documentElement.dataset.theme = 'light';
        update();

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(a => {
            a.addEventListener('click', e => {
                const target = document.querySelector(a.getAttribute('href'));
                if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
            });
        });
    </script>
</body>
</html>
