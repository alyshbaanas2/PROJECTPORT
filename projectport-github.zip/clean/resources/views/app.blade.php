<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="ProjectPort — students publish their projects and source code; recruiters find them by skill.">
    <title>ProjectPort</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%234f46e5'/><path d='M8 10h10a4 4 0 0 1 0 8H8z' fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round'/><circle cx='10.5' cy='22.5' r='2' fill='white'/></svg>">
    <link rel="stylesheet" href="{{ asset('assets/app.css') }}?v={{ filemtime(public_path('assets/app.css')) }}">
</head>
<body>
    <div id="app"></div>
    <div class="toasts" id="toasts" aria-live="polite"></div>
    <script src="{{ asset('assets/app.js') }}?v={{ filemtime(public_path('assets/app.js')) }}"></script>
</body>
</html>
