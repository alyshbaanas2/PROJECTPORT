/**
 * ProjectPort web client.
 *
 * Talks to the ProjectPort API. Authentication is a stateless JWT: the access
 * token is sent in the Authorization header and the refresh token is rotated
 * automatically when the access token expires.
 */
(() => {
    'use strict';

    /* ================================ icons ================================ */

    const icon = (name, size = 17) => {
        const paths = {
            user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
            search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
            shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
            box: '<path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
            check: '<path d="M20 6 9 17l-5-5"/>',
            x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
            upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5-5 5 5"/><path d="M12 5v12"/>',
            download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
            mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-10 6L2 7"/>',
            inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.5 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.5A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.5z"/>',
            logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
            sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M5 5l1.5 1.5M17.5 17.5 19 19M2 12h2M20 12h2M5 19l1.5-1.5M17.5 6.5 19 5"/>',
            info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
            edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
            trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
            heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
            'heart-fill': '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" fill="currentColor"/>',
            message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
            store: '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
            filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
            video: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>',
            sparkles: '<path d="M12 3L9.5 9.5 3 12l6.5 2.5L12 21l2.5-6.5L21 12l-6.5-2.5z"/><path d="M5 3v4M3 5h4M19 17v4M17 19h4"/>',
            bot: '<rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" y1="16" x2="8" y2="16"/><line x1="16" y1="16" x2="16" y2="16"/>',
            award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
            'play-circle': '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>',
            'check-circle': '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
        };
        return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor"
            stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] || ''}</svg>`;
    };

    /* ================================ store ================================ */

    const store = {
        get access() { return localStorage.getItem('pp.access'); },
        set access(v) { v ? localStorage.setItem('pp.access', v) : localStorage.removeItem('pp.access'); },
        get refresh() { return localStorage.getItem('pp.refresh'); },
        set refresh(v) { v ? localStorage.setItem('pp.refresh', v) : localStorage.removeItem('pp.refresh'); },
        get user() { try { return JSON.parse(localStorage.getItem('pp.user')); } catch { return null; } },
        set user(v) { v ? localStorage.setItem('pp.user', JSON.stringify(v)) : localStorage.removeItem('pp.user'); },
        clear() { this.access = null; this.refresh = null; this.user = null; },
    };

    /* ============================== api client ============================= */

    class ApiError extends Error {
        constructor(status, body) {
            super(body?.message || 'Something went wrong.');
            this.status = status;
            this.code = body?.error || 'UNKNOWN';
            this.field = body?.field || null;
        }
    }

    async function request(method, path, { body, auth = true, retry = true } = {}) {
        const headers = { Accept: 'application/json' };
        if (auth && store.access) headers.Authorization = `Bearer ${store.access}`;

        let payload = body;
        if (body && !(body instanceof FormData)) {
            headers['Content-Type'] = 'application/json';
            payload = JSON.stringify(body);
        }

        const res = await fetch(`/api${path}`, { method, headers, body: payload });
        const data = res.status === 204 ? null : await res.json().catch(() => null);

        if (res.ok) return data;

        const expired = res.status === 401 && ['TOKEN_EXPIRED', 'UNAUTHENTICATED'].includes(data?.error);
        if (expired && retry && auth && store.refresh && await rotate()) {
            return request(method, path, { body, auth, retry: false });
        }

        if (res.status === 401 && auth) signOutLocally();

        throw new ApiError(res.status, data);
    }

    async function rotate() {
        try {
            const data = await request('POST', '/auth/refresh', {
                body: { refresh_token: store.refresh }, auth: false, retry: false,
            });
            store.access = data.access_token;
            store.refresh = data.refresh_token;
            return true;
        } catch {
            store.clear();
            return false;
        }
    }

    const qs = (params) => Object.entries(params)
        .filter(([, v]) => v !== '' && v !== null && v !== undefined)
        .map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

    const api = {
        register: (b) => request('POST', '/auth/register', { body: b, auth: false }),
        verify: (t) => request('GET', `/auth/verify-email/${encodeURIComponent(t)}`, { auth: false }),
        resend: (email) => request('POST', '/auth/verify-email/resend', { body: { email }, auth: false }),
        login: (b) => request('POST', '/auth/login', { body: b, auth: false }),
        logout: () => request('POST', '/auth/logout'),
        me: () => request('GET', '/students/me/profile'),
        saveProfile: (f) => request('PATCH', '/students/me/profile', { body: f }),
        addProject: (f) => request('POST', '/students/me/projects', { body: f }),
        updateProject: (id, f) => request('PATCH', `/students/me/projects/${id}`, { body: f }),
        deleteProject: (id) => request('DELETE', `/students/me/projects/${id}`),
        student: (id) => request('GET', `/students/${id}`),
        findStudents: (p) => request('GET', `/search/students?${qs(p)}`),
        findProjects: (p) => request('GET', `/search/projects?${qs(p)}`),
        projectFiles: (id) => request('GET', `/projects/${id}/source-code/contents`),
        queue: (p) => request('GET', `/admin/registrations?${qs(p)}`),
        approve: (id) => request('POST', `/admin/registrations/${id}/approve`),
        reject: (id) => request('POST', `/admin/registrations/${id}/reject`),
        // Marketplace
        marketplace: (p) => request('GET', `/marketplace?${qs(p)}`),
        likeProject: (id) => request('POST', `/projects/${id}/like`),
        unlikeProject: (id) => request('DELETE', `/projects/${id}/like`),
        addComment: (id, body) => request('POST', `/projects/${id}/comments`, { body: { body } }),
        deleteComment: (id) => request('DELETE', `/comments/${id}`),
        // Courses
        getCourses: () => request('GET', '/courses'),
        markWatched: (id) => request('POST', `/courses/${id}/progress`),
        certify: (id) => request('POST', `/courses/${id}/certify`),
        aiChat: (id, question) => request('POST', `/courses/${id}/ai-chat`, { body: { question } }),
    };

    /**
     * Downloads a source archive. The JWT lives in the Authorization header, so
     * the file is fetched as a blob and handed to the browser rather than being
     * linked to directly.
     */
    async function downloadArchive(projectId, retry = true) {
        const res = await fetch(`/api/projects/${projectId}/source-code`, {
            headers: { Authorization: `Bearer ${store.access}` },
        });

        if (!res.ok) {
            const body = await res.json().catch(() => null);
            if (res.status === 401 && retry && store.refresh && await rotate()) {
                return downloadArchive(projectId, false);
            }
            throw new ApiError(res.status, body);
        }

        const disposition = res.headers.get('Content-Disposition') || '';
        const named = /filename="?([^"';]+)"?/i.exec(disposition);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = named ? named[1] : `project-${projectId}.zip`;
        document.body.append(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);

        return link.download;
    }

    /* =============================== helpers ============================== */

    const $ = (s, root = document) => root.querySelector(s);
    const $$ = (s, root = document) => [...root.querySelectorAll(s)];
    const app = $('#app');

    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    const initials = (user) => {
        const src = (user?.name || user?.email || '?').trim();
        const parts = src.split(/[\s@._-]+/).filter(Boolean);
        return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || src[0].toUpperCase();
    };

    const avatar = (user, cls = '') => `<div class="avatar ${cls}">${esc(initials(user))}</div>`;
    const pill = (text, kind = '') => `<span class="pill ${kind}">${esc(text)}</span>`;
    const tagList = (skills) => (skills || '').split(',').map((s) => s.trim()).filter(Boolean);

    const when = (iso) => {
        if (!iso) return '—';
        const days = Math.floor((Date.now() - new Date(iso)) / 86400000);
        if (days <= 0) return 'Today';
        if (days === 1) return 'Yesterday';
        if (days < 30) return `${days} days ago`;
        return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
    };

    function toast(kind, title, message = '') {
        const el = document.createElement('div');
        el.className = `toast ${kind}`;
        el.innerHTML = `<div>${icon(kind === 'ok' ? 'check' : 'info', 16)}</div>
            <div><div class="t">${esc(title)}</div>${message ? `<div class="m">${esc(message)}</div>` : ''}</div>`;
        $('#toasts').append(el);
        setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 250); }, 5200);
    }

    function fail(error, form) {
        if (!(error instanceof ApiError)) {
            toast('err', 'Connection lost', 'The server did not respond. Check that it is running.');
            return;
        }
        if (form && error.field) {
            const input = form.querySelector(`[name="${error.field}"]`);
            if (input) {
                input.classList.add('invalid');
                let note = input.parentElement.querySelector('.field-error');
                if (!note) {
                    note = document.createElement('div');
                    note.className = 'field-error';
                    input.parentElement.append(note);
                }
                note.textContent = error.message;
                input.focus();
                return;
            }
        }
        const titles = {
            INVALID_CREDENTIALS: 'Incorrect email or password',
            EMAIL_NOT_VERIFIED: 'Email not verified',
            EMAIL_ALREADY_REGISTERED: 'Email already registered',
            ACCOUNT_NOT_ACTIVE: 'Account awaiting approval',
            REGISTRATION_ALREADY_DECIDED: 'Already decided',
            INVALID_VERIFICATION_TOKEN: 'Link is not valid',
            RATE_LIMIT_EXCEEDED: 'Too many attempts',
            FORBIDDEN: 'Not allowed',
            NOT_FOUND: 'Not found',
        };
        toast('err', titles[error.code] || 'Request failed', error.message);
    }

    function clearErrors(form) {
        $$('.invalid', form).forEach((el) => el.classList.remove('invalid'));
        $$('.field-error', form).forEach((el) => el.remove());
    }

    function busy(button, on) {
        if (!button) return;
        if (on) {
            button.dataset.label = button.innerHTML;
            button.disabled = true;
            button.innerHTML = '<span class="spinner"></span>';
        } else {
            button.disabled = false;
            if (button.dataset.label) button.innerHTML = button.dataset.label;
        }
    }

    async function submit(form, button, work) {
        clearErrors(form);
        busy(button, true);
        try { await work(); } catch (error) { fail(error, form); } finally { busy(button, false); }
    }

    function sheet(html) {
        const scrim = document.createElement('div');
        scrim.className = 'scrim';
        scrim.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">${html}</div>`;
        const close = () => scrim.remove();
        scrim.addEventListener('click', (e) => { if (e.target === scrim) close(); });
        document.addEventListener('keydown', function onKey(e) {
            if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); }
        });
        $$('[data-close]', scrim).forEach((b) => b.addEventListener('click', close));
        document.body.append(scrim);
        return { el: scrim, close };
    }

    const fileSize = (bytes) => {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / 1048576).toFixed(1)} MB`;
    };

    /** Saves an archive and reports the outcome, wherever the button lives. */
    async function saveArchive(project, button) {
        busy(button, true);
        try {
            const name = await downloadArchive(project.id);
            toast('ok', 'Download started', name);
        } catch (error) { fail(error); } finally { busy(button, false); }
    }

    /** Opens a project: the files inside its archive, plus a download. */
    async function openProject(project) {
        const { el } = sheet(`
            <div class="sheet-head">
                <div class="avatar">${icon('box', 16)}</div>
                <div><div class="section-title">${esc(project.name)}</div>
                <div class="section-sub">Source archive</div></div>
            </div>
            ${project.screenshots?.length ? `
            <div style="padding:16px 20px 0">
                <div class="section-sub" style="margin-bottom:8px">Screenshots</div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">${
                    project.screenshots.map((url) =>
                        `<a href="${esc(url)}" target="_blank" rel="noopener">
                            <img src="${esc(url)}" alt="screenshot" style="width:96px;height:72px;object-fit:cover;border-radius:6px;border:1px solid var(--line)">
                        </a>`
                    ).join('')}</div>
            </div>` : ''}
            <div class="sheet-body" id="files"><div class="stack">
                <div class="skeleton row"></div><div class="skeleton row"></div></div></div>
            <div class="sheet-foot">
                <button class="btn ghost" data-close>Close</button>
                <button class="btn" id="dl">${icon('download', 15)} Download archive</button>
            </div>`);

        $('#dl', el).addEventListener('click', (e) => saveArchive(project, e.currentTarget));

        try {
            const data = await api.projectFiles(project.id);
            $('#files', el).innerHTML = `
                <div class="section-sub" style="margin-bottom:10px">
                    ${data.total_files} file${data.total_files === 1 ? '' : 's'} in <code>${esc(data.download_name)}</code>
                </div>
                <div class="table-wrap"><table>
                    <thead><tr><th>File</th><th>Size</th></tr></thead>
                    <tbody>${data.files.map((f) => `<tr>
                        <td><code>${esc(f.name)}</code></td>
                        <td class="muted nowrap">${esc(fileSize(f.size))}</td></tr>`).join('')}</tbody>
                </table></div>
                ${data.truncated ? '<div class="hint" style="margin-top:10px">Only the first 500 files are listed. Download the archive to see everything.</div>' : ''}`;
        } catch (error) {
            $('#files', el).innerHTML = `<div class="banner warn">${icon('info', 18)}<div>
                <b>No file listing</b>${esc(error.message || 'This archive cannot be previewed.')}</div></div>`;
        }
    }

    const emptyState = (name, title, body) => `
        <div class="empty">
            <div class="ico">${icon(name, 20)}</div>
            <h3>${esc(title)}</h3>
            <p>${esc(body)}</p>
        </div>`;

    const skeletonRows = (n = 4) => `<div class="card-body stack">${
        Array.from({ length: n }, () => '<div class="skeleton row"></div>').join('')}</div>`;

    /* ============================== auth screen ============================ */

    function authScreen() {
        document.body.className = 'auth-body';
        app.innerHTML = `
        <div class="auth">
            <aside class="auth-aside">
                <a class="brand" href="#/"><span class="brand-mark">PP</span> ProjectPort</a>
                <h2>Student work, ready for the people who hire.</h2>
                <p>A single place for students to publish real projects with their source code, and for recruiters to find them by the skills they actually have.</p>
                <ul class="auth-points">
                    <li>${icon('box', 18)}<span>Publish projects with downloadable source archives</span></li>
                    <li>${icon('search', 18)}<span>Recruiters search by skill, keyword and project</span></li>
                    <li>${icon('shield', 18)}<span>Every account is reviewed before it goes live</span></li>
                </ul>
            </aside>
            <main class="auth-main">
                <div class="auth-card">
                    <a class="brand" href="#/"><span class="brand-mark">PP</span> ProjectPort</a>
                    <div class="auth-switch" role="tablist">
                        <button role="tab" aria-selected="true" data-pane="signin">Sign in</button>
                        <button role="tab" aria-selected="false" data-pane="signup">Create account</button>
                    </div>
                    <div id="pane"></div>
                </div>
            </main>
        </div>`;

        const panes = {
            signin: () => `
                <form id="form-signin" novalidate>
                    <div class="fields">
                        <div class="field">
                            <label for="in-email">Email</label>
                            <input id="in-email" name="email" type="email" autocomplete="username" placeholder="you@example.com" required>
                        </div>
                        <div class="field">
                            <label for="in-password">Password</label>
                            <input id="in-password" name="password" type="password" autocomplete="current-password" placeholder="••••••••" required>
                        </div>
                    </div>
                    <div style="margin-top:20px"><button class="btn lg block" type="submit">Sign in</button></div>
                </form>
                <div id="signin-notice"></div>
                <div class="auth-foot">Have a verification link? <button type="button" id="open-verify">Verify your email</button></div>`,
            signup: () => `
                <form id="form-signup" novalidate>
                    <div class="fields">
                        <div class="field">
                            <label for="up-name">Full name</label>
                            <input id="up-name" name="name" type="text" autocomplete="name" placeholder="Ada Lovelace">
                        </div>
                        <div class="field">
                            <label for="up-email">Email</label>
                            <input id="up-email" name="email" type="email" autocomplete="email" placeholder="you@example.com" required>
                        </div>
                        <div class="field">
                            <label for="up-role">I am joining as</label>
                            <select id="up-role" name="role">
                                <option value="student">A student sharing my work</option>
                                <option value="recruiter">A recruiter looking for talent</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="up-password">Password</label>
                            <input id="up-password" name="password" type="password" autocomplete="new-password" placeholder="At least 8 characters" required>
                            <div class="hint">Use at least 8 characters.</div>
                        </div>
                    </div>
                    <div style="margin-top:20px"><button class="btn lg block" type="submit">Create account</button></div>
                </form>
                <div class="auth-foot">We email you a link to confirm your address. An administrator reviews new accounts before they go live.</div>`,
        };

        function showPane(name) {
            $$('.auth-switch button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.pane === name)));
            $('#pane').innerHTML = panes[name]();
            name === 'signin' ? wireSignIn() : wireSignUp();
        }

        $$('.auth-switch button').forEach((b) => b.addEventListener('click', () => showPane(b.dataset.pane)));

        function wireSignIn() {
            const form = $('#form-signin');
            const button = form.querySelector('button');

            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                clearErrors(form);
                $('#signin-notice').innerHTML = '';
                busy(button, true);
                try {
                    const data = await api.login(Object.fromEntries(new FormData(form)));
                    store.access = data.access_token;
                    store.refresh = data.refresh_token;
                    store.user = data.user;
                    toast('ok', `Welcome back${data.user.name ? `, ${data.user.name.split(' ')[0]}` : ''}`);
                    navigate(landingFor(data.user));
                } catch (error) {
                    // An unverified address is recoverable in place rather than a dead end.
                    if (error instanceof ApiError && error.code === 'EMAIL_NOT_VERIFIED') {
                        unverifiedNotice($('#in-email').value.trim());
                    } else {
                        fail(error, form);
                    }
                } finally {
                    busy(button, false);
                }
            });

            $('#open-verify').addEventListener('click', () => verifySheet($('#in-email').value.trim()));
        }

        /** Offers the two ways out of an unverified address: resend, or paste the token. */
        function unverifiedNotice(email) {
            $('#signin-notice').innerHTML = `
                <div class="banner warn" style="margin-top:16px">
                    ${icon('mail', 18)}
                    <div>
                        <b>Confirm your email first</b>
                        We need to know this address is yours before you can sign in.
                        <div style="display:flex;gap:8px;margin-top:11px;flex-wrap:wrap">
                            <button class="btn sm" id="do-resend">Resend email</button>
                            <button class="btn ghost sm" id="have-token">I have a token</button>
                        </div>
                    </div>
                </div>`;

            // NB: capture the button now — e.currentTarget is null once we await.
            $('#do-resend').addEventListener('click', async (e) => {
                const button = e.currentTarget;
                busy(button, true);
                try {
                    const data = await api.resend(email);
                    toast('ok', 'Verification email sent', data.message);
                } catch (error) { fail(error); } finally { busy(button, false); }
            });

            $('#have-token').addEventListener('click', () => verifySheet(email));
        }

        function wireSignUp() {
            const form = $('#form-signup');
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                submit(form, form.querySelector('button'), async () => {
                    const data = await api.register(Object.fromEntries(new FormData(form)));
                    form.reset();
                    sheet(`
                        <div class="sheet-head"><h2 class="section-title">Check your inbox</h2></div>
                        <div class="sheet-body stack">
                            <div class="banner info">${icon('mail', 18)}<div><b>Verification email sent</b>
                                We sent a confirmation link to ${esc(data.user.email)}. Open it to activate your sign-in.</div></div>
                            <p class="section-sub">Once your email is confirmed, an administrator reviews the account. You will be able to sign in as soon as the review is done.</p>
                        </div>
                        <div class="sheet-foot"><button class="btn" data-close>Got it</button></div>`);
                });
            });
        }

        function verifySheet(email = '') {
            const { el, close } = sheet(`
                <div class="sheet-head"><h2 class="section-title">Verify your email</h2></div>
                <div class="sheet-body">
                    <form id="form-verify" novalidate>
                        <div class="field">
                            <label for="vf-token">Verification token</label>
                            <input id="vf-token" name="token" type="text" placeholder="Paste the token from your email link" required>
                            <div class="hint">It is the last part of the link we emailed you.</div>
                        </div>
                    </form>
                    ${email ? `<div class="auth-foot" style="text-align:left;margin-top:16px">
                        Nothing in your inbox? <button type="button" id="sheet-resend">Send it again to ${esc(email)}</button>
                    </div>` : ''}
                </div>
                <div class="sheet-foot">
                    <button class="btn ghost" data-close>Cancel</button>
                    <button class="btn" id="do-verify">Verify email</button>
                </div>`);

            $('#sheet-resend', el)?.addEventListener('click', async (e) => {
                const button = e.currentTarget;
                busy(button, true);
                try {
                    const data = await api.resend(email);
                    toast('ok', 'Verification email sent', data.message);
                } catch (error) { fail(error); } finally { busy(button, false); }
            });

            const form = $('#form-verify', el);
            const run = () => submit(form, $('#do-verify', el), async () => {
                const data = await api.verify($('#vf-token', el).value.trim());
                close();
                toast('ok', 'Email verified', `${data.user.email} can now sign in.`);
            });

            $('#do-verify', el).addEventListener('click', run);
            form.addEventListener('submit', (e) => { e.preventDefault(); run(); });
        }

        showPane('signin');
    }

    /* =============================== app shell ============================ */

    const NAV = {
        student:   [['#/profile', 'My profile', 'user'], ['#/projects', 'My projects', 'box'], ['#/marketplace', 'Marketplace', 'store'], ['#/courses', 'Courses', 'video']],
        recruiter: [['#/search', 'Find talent', 'search'], ['#/marketplace', 'Marketplace', 'store']],
        admin:     [['#/admin', 'Registrations', 'inbox'], ['#/marketplace', 'Marketplace', 'store']],
    };

    const landingFor = (user) => ({ student: '/profile', recruiter: '/search', admin: '/admin' }[user?.role] || '/');

    function shell(title, bodyHtml) {
        const user = store.user;
        document.body.className = 'app-body';
        app.innerHTML = `
        <div class="shell">
            <aside class="sidebar">
                <a class="brand" href="#${landingFor(user)}"><span class="brand-mark">PP</span> ProjectPort</a>
                <div class="side-label">Workspace</div>
                <nav class="side-nav">${(NAV[user?.role] || []).map(([href, label, ico]) =>
                    `<a href="${href}" data-nav="${href}">${icon(ico)} ${label}</a>`).join('')}</nav>
                <div class="side-foot">
                    <div class="user-chip">
                        ${avatar(user)}
                        <div class="meta">
                            <div class="name">${esc(user?.name || user?.email || '')}</div>
                            <div class="sub">${esc(user?.role || '')}</div>
                        </div>
                    </div>
                    <button class="btn quiet block" id="sign-out" style="justify-content:flex-start">${icon('logout')} Sign out</button>
                </div>
            </aside>
            <div>
                <header class="topbar">
                    <div class="topbar-title">${esc(title)}</div>
                    <div class="spacer"></div>
                    <button class="btn ghost icon" id="theme" title="Switch theme" aria-label="Switch theme">${icon('sun', 16)}</button>
                </header>
                <main class="content" id="content">${bodyHtml}</main>
            </div>
        </div>`;

        const current = location.hash || '#/';
        $$('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === current));
        $('#sign-out').addEventListener('click', signOut);
        $('#theme').addEventListener('click', toggleTheme);
        return $('#content');
    }

    /* ============================ student screens ========================= */

    async function profileScreen() {
        const content = shell('My profile', `<div class="card">${skeletonRows(3)}</div>`);

        let student;
        try { ({ student } = await api.me()); } catch (error) { return blocked(content, error); }

        store.user = { ...store.user, ...student };

        content.innerHTML = `
        <div class="page-head">
            <div>
                <h1 class="page-title">My profile</h1>
                <p class="page-sub">This is what recruiters see when they find you.</p>
            </div>
            <div class="spacer"></div>
            <a class="btn ghost" href="#/projects">${icon('box', 16)} My projects</a>
        </div>

        <div class="cols side">
            <div class="stack">
                <div class="card">
                    <div class="card-body" style="text-align:center">
                        ${avatar(student, 'lg')}
                        <div style="margin-top:12px;font-weight:650;font-size:16px">${esc(student.name || 'Add your name')}</div>
                        <div class="muted" style="font-size:13px">${esc(student.email)}</div>
                        <div style="margin-top:12px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">
                            ${pill(student.status, student.status)}
                            ${student.email_verified ? pill('email verified', 'approved') : pill('email unverified', 'pending')}
                        </div>
                    </div>
                    <div class="card-foot" style="justify-content:space-between">
                        <span class="muted" style="font-size:13px">Projects</span>
                        <strong>${student.projects?.length || 0}</strong>
                    </div>
                </div>
                ${student.status !== 'active' ? `
                <div class="banner warn">${icon('info', 18)}<div><b>Account under review</b>
                    An administrator is reviewing your account. You can prepare your profile in the meantime.</div></div>` : ''}
            </div>

            <div class="card">
                <div class="card-head">
                    <div>
                        <div class="section-title">Profile details</div>
                        <div class="section-sub">Your skills drive how recruiters find you.</div>
                    </div>
                </div>
                <div class="card-body">
                    <form id="form-profile" novalidate>
                        <div class="fields">
                            <div class="field">
                                <label for="pf-name">Full name</label>
                                <input id="pf-name" name="name" type="text" value="${esc(student.name || '')}" placeholder="Ada Lovelace">
                            </div>
                            <div class="field">
                                <label for="pf-skills">Skills</label>
                                <textarea id="pf-skills" name="skills" placeholder="php, laravel, mysql, api design">${esc(student.skills || '')}</textarea>
                                <div class="hint">Separate skills with commas.</div>
                            </div>
                            <div class="field">
                                <label>Resume / Profile photo</label>
                                <label class="dropzone" id="dz-resume">
                                    <input type="file" name="resume_photo" id="pf-photo" accept=".jpg,.jpeg,.png,.webp">
                                    ${student.resume_photo
                                        ? `<img id="resume-preview" src="${esc(student.resume_photo)}" alt="Current resume photo" style="max-height:100px;border-radius:8px;object-fit:cover">`
                                        : `<div>${icon('upload', 20)}</div>`}
                                    <div class="dz-title" id="dz-resume-title">${student.resume_photo ? 'Replace photo' : 'Choose a photo or drop it here'}</div>
                                    <div class="dz-sub">jpg, jpeg, png or webp · up to 2 MB</div>
                                </label>
                                ${student.resume_photo ? `<button type="button" class="btn ghost sm" id="remove-photo" style="margin-top:6px">${icon('x', 14)} Remove photo</button>` : ''}
                            </div>
                        </div>
                        <div class="tags" id="tag-preview" style="margin-top:14px">${
                            tagList(student.skills).map((t) => `<span class="tag">${esc(t)}</span>`).join('')}</div>
                        <div style="margin-top:20px"><button class="btn" type="submit">Save changes</button></div>
                    </form>
                </div>
            </div>
        </div>`;

        const form = $('#form-profile');
        $('#pf-skills').addEventListener('input', (e) => {
            $('#tag-preview').innerHTML = tagList(e.target.value).map((t) => `<span class="tag">${esc(t)}</span>`).join('');
        });

        // Resume photo picker — show a live preview on selection.
        const photoInput = $('#pf-photo');
        const dzResume = $('#dz-resume');
        if (photoInput) {
            photoInput.addEventListener('change', () => {
                const file = photoInput.files[0];
                if (!file) return;
                $('#dz-resume-title').textContent = file.name;
                dzResume.classList.add('filled');
                const reader = new FileReader();
                reader.onload = (ev) => {
                    let preview = $('#resume-preview');
                    if (!preview) {
                        preview = document.createElement('img');
                        preview.id = 'resume-preview';
                        preview.alt = 'Resume photo preview';
                        preview.style.cssText = 'max-height:100px;border-radius:8px;object-fit:cover';
                        dzResume.insertBefore(preview, dzResume.firstChild);
                    }
                    preview.src = ev.target.result;
                };
                reader.readAsDataURL(file);
            });
            ['dragenter', 'dragover'].forEach((ev) => dzResume.addEventListener(ev, (e) => { e.preventDefault(); dzResume.classList.add('drag'); }));
            ['dragleave', 'drop'].forEach((ev) => dzResume.addEventListener(ev, () => dzResume.classList.remove('drag')));
            dzResume.addEventListener('drop', (e) => {
                e.preventDefault();
                if (e.dataTransfer.files.length) { photoInput.files = e.dataTransfer.files; photoInput.dispatchEvent(new Event('change')); }
            });
        }

        // "Remove photo" clears the current photo server-side.
        $('#remove-photo')?.addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            busy(btn, true);
            try {
                const fd = new FormData();
                fd.append('name', $('#pf-name').value);
                fd.append('skills', $('#pf-skills').value);
                fd.append('resume_photo', '');          // empty string signals removal
                await api.saveProfile(fd);
                toast('ok', 'Photo removed');
                render();
            } catch (error) { fail(error); } finally { busy(btn, false); }
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            submit(form, form.querySelector('button[type="submit"]'), async () => {
                const fd = new FormData(form);
                // If the file input is empty and there's already a photo, omit the
                // field entirely so the existing photo is kept untouched.
                if (photoInput && !photoInput.files.length) fd.delete('resume_photo');
                const { student: saved } = await api.saveProfile(fd);
                store.user = { ...store.user, ...saved };
                toast('ok', 'Profile saved');
                render();
            });
        });
    }

    async function projectsScreen() {
        const content = shell('My projects', `<div class="card">${skeletonRows(3)}</div>`);

        let student;
        try { ({ student } = await api.me()); } catch (error) { return blocked(content, error); }

        const rows = (student.projects || []).map((p) => `
            <tr>
                <td><div class="cell-user"><div class="avatar">${icon('box', 15)}</div>
                    <div><div class="nm">${esc(p.name)}</div>
                    <div class="em">Added ${esc(when(p.created_at))}</div>
                    ${p.screenshots?.length ? `<div style="display:flex;gap:4px;margin-top:5px;flex-wrap:wrap">${
                        p.screenshots.slice(0, 3).map((url) =>
                            `<img src="${esc(url)}" alt="screenshot" style="width:36px;height:36px;object-fit:cover;border-radius:4px;border:1px solid var(--line)">`
                        ).join('')}${p.screenshots.length > 3 ? `<span class="muted" style="font-size:11px;align-self:center">+${p.screenshots.length - 3}</span>` : ''}</div>` : ''}
                    </div></div></td>
                <td class="nowrap">${pill('published', 'approved')}</td>
                <td class="actions">
                    <button class="btn ghost sm" data-open="${p.id}">View files</button>
                    <button class="btn ghost sm" data-edit="${p.id}">${icon('edit', 14)}</button>
                    <button class="btn ghost sm" data-download="${p.id}">${icon('download', 14)}</button>
                    <button class="btn bad sm" data-delete="${p.id}">${icon('trash', 14)}</button>
                </td>
            </tr>`).join('');

        content.innerHTML = `
        <div class="page-head">
            <div>
                <h1 class="page-title">My projects</h1>
                <p class="page-sub">Upload the work you want recruiters to see, with its source archive.</p>
            </div>
        </div>

        <div class="cols side">
            <div class="card">
                <div class="card-head"><div>
                    <div class="section-title">Upload a project</div>
                    <div class="section-sub">Zip your source before uploading.</div>
                </div></div>
                <div class="card-body">
                    <form id="form-project" novalidate>
                        <div class="fields">
                            <div class="field">
                                <label for="pj-name">Project name</label>
                                <input id="pj-name" name="project_name" type="text" placeholder="Distributed Ledger Explorer" required>
                                <div class="hint">At least 5 characters.</div>
                            </div>
                            <div class="field">
                                <label>Source archive</label>
                                <label class="dropzone" id="dz">
                                    <input type="file" name="source_code" accept=".zip,.tar,.gz,.tgz,.rar,.7z" required>
                                    <div>${icon('upload', 20)}</div>
                                    <div class="dz-title" id="dz-title">Choose a file or drop it here</div>
                                    <div class="dz-sub">zip, tar, gz, tgz, rar or 7z · up to 50 MB</div>
                                </label>
                            </div>
                            <div class="field">
                                <label>Screenshots <span class="muted" style="font-weight:400;font-size:12px">(optional, up to 5)</span></label>
                                <label class="dropzone" id="dz-shots">
                                    <input type="file" name="screenshots[]" id="shots-input" accept=".jpg,.jpeg,.png,.gif,.webp" multiple>
                                    <div>${icon('upload', 20)}</div>
                                    <div class="dz-title" id="dz-shots-title">Choose images or drop them here</div>
                                    <div class="dz-sub">jpg, jpeg, png, gif or webp · up to 5 MB each · max 5 images</div>
                                </label>
                                <div id="shots-preview" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"></div>
                            </div>
                        </div>
                        <div style="margin-top:20px"><button class="btn block" type="submit">Publish project</button></div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-head">
                    <div><div class="section-title">Published</div>
                    <div class="section-sub">${student.projects?.length || 0} project(s) on your profile</div></div>
                </div>
                ${rows ? `<div class="table-wrap"><table>
                    <thead><tr><th>Project</th><th>Status</th><th></th></tr></thead>
                    <tbody>${rows}</tbody></table></div>`
                    : emptyState('box', 'No projects yet', 'Upload your first project to appear in recruiter searches.')}
            </div>
        </div>`;

        const byId = (id) => (student.projects || []).find((p) => String(p.id) === String(id));
        $$('[data-open]').forEach((b) => b.addEventListener('click', () => openProject(byId(b.dataset.open))));
        $$('[data-download]').forEach((b) => b.addEventListener('click', (e) =>
            saveArchive(byId(b.dataset.download), e.currentTarget)));
        $$('[data-edit]').forEach((b) => b.addEventListener('click', () =>
            editProjectSheet(byId(b.dataset.edit))));
        $$('[data-delete]').forEach((b) => b.addEventListener('click', () =>
            confirmDeleteProject(byId(b.dataset.delete))));

        const form = $('#form-project');
        const input = $('#dz input');
        const dz = $('#dz');

        input.addEventListener('change', () => {
            const file = input.files[0];
            $('#dz-title').textContent = file ? file.name : 'Choose a file or drop it here';
            dz.classList.toggle('filled', Boolean(file));
        });
        ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('drag'); }));
        ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, () => dz.classList.remove('drag')));
        dz.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files.length) { input.files = e.dataTransfer.files; input.dispatchEvent(new Event('change')); }
        });

        // Screenshots picker — show thumbnails as files are selected.
        const shotsInput = $('#shots-input');
        const dzShots = $('#dz-shots');
        shotsInput.addEventListener('change', () => {
            const files = [...shotsInput.files];
            $('#dz-shots-title').textContent = files.length
                ? `${files.length} image${files.length > 1 ? 's' : ''} selected`
                : 'Choose images or drop them here';
            dzShots.classList.toggle('filled', files.length > 0);
            const preview = $('#shots-preview');
            preview.innerHTML = '';
            files.slice(0, 5).forEach((file) => {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const img = document.createElement('img');
                    img.src = ev.target.result;
                    img.alt = file.name;
                    img.title = file.name;
                    img.style.cssText = 'width:72px;height:72px;object-fit:cover;border-radius:6px;border:1px solid var(--line)';
                    preview.append(img);
                };
                reader.readAsDataURL(file);
            });
        });
        ['dragenter', 'dragover'].forEach((ev) => dzShots.addEventListener(ev, (e) => { e.preventDefault(); dzShots.classList.add('drag'); }));
        ['dragleave', 'drop'].forEach((ev) => dzShots.addEventListener(ev, () => dzShots.classList.remove('drag')));
        dzShots.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files.length) { shotsInput.files = e.dataTransfer.files; shotsInput.dispatchEvent(new Event('change')); }
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            submit(form, form.querySelector('button'), async () => {
                const data = await api.addProject(new FormData(form));
                toast('ok', 'Project published', `${data.project.name} is now on your profile.`);
                render();
            });
        });
    }

    /** Edit project name and/or replace screenshots. */
    function editProjectSheet(project) {
        const { el, close } = sheet(`
            <div class="sheet-head">
                <div class="avatar">${icon('edit', 16)}</div>
                <div><div class="section-title">Edit project</div>
                <div class="section-sub">${esc(project.name)}</div></div>
            </div>
            <div class="sheet-body">
                <form id="form-edit-project" novalidate>
                    <div class="fields">
                        <div class="field">
                            <label for="ep-name">Project name</label>
                            <input id="ep-name" name="project_name" type="text"
                                value="${esc(project.name)}" placeholder="Project name" required>
                            <div class="hint">At least 5 characters.</div>
                        </div>
                        <div class="field">
                            <label>Screenshots
                                <span class="muted" style="font-weight:400;font-size:12px">
                                    (optional — uploading new ones replaces the existing set)
                                </span>
                            </label>
                            ${project.screenshots?.length ? `
                            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px" id="current-shots">
                                ${project.screenshots.map((url) =>
                                    `<img src="${esc(url)}" alt="screenshot"
                                        style="width:72px;height:72px;object-fit:cover;border-radius:6px;border:1px solid var(--line)">`
                                ).join('')}
                            </div>
                            <button type="button" class="btn ghost sm" id="clear-shots" style="margin-bottom:10px">
                                ${icon('trash', 13)} Remove all screenshots
                            </button>` : ''}
                            <label class="dropzone" id="dz-edit-shots">
                                <input type="file" name="screenshots[]" id="edit-shots-input"
                                    accept=".jpg,.jpeg,.png,.gif,.webp" multiple>
                                <div>${icon('upload', 18)}</div>
                                <div class="dz-title" id="dz-edit-shots-title">Choose images or drop here</div>
                                <div class="dz-sub">jpg, jpeg, png, gif or webp · up to 5 MB each · max 5</div>
                            </label>
                            <div id="edit-shots-preview"
                                style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="sheet-foot">
                <button class="btn ghost" data-close>Cancel</button>
                <button class="btn" id="save-edit">Save changes</button>
            </div>`);

        // Live thumbnail preview for newly selected screenshots.
        const shotsInput = $('#edit-shots-input', el);
        const dzEditShots = $('#dz-edit-shots', el);
        shotsInput.addEventListener('change', () => {
            const files = [...shotsInput.files];
            $('#dz-edit-shots-title', el).textContent = files.length
                ? `${files.length} image${files.length > 1 ? 's' : ''} selected`
                : 'Choose images or drop here';
            dzEditShots.classList.toggle('filled', files.length > 0);
            const preview = $('#edit-shots-preview', el);
            preview.innerHTML = '';
            files.slice(0, 5).forEach((file) => {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const img = document.createElement('img');
                    img.src = ev.target.result;
                    img.alt = file.name;
                    img.style.cssText = 'width:72px;height:72px;object-fit:cover;border-radius:6px;border:1px solid var(--line)';
                    preview.append(img);
                };
                reader.readAsDataURL(file);
            });
        });
        ['dragenter', 'dragover'].forEach((ev) =>
            dzEditShots.addEventListener(ev, (e) => { e.preventDefault(); dzEditShots.classList.add('drag'); }));
        ['dragleave', 'drop'].forEach((ev) =>
            dzEditShots.addEventListener(ev, () => dzEditShots.classList.remove('drag')));
        dzEditShots.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files.length) {
                shotsInput.files = e.dataTransfer.files;
                shotsInput.dispatchEvent(new Event('change'));
            }
        });

        // "Remove all screenshots" — sends screenshots=null to the API.
        let clearScreenshots = false;
        $('#clear-shots', el)?.addEventListener('click', () => {
            clearScreenshots = true;
            const cur = $('#current-shots', el);
            if (cur) cur.innerHTML = '<span class="muted" style="font-size:13px">Screenshots will be removed on save.</span>';
            $('#clear-shots', el).disabled = true;
        });

        $('#save-edit', el).addEventListener('click', async () => {
            const btn = $('#save-edit', el);
            const form = $('#form-edit-project', el);
            clearErrors(form);
            busy(btn, true);
            try {
                const fd = new FormData(form);
                // If no new files chosen and not clearing, remove the field so
                // the backend leaves existing screenshots untouched.
                if (!shotsInput.files.length && !clearScreenshots) {
                    fd.delete('screenshots[]');
                } else if (clearScreenshots && !shotsInput.files.length) {
                    fd.delete('screenshots[]');
                    fd.append('screenshots', '');   // empty value signals null on the backend
                }
                const data = await api.updateProject(project.id, fd);
                close();
                toast('ok', 'Project updated', data.project.name);
                render();
            } catch (error) { fail(error, form); } finally { busy(btn, false); }
        });
    }

    /** Confirm and execute project deletion. */
    function confirmDeleteProject(project) {
        const { el, close } = sheet(`
            <div class="sheet-head">
                <div class="avatar" style="background:var(--red-dim,#3b1414);color:var(--red,#f87171)">
                    ${icon('trash', 16)}
                </div>
                <div><div class="section-title">Delete project?</div>
                <div class="section-sub">${esc(project.name)}</div></div>
            </div>
            <div class="sheet-body">
                <p class="section-sub">
                    This permanently removes the project, its source archive, and all screenshots.
                    This cannot be undone.
                </p>
            </div>
            <div class="sheet-foot">
                <button class="btn ghost" data-close>Cancel</button>
                <button class="btn bad" id="confirm-delete">Delete project</button>
            </div>`);

        $('#confirm-delete', el).addEventListener('click', async () => {
            busy($('#confirm-delete', el), true);
            try {
                await api.deleteProject(project.id);
                close();
                toast('ok', 'Project deleted', project.name);
                render();
            } catch (error) {
                close();
                fail(error);
            }
        });
    }

    function blocked(content, error) {
        if (!(error instanceof ApiError)) { fail(error); return; }
        const pendingReview = error.code === 'ACCOUNT_NOT_ACTIVE';
        content.innerHTML = `<div class="card">${emptyState(
            pendingReview ? 'shield' : 'info',
            pendingReview ? 'Your account is being reviewed' : 'Unable to load this page',
            pendingReview
                ? 'An administrator has to approve your account before you can use this area. We will email you when that is done.'
                : error.message,
        )}</div>`;
    }

    /* =========================== recruiter screen ========================= */

    function searchScreen() {
        const content = shell('Find talent', '');
        let mode = 'students';
        let lastQuery = '';

        content.innerHTML = `
        <div class="page-head">
            <div>
                <h1 class="page-title">Find talent</h1>
                <p class="page-sub">Search approved students by skill, or search their published projects by keyword.</p>
            </div>
        </div>

        <div class="card">
            <div class="card-head">
                <div class="seg" id="mode">
                    <button aria-selected="true" data-mode="students">Students</button>
                    <button aria-selected="false" data-mode="projects">Projects</button>
                </div>
                <div class="spacer"></div>
                <form id="form-search" style="display:flex;gap:10px;flex:1 1 320px;min-width:240px">
                    <input name="q" type="search" id="q" placeholder="Try laravel, rust, compiler…" required>
                    <button class="btn" type="submit">${icon('search', 16)} Search</button>
                </form>
            </div>
            <div id="results">${emptyState('search', 'Start searching', 'Search by a skill like “laravel”, or a keyword from a project name.')}</div>
        </div>`;

        $$('#mode button').forEach((b) => b.addEventListener('click', () => {
            $$('#mode button').forEach((x) => x.setAttribute('aria-selected', String(x === b)));
            mode = b.dataset.mode;
            if (lastQuery) runSearch();
        }));

        const form = $('#form-search');
        form.addEventListener('submit', (e) => { e.preventDefault(); runSearch(); });

        function runSearch() {
            const q = $('#q').value.trim();
            lastQuery = q;
            submit(form, form.querySelector('button'), async () => {
                const data = mode === 'students'
                    ? await api.findStudents({ q })
                    : await api.findProjects({ q });
                mode === 'students' ? paintStudents(data) : paintProjects(data);
            });
        }

        function resultHead(total, q) {
            return `<div class="card-head" style="border-top:1px solid var(--line)">
                <div class="section-sub">${total} result${total === 1 ? '' : 's'} for “${esc(q)}”</div></div>`;
        }

        function paintStudents({ students, total, query }) {
            if (!total) {
                $('#results').innerHTML = emptyState('search', 'No students matched', `Nothing found for “${query}”. Try a broader skill.`);
                return;
            }
            $('#results').innerHTML = resultHead(total, query) + `<div class="table-wrap"><table>
                <thead><tr><th>Student</th><th>Skills</th><th>Projects</th><th></th></tr></thead>
                <tbody>${students.map((s) => `
                    <tr data-student="${s.id}" style="cursor:pointer">
                        <td><div class="cell-user">${avatar(s)}<div>
                            <div class="nm">${esc(s.name || s.email)}</div>
                            <div class="em">${esc(s.email)}</div></div></div></td>
                        <td><div class="tags">${tagList(s.skills).slice(0, 4).map((t) => `<span class="tag">${esc(t)}</span>`).join('') || '<span class="muted">—</span>'}</div></td>
                        <td class="nowrap">${s.projects?.length || 0}</td>
                        <td class="actions"><button class="btn ghost sm">View profile</button></td>
                    </tr>`).join('')}</tbody></table></div>`;
            wireRows();
        }

        function paintProjects({ projects, total, query }) {
            if (!total) {
                $('#results').innerHTML = emptyState('box', 'No projects matched', `Nothing found for “${query}”. Try another keyword.`);
                return;
            }
            $('#results').innerHTML = resultHead(total, query) + `<div class="table-wrap"><table>
                <thead><tr><th>Project</th><th>Student</th><th>Skills</th><th></th></tr></thead>
                <tbody>${projects.map((p) => `
                    <tr>
                        <td><div class="cell-user"><div class="avatar">${icon('box', 15)}</div>
                            <div><div class="nm">${esc(p.name)}</div>
                            <div class="em">Added ${esc(when(p.created_at))}</div></div></div></td>
                        <td class="nowrap"><button class="btn quiet sm" data-student="${p.user_id}">${esc(p.student?.name || p.student?.email || '—')}</button></td>
                        <td><div class="tags">${tagList(p.student?.skills).slice(0, 3).map((t) => `<span class="tag">${esc(t)}</span>`).join('') || '<span class="muted">—</span>'}</div></td>
                        <td class="actions">
                            <button class="btn ghost sm" data-open="${p.id}">View files</button>
                            <button class="btn ghost sm" data-download="${p.id}">${icon('download', 14)}</button>
                        </td>
                    </tr>`).join('')}</tbody></table></div>`;

            const byId = (id) => projects.find((p) => String(p.id) === String(id));
            $$('#results [data-open]').forEach((b) => b.addEventListener('click', () => openProject(byId(b.dataset.open))));
            $$('#results [data-download]').forEach((b) => b.addEventListener('click', (e) =>
                saveArchive(byId(b.dataset.download), e.currentTarget)));
            wireRows();
        }

        function wireRows() {
            $$('#results [data-student]').forEach((row) =>
                row.addEventListener('click', () => openStudent(row.dataset.student)));
        }

        async function openStudent(id) {
            try {
                const { student } = await api.student(id);
                const { el } = sheet(`
                    <div class="sheet-head">
                        ${avatar(student)}
                        <div><div class="section-title">${esc(student.name || student.email)}</div>
                        <div class="section-sub">${esc(student.email)}</div></div>
                        <div class="spacer"></div>
                        ${pill(student.status, student.status)}
                    </div>
                    <div class="sheet-body stack">
                        ${student.resume_photo ? `
                        <div>
                            <div class="section-sub" style="margin-bottom:8px">Resume photo</div>
                            <img src="${esc(student.resume_photo)}" alt="Resume photo"
                                style="max-width:100%;max-height:180px;border-radius:8px;object-fit:cover;border:1px solid var(--line)">
                        </div>` : ''}
                        <div>
                            <div class="section-sub" style="margin-bottom:8px">Skills</div>
                            <div class="tags">${tagList(student.skills).map((t) => `<span class="tag">${esc(t)}</span>`).join('') || '<span class="muted">No skills listed</span>'}</div>
                        </div>
                        <div>
                            <div class="section-sub" style="margin-bottom:8px">Projects</div>
                            ${(student.projects || []).length ? `<div class="stack" style="gap:8px">${student.projects.map((p) => `
                                <div class="card"><div class="card-body" style="padding:13px 15px;display:flex;align-items:center;gap:12px">
                                    <div style="flex:1;min-width:0">
                                        <div style="font-weight:600">${esc(p.name)}</div>
                                        <div class="muted" style="font-size:12.5px;margin-top:3px">Added ${esc(when(p.created_at))}</div>
                                    </div>
                                    <button class="btn ghost sm" data-open="${p.id}">View files</button>
                                    <button class="btn ghost sm" data-download="${p.id}">${icon('download', 14)}</button>
                                </div></div>`).join('')}</div>` : '<div class="muted">No projects published yet.</div>'}
                        </div>
                    </div>
                    <div class="sheet-foot"><button class="btn ghost" data-close>Close</button></div>`);

                const byId = (id) => student.projects.find((p) => String(p.id) === String(id));
                $$('[data-open]', el).forEach((b) => b.addEventListener('click', () => openProject(byId(b.dataset.open))));
                $$('[data-download]', el).forEach((b) => b.addEventListener('click', (e) =>
                    saveArchive(byId(b.dataset.download), e.currentTarget)));
            } catch (error) { fail(error); }
        }
    }

    /* ============================= admin panel =========================== */

    function adminScreen() {
        const content = shell('Registrations', '');
        const state = { state: 'pending', q: '', page: 1 };

        content.innerHTML = `
        <div class="page-head">
            <div>
                <h1 class="page-title">Registrations</h1>
                <p class="page-sub">Review new students and recruiters. Approving activates the account; rejecting keeps it locked.</p>
            </div>
            <div class="spacer"></div>
            <button class="btn ghost" id="reload">Refresh</button>
        </div>

        <div class="stats" id="stats"></div>

        <div class="card">
            <div class="card-head">
                <div class="seg" id="filters">
                    <button aria-selected="true" data-state="pending">Pending <span class="count" data-count="pending">–</span></button>
                    <button aria-selected="false" data-state="approved">Approved <span class="count" data-count="approved">–</span></button>
                    <button aria-selected="false" data-state="rejected">Rejected <span class="count" data-count="rejected">–</span></button>
                    <button aria-selected="false" data-state="all">All</button>
                </div>
                <div class="spacer"></div>
                <form id="form-filter" style="display:flex;gap:10px;flex:1 1 260px;min-width:200px">
                    <input name="q" type="search" id="admin-q" placeholder="Search name or email…">
                    <button class="btn ghost" type="submit">${icon('search', 16)}</button>
                </form>
            </div>
            <div id="queue">${skeletonRows(4)}</div>
        </div>`;

        $$('#filters button').forEach((b) => b.addEventListener('click', () => {
            $$('#filters button').forEach((x) => x.setAttribute('aria-selected', String(x === b)));
            state.state = b.dataset.state;
            state.page = 1;
            load();
        }));

        $('#form-filter').addEventListener('submit', (e) => {
            e.preventDefault();
            state.q = $('#admin-q').value.trim();
            state.page = 1;
            load();
        });

        $('#reload').addEventListener('click', () => load());

        async function load() {
            try {
                const data = await api.queue(state);
                paintStats(data.counts);
                paintQueue(data);
            } catch (error) {
                fail(error);
                $('#queue').innerHTML = emptyState('info', 'Could not load registrations', error.message || '');
            }
        }

        function paintStats(counts) {
            $('#stats').innerHTML = `
                <div class="stat hot"><div class="k">Awaiting review</div><div class="v">${counts.pending}</div></div>
                <div class="stat good"><div class="k">Approved</div><div class="v">${counts.approved}</div></div>
                <div class="stat"><div class="k">Rejected</div><div class="v">${counts.rejected}</div></div>
                <div class="stat"><div class="k">Students</div><div class="v">${counts.students}</div></div>
                <div class="stat"><div class="k">Recruiters</div><div class="v">${counts.recruiters}</div></div>`;
            ['pending', 'approved', 'rejected'].forEach((k) => {
                const el = $(`[data-count="${k}"]`);
                if (el) el.textContent = counts[k];
            });
        }

        function paintQueue({ registrations, total, current_page: page, last_page: pages }) {
            if (!total) {
                $('#queue').innerHTML = emptyState(
                    'check',
                    state.q ? 'Nothing matched that search' : 'Queue is clear',
                    state.q ? 'Try a different name or email.' : 'There are no registrations in this view.',
                );
                return;
            }

            $('#queue').innerHTML = `<div class="table-wrap"><table>
                <thead><tr><th>Applicant</th><th>Role</th><th>Email</th><th>Requested</th><th>Status</th><th></th></tr></thead>
                <tbody>${registrations.map((r) => `
                    <tr data-row="${r.id}">
                        <td><div class="cell-user">${avatar(r.user)}<div>
                            <div class="nm">${esc(r.user?.name || '—')}</div>
                            <div class="em">#${r.id}${r.admin ? ` · decided by ${esc(r.admin.email)}` : ''}</div>
                        </div></div></td>
                        <td>${pill(r.user?.role || '—', 'brand')}</td>
                        <td class="muted">${esc(r.user?.email || '')}
                            ${r.user?.email_verified ? '' : '<div style="margin-top:4px">' + pill('email unverified', 'pending') + '</div>'}</td>
                        <td class="nowrap muted">${esc(when(r.created_at))}</td>
                        <td>${pill(r.state, r.state)}</td>
                        <td class="actions">${r.state === 'pending' ? `
                            <button class="btn ok sm" data-approve="${r.id}">${icon('check', 14)} Approve</button>
                            <button class="btn bad sm" data-reject="${r.id}">${icon('x', 14)} Reject</button>`
                            : `<span class="muted" style="font-size:12.5px">${esc(when(r.decided_at))}</span>`}</td>
                    </tr>`).join('')}</tbody></table></div>
                ${pages > 1 ? `<div class="card-foot">
                    <span class="muted" style="font-size:13px">Page ${page} of ${pages} · ${total} total</span>
                    <div class="spacer" style="flex:1"></div>
                    <button class="btn ghost sm" id="prev" ${page <= 1 ? 'disabled' : ''}>Previous</button>
                    <button class="btn ghost sm" id="next" ${page >= pages ? 'disabled' : ''}>Next</button>
                </div>` : ''}`;

            $$('[data-approve]').forEach((b) => b.addEventListener('click', () => confirmDecision('approve', b.dataset.approve)));
            $$('[data-reject]').forEach((b) => b.addEventListener('click', () => confirmDecision('reject', b.dataset.reject)));
            $('#prev')?.addEventListener('click', () => { state.page = Math.max(1, page - 1); load(); });
            $('#next')?.addEventListener('click', () => { state.page = page + 1; load(); });
        }

        function confirmDecision(decision, id) {
            const approving = decision === 'approve';
            const { el, close } = sheet(`
                <div class="sheet-head"><h2 class="section-title">${approving ? 'Approve this registration?' : 'Reject this registration?'}</h2></div>
                <div class="sheet-body">
                    <p class="section-sub">${approving
                        ? 'The account becomes active immediately and the person gains full access to their workspace.'
                        : 'The account stays locked. The person keeps their login but cannot use the platform.'}</p>
                </div>
                <div class="sheet-foot">
                    <button class="btn ghost" data-close>Cancel</button>
                    <button class="btn ${approving ? 'ok' : 'bad'}" id="confirm">${approving ? 'Approve account' : 'Reject account'}</button>
                </div>`);

            $('#confirm', el).addEventListener('click', async () => {
                busy($('#confirm', el), true);
                try {
                    const data = approving ? await api.approve(id) : await api.reject(id);
                    close();
                    toast('ok', approving ? 'Account approved' : 'Account rejected', data.user.email);
                } catch (error) {
                    close();
                    // Someone else decided it first, or the row was stale: say so plainly
                    // and let the reload below put the table back in sync.
                    if (error instanceof ApiError && error.code === 'REGISTRATION_ALREADY_DECIDED') {
                        toast('err', 'Already decided', 'Another administrator got there first. Refreshing the queue.');
                    } else {
                        fail(error);
                    }
                }
                load();
            });
        }

        load();
    }

    /* =========================== marketplace screen ======================== */

    async function marketplaceScreen() {
        const content = shell('Marketplace', `<div class="card">${skeletonRows(6)}</div>`);
        const user = store.user;

        // State kept in closure — lets pagination + filter share the same load().
        const state = { q: '', skill: '', sort: 'latest', page: 1 };
        // Cache projects keyed by id so like/comment mutations can update them.
        let projectCache = {};

        // ── render shell ──────────────────────────────────────────────────
        content.innerHTML = `
        <div class="page-head">
            <div>
                <h1 class="page-title">Marketplace</h1>
                <p class="page-sub">Explore every project published on ProjectPort. Like what you see, leave a comment.</p>
            </div>
        </div>

        <div class="mk-toolbar card">
            <form id="mk-search-form" style="display:flex;gap:10px;flex:1 1 280px;min-width:200px">
                <div style="position:relative;flex:1">
                    <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--ink-3);pointer-events:none">${icon('search', 15)}</span>
                    <input id="mk-q" name="q" type="search" placeholder="Search projects, students, skills…"
                        style="padding-left:34px;width:100%">
                </div>
                <button class="btn" type="submit">${icon('search', 15)} Search</button>
            </form>
            <div class="mk-filters">
                <div class="field" style="min-width:160px">
                    <label for="mk-skill" style="font-size:11.5px">${icon('filter', 12)} Filter by skill</label>
                    <input id="mk-skill" type="text" placeholder="e.g. laravel, react">
                </div>
                <div class="field" style="min-width:140px">
                    <label for="mk-sort" style="font-size:11.5px">Sort by</label>
                    <select id="mk-sort">
                        <option value="latest">Latest</option>
                        <option value="popular">Most liked</option>
                        <option value="most_commented">Most discussed</option>
                    </select>
                </div>
            </div>
        </div>

        <div id="mk-grid" class="mk-grid">${skeletonGrid(6)}</div>
        <div id="mk-pagination" class="mk-pagination"></div>`;

        // ── wire toolbar ──────────────────────────────────────────────────
        const form = $('#mk-search-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            state.q = $('#mk-q').value.trim();
            state.page = 1;
            load();
        });

        $('#mk-skill').addEventListener('change', () => {
            state.skill = $('#mk-skill').value.trim();
            state.page  = 1;
            load();
        });

        $('#mk-sort').addEventListener('change', () => {
            state.sort = $('#mk-sort').value;
            state.page = 1;
            load();
        });

        // ── load & render projects ────────────────────────────────────────
        async function load() {
            $('#mk-grid').innerHTML = skeletonGrid(6);
            $('#mk-pagination').innerHTML = '';
            try {
                const data = await api.marketplace(state);
                // Rebuild cache.
                projectCache = {};
                data.projects.forEach((p) => { projectCache[p.id] = p; });
                paintGrid(data);
            } catch (e) {
                $('#mk-grid').innerHTML = `<div class="card" style="grid-column:1/-1">${
                    emptyState('store', 'Could not load marketplace', e.message || '')}</div>`;
            }
        }

        function paintGrid({ projects, current_page: page, last_page: pages, total }) {
            if (!projects.length) {
                $('#mk-grid').innerHTML = `<div class="mk-empty-wrap">${
                    emptyState('store', 'No projects found', state.q || state.skill
                        ? 'Try a different search or clear the filters.'
                        : 'No projects have been published yet.')}</div>`;
                return;
            }

            $('#mk-grid').innerHTML = projects.map((p) => projectCard(p)).join('');
            wireCards();

            // Pagination
            if (pages > 1) {
                $('#mk-pagination').innerHTML = `
                    <span class="muted" style="font-size:13px">${total} projects · Page ${page} of ${pages}</span>
                    <div style="display:flex;gap:8px">
                        <button class="btn ghost sm" id="mk-prev" ${page <= 1 ? 'disabled' : ''}>← Previous</button>
                        <button class="btn ghost sm" id="mk-next" ${page >= pages ? 'disabled' : ''}>Next →</button>
                    </div>`;
                $('#mk-prev')?.addEventListener('click', () => { state.page = Math.max(1, page - 1); load(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
                $('#mk-next')?.addEventListener('click', () => { state.page = page + 1; load(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
            }
        }

        // ── project card HTML ─────────────────────────────────────────────
        function projectCard(p) {
            const liked   = p.user_has_liked;
            const skills  = tagList(p.student?.skills);
            const shots   = p.screenshots || [];
            const hasMany = shots.length > 1;

            // Build the visual header: single thumb or a mini gallery strip.
            const visual = shots.length === 0
                ? `<div class="mk-card-thumb mk-card-thumb--empty">${icon('box', 28)}</div>`
                : shots.length === 1
                    ? `<div class="mk-card-thumb" style="background-image:url('${esc(shots[0])}')"
                            role="img" aria-label="${esc(p.name)} screenshot"></div>`
                    : `<div class="mk-card-gallery" data-pid="${p.id}">
                           <div class="mk-gallery-main">
                               <img src="${esc(shots[0])}" alt="${esc(p.name)} screenshot 1"
                                    class="mk-gallery-img active" data-idx="0">
                               ${shots.slice(1).map((url, i) =>
                                   `<img src="${esc(url)}" alt="${esc(p.name)} screenshot ${i + 2}"
                                        class="mk-gallery-img" data-idx="${i + 1}">`
                               ).join('')}
                               <button class="mk-gallery-arrow mk-gallery-prev" aria-label="Previous screenshot">&#8249;</button>
                               <button class="mk-gallery-arrow mk-gallery-next" aria-label="Next screenshot">&#8250;</button>
                               <div class="mk-gallery-dots">
                                   ${shots.map((_, i) =>
                                       `<span class="mk-gallery-dot${i === 0 ? ' active' : ''}" data-dot="${i}"></span>`
                                   ).join('')}
                               </div>
                           </div>
                           <div class="mk-gallery-strip">
                               ${shots.map((url, i) =>
                                   `<img src="${esc(url)}" alt="thumb ${i + 1}"
                                        class="mk-strip-thumb${i === 0 ? ' active' : ''}" data-strip="${i}"
                                        style="cursor:pointer">`
                               ).join('')}
                           </div>
                       </div>`;

            return `<div class="mk-card" data-id="${p.id}">
                ${visual}
                <div class="mk-card-body">
                    <div class="mk-card-title">${esc(p.name)}</div>
                    <div class="mk-card-meta">
                        <div class="mk-card-author">
                            ${avatar(p.student, 'mk-avatar')}
                            <span>${esc(p.student?.name || p.student?.email || 'Student')}</span>
                        </div>
                        <span class="muted" style="font-size:12px">${when(p.created_at)}</span>
                    </div>
                    ${shots.length > 1
                        ? `<div class="mk-card-img-count" style="margin-top:6px">
                               ${icon('filter', 11)} ${shots.length} images
                           </div>`
                        : ''}
                    ${skills.length
                        ? `<div class="tags" style="margin-top:10px">${
                            skills.slice(0, 4).map((t) => `<span class="tag">${esc(t)}</span>`).join('')
                            }${skills.length > 4 ? `<span class="tag muted">+${skills.length - 4}</span>` : ''}</div>`
                        : ''}
                </div>
                <div class="mk-card-foot">
                    <button class="mk-like-btn ${liked ? 'liked' : ''}" data-like="${p.id}"
                        aria-label="${liked ? 'Unlike' : 'Like'} project" title="${liked ? 'Unlike' : 'Like'}">
                        ${icon(liked ? 'heart-fill' : 'heart', 15)}
                        <span class="mk-like-count">${p.likes_count}</span>
                    </button>
                    <button class="mk-comment-btn" data-comment="${p.id}"
                        aria-label="Comments" title="View comments">
                        ${icon('message', 15)}
                        <span>${p.comments_count}</span>
                    </button>
                    <div style="flex:1"></div>
                    <button class="btn ghost sm" data-view="${p.id}">View project</button>
                </div>
            </div>`;
        }

        // ── wire card interactions ────────────────────────────────────────
        function wireCards() {
            $$('[data-like]', $('#mk-grid')).forEach((btn) => {
                btn.addEventListener('click', () => toggleLike(btn));
            });
            $$('[data-comment]', $('#mk-grid')).forEach((btn) => {
                btn.addEventListener('click', () => openComments(projectCache[btn.dataset.comment]));
            });
            $$('[data-view]', $('#mk-grid')).forEach((btn) => {
                btn.addEventListener('click', () => openProject(projectCache[btn.dataset.view]));
            });

            // ── gallery navigation ──────────────────────────────────────
            $$('.mk-card-gallery', $('#mk-grid')).forEach((gallery) => {
                const imgs  = $$('.mk-gallery-img', gallery);
                const dots  = $$('.mk-gallery-dot', gallery);
                const thumbs = $$('.mk-strip-thumb', gallery);
                let current = 0;

                function goTo(idx) {
                    imgs[current].classList.remove('active');
                    dots[current]?.classList.remove('active');
                    thumbs[current]?.classList.remove('active');
                    current = (idx + imgs.length) % imgs.length;
                    imgs[current].classList.add('active');
                    dots[current]?.classList.add('active');
                    thumbs[current]?.classList.add('active');
                }

                $('.mk-gallery-prev', gallery)?.addEventListener('click', (e) => { e.stopPropagation(); goTo(current - 1); });
                $('.mk-gallery-next', gallery)?.addEventListener('click', (e) => { e.stopPropagation(); goTo(current + 1); });
                dots.forEach((d)    => d.addEventListener('click',  (e) => { e.stopPropagation(); goTo(+d.dataset.dot);    }));
                thumbs.forEach((t)  => t.addEventListener('click',  (e) => { e.stopPropagation(); goTo(+t.dataset.strip);  }));
            });
        }

        // ── like toggle ───────────────────────────────────────────────────
        async function toggleLike(btn) {
            if (btn.disabled) return;
            const id     = btn.dataset.like;
            const liked  = btn.classList.contains('liked');
            const span   = btn.querySelector('.mk-like-count');
            const current = parseInt(span.textContent, 10) || 0;

            // Optimistic update.
            btn.classList.toggle('liked', !liked);
            btn.innerHTML = `${icon(!liked ? 'heart-fill' : 'heart', 15)}<span class="mk-like-count">${!liked ? current + 1 : Math.max(0, current - 1)}</span>`;
            btn.dataset.like = id;

            btn.disabled = true;
            try {
                const data = liked
                    ? await api.unlikeProject(id)
                    : await api.likeProject(id);
                btn.querySelector('.mk-like-count').textContent = data.likes_count;
                // Update cache.
                if (projectCache[id]) {
                    projectCache[id].user_has_liked = data.user_has_liked;
                    projectCache[id].likes_count    = data.likes_count;
                }
            } catch (e) {
                // Revert on failure.
                btn.classList.toggle('liked', liked);
                btn.innerHTML = `${icon(liked ? 'heart-fill' : 'heart', 15)}<span class="mk-like-count">${current}</span>`;
                btn.dataset.like = id;
                fail(e);
            } finally {
                btn.disabled = false;
            }
        }

        // ── comments sheet ────────────────────────────────────────────────
        function openComments(project) {
            const canDelete = (c) => c.user?.id === user?.id;

            const buildCommentList = (comments) => {
                if (!comments.length) return `<div class="muted" style="font-size:13.5px;padding:8px 0">No comments yet. Be the first!</div>`;
                return `<div class="mk-comment-list" id="mk-comment-list">${comments.map((c) => `
                    <div class="mk-comment" data-cid="${c.id}">
                        <div class="mk-comment-avatar">${avatar(c.user, 'sm')}</div>
                        <div class="mk-comment-body">
                            <div class="mk-comment-meta">
                                <span class="mk-comment-author">${esc(c.user?.name || c.user?.email || 'User')}</span>
                                <span class="muted" style="font-size:11.5px">${when(c.created_at)}</span>
                                ${canDelete(c) ? `<button class="btn quiet sm mk-comment-del" data-del="${c.id}" style="margin-left:auto;padding:2px 6px;font-size:11px;color:var(--bad)">${icon('trash', 12)}</button>` : ''}
                            </div>
                            <div class="mk-comment-text">${esc(c.body)}</div>
                        </div>
                    </div>`).join('')}</div>`;
            };

            const { el, close } = sheet(`
                <div class="sheet-head">
                    <div class="avatar">${icon('message', 16)}</div>
                    <div>
                        <div class="section-title">${esc(project.name)}</div>
                        <div class="section-sub">${project.comments_count} comment${project.comments_count === 1 ? '' : 's'}</div>
                    </div>
                </div>
                <div class="sheet-body stack" id="mk-comments-body">
                    ${buildCommentList(project.comments || [])}
                </div>
                <div class="sheet-foot" style="flex-direction:column;align-items:stretch;gap:10px">
                    <form id="mk-comment-form" novalidate style="display:flex;gap:8px;align-items:flex-end">
                        <div class="field" style="flex:1;margin:0">
                            <textarea id="mk-comment-input" name="body" placeholder="Write a comment…"
                                style="min-height:60px;resize:none" maxlength="1000"></textarea>
                        </div>
                        <button class="btn" type="submit" id="mk-comment-submit">${icon('message', 14)} Post</button>
                    </form>
                </div>`);

            // Wire delete buttons on existing comments.
            function wireDelButtons() {
                $$('.mk-comment-del', el).forEach((btn) => {
                    btn.addEventListener('click', async () => {
                        busy(btn, true);
                        try {
                            await api.deleteComment(btn.dataset.del);
                            const row = btn.closest('[data-cid]');
                            row?.remove();
                            // Update count.
                            project.comments_count = Math.max(0, (project.comments_count || 1) - 1);
                            project.comments = (project.comments || []).filter((c) => String(c.id) !== String(btn.dataset.del));
                            // Refresh count badge in list title.
                            el.querySelector('.section-sub').textContent = `${project.comments_count} comment${project.comments_count === 1 ? '' : 's'}`;
                            // Update card badge.
                            const cardBtn = $(`[data-comment="${project.id}"] span`);
                            if (cardBtn) cardBtn.textContent = project.comments_count;
                            toast('ok', 'Comment deleted');
                        } catch (e) { fail(e); } finally { busy(btn, false); }
                    });
                });
            }
            wireDelButtons();

            // Submit new comment.
            const commentForm = $('#mk-comment-form', el);
            commentForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const body = $('#mk-comment-input', el).value.trim();
                if (!body) return;
                const submitBtn = $('#mk-comment-submit', el);
                busy(submitBtn, true);
                try {
                    const data = await api.addComment(project.id, body);
                    const c = data.comment;

                    // Append to the comment list.
                    project.comments = project.comments || [];
                    project.comments.unshift(c);
                    project.comments_count = (project.comments_count || 0) + 1;

                    const list = $('#mk-comment-list', el);
                    if (list) {
                        const div = document.createElement('div');
                        div.className = 'mk-comment';
                        div.dataset.cid = c.id;
                        div.innerHTML = `
                            <div class="mk-comment-avatar">${avatar(c.user, 'sm')}</div>
                            <div class="mk-comment-body">
                                <div class="mk-comment-meta">
                                    <span class="mk-comment-author">${esc(c.user?.name || c.user?.email || 'You')}</span>
                                    <span class="muted" style="font-size:11.5px">Just now</span>
                                    <button class="btn quiet sm mk-comment-del" data-del="${c.id}" style="margin-left:auto;padding:2px 6px;font-size:11px;color:var(--bad)">${icon('trash', 12)}</button>
                                </div>
                                <div class="mk-comment-text">${esc(c.body)}</div>
                            </div>`;
                        list.prepend(div);
                    } else {
                        // No list yet (was empty), rebuild.
                        $('#mk-comments-body', el).innerHTML = buildCommentList(project.comments);
                    }
                    wireDelButtons();

                    // Update section sub count.
                    el.querySelector('.section-sub').textContent = `${project.comments_count} comment${project.comments_count === 1 ? '' : 's'}`;
                    // Update card badge.
                    const cardBtn = $(`[data-comment="${project.id}"] span`);
                    if (cardBtn) cardBtn.textContent = project.comments_count;

                    $('#mk-comment-input', el).value = '';
                } catch (e) { fail(e, commentForm); } finally { busy(submitBtn, false); }
            });
        }

        load();
    }

    /* ======================== marketplace helpers ======================= */

    function skeletonGrid(n) {
        return `<div class="mk-skeleton-wrap">${
            Array.from({ length: n }, () =>
                `<div class="mk-card mk-card--skeleton">
                    <div class="mk-card-thumb skeleton"></div>
                    <div class="mk-card-body"><div class="skeleton" style="height:14px;width:70%;border-radius:4px"></div>
                    <div class="skeleton" style="height:12px;width:50%;border-radius:4px;margin-top:8px"></div></div>
                </div>`
            ).join('')}</div>`;
    }

    /* =========================== courses screen =========================== */

    async function coursesScreen() {
        const content = shell('Courses', `<div class="card">${skeletonRows(4)}</div>`);
        const user = store.user;

        // ── load data ────────────────────────────────────────────────────
        let data;
        try {
            data = await api.getCourses();
        } catch (e) {
            content.innerHTML = `<div class="card">${emptyState('video', 'Could not load courses', e.message)}</div>`;
            return;
        }

        // Active course state — kept in closure.
        let activeCourse = data.courses[0] ?? null;
        let chatHistory  = [];   // [{ role:'user'|'ai', text }]

        // ── build screen ─────────────────────────────────────────────────
        function render() {
            const { courses, stats, grouped } = data;
            const topics = Object.keys(grouped).sort();

            content.innerHTML = `
            <div class="page-head">
                <div>
                    <h1 class="page-title">${icon('video', 18)} Courses</h1>
                    <p class="page-sub">Watch a course, mark it complete, and earn your certificate. Ask the AI anything along the way.</p>
                </div>
                <div class="spacer"></div>
                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
                    <span class="pill approved">${icon('check-circle', 12)} ${stats.certified} certified</span>
                    <span class="pill brand">${icon('play-circle', 12)} ${stats.watched} watched</span>
                    <span class="muted" style="font-size:13px">of ${stats.total} courses</span>
                </div>
            </div>

            <div class="cs-layout">
                <!-- Left: course list -->
                <aside class="cs-sidebar">
                    <div class="cs-topic-filter card" style="margin-bottom:14px;padding:10px 14px">
                        <input id="cs-search" type="search" placeholder="Filter courses…" style="width:100%">
                    </div>
                    <div id="cs-course-list" class="cs-course-list">
                        ${topics.map((topic) => `
                        <div class="cs-topic-group">
                            <div class="cs-topic-label">${esc(topic)}</div>
                            ${grouped[topic].map((c) => courseListItem(c)).join('')}
                        </div>`).join('')}
                    </div>
                </aside>

                <!-- Right: player + AI -->
                <div class="cs-main">
                    <div id="cs-player-panel" class="cs-player-panel card">
                        ${activeCourse ? playerPanel(activeCourse) : emptyState('video', 'Select a course', 'Pick a course from the list to start watching.')}
                    </div>

                    <!-- AI Q&A -->
                    <div class="cs-ai-panel card">
                        <div class="cs-ai-head">
                            <div class="cs-ai-brand">
                                ${icon('bot', 18)}
                                <span>AI Tutor</span>
                                <span class="pill brand" style="font-size:11px">Powered by GPT</span>
                            </div>
                            <span class="muted" style="font-size:12.5px">Ask anything about the current course topic</span>
                        </div>
                        <div class="cs-ai-messages" id="cs-ai-messages">
                            <div class="cs-ai-msg cs-ai-msg--bot">
                                ${icon('sparkles', 14)}
                                <div>Hi! I'm your AI tutor. Select a course and ask me anything about <strong>${esc(activeCourse?.topic ?? 'the topic')}</strong>. I'm here to help!</div>
                            </div>
                        </div>
                        <form id="cs-ai-form" class="cs-ai-input-row">
                            <input id="cs-ai-input" type="text" placeholder="Ask a question about this topic…"
                                autocomplete="off" ${!activeCourse ? 'disabled' : ''}>
                            <button class="btn" type="submit" id="cs-ai-send" ${!activeCourse ? 'disabled' : ''}>
                                ${icon('sparkles', 15)} Ask
                            </button>
                        </form>
                    </div>
                </div>
            </div>`;

            wireScreen();
        }

        // ── course list item ──────────────────────────────────────────────
        function courseListItem(c) {
            const isActive = activeCourse?.id === c.id;
            return `<button class="cs-course-item ${isActive ? 'active' : ''} ${c.certified ? 'certified' : c.watched ? 'watched' : ''}"
                        data-cid="${c.id}">
                <div class="cs-ci-icon">
                    ${c.certified
                        ? icon('award', 14)
                        : c.watched
                            ? icon('check-circle', 14)
                            : icon('play-circle', 14)}
                </div>
                <div class="cs-ci-body">
                    <div class="cs-ci-title">${esc(c.title)}</div>
                    <div class="cs-ci-badge">${c.certified ? 'Certified' : c.watched ? 'Watched' : 'Not started'}</div>
                </div>
            </button>`;
        }

        // ── player panel HTML ─────────────────────────────────────────────
        function playerPanel(c) {
            return `
            <div class="cs-player-head">
                <div>
                    <div class="section-title">${esc(c.title)}</div>
                    <div class="section-sub">${icon('video', 12)} ${esc(c.topic)}
                        ${c.certified
                            ? `&nbsp;·&nbsp;<span style="color:var(--ok)">${icon('award', 12)} Certified</span>`
                            : c.watched
                                ? `&nbsp;·&nbsp;<span style="color:var(--brand)">${icon('check-circle', 12)} Watched</span>`
                                : ''}
                    </div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-left:auto">
                    ${!c.watched
                        ? `<button class="btn ghost sm" id="cs-mark-watched" data-id="${c.id}">
                               ${icon('check-circle', 13)} Mark as watched
                           </button>`
                        : ''}
                    ${c.watched && !c.certified
                        ? `<button class="btn sm" id="cs-get-cert" data-id="${c.id}" style="background:var(--ok)">
                               ${icon('award', 13)} Get certificate
                           </button>`
                        : ''}
                    ${c.certified
                        ? `<button class="btn ghost sm" id="cs-view-cert" data-id="${c.id}" style="border-color:var(--ok);color:var(--ok)">
                               ${icon('award', 13)} View certificate
                           </button>`
                        : ''}
                </div>
            </div>
            <div class="cs-embed-wrap">
                <iframe class="cs-embed"
                    src="https://www.youtube.com/embed/${esc(c.youtube_id)}?rel=0&modestbranding=1"
                    title="${esc(c.title)}"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen loading="lazy"></iframe>
            </div>
            ${c.description ? `<p class="cs-desc">${esc(c.description)}</p>` : ''}`;
        }

        // ── wire all interactions ─────────────────────────────────────────
        function wireScreen() {
            // Course list click.
            $$('[data-cid]', content).forEach((btn) => {
                btn.addEventListener('click', () => {
                    const c = data.courses.find((x) => String(x.id) === String(btn.dataset.cid));
                    if (!c) return;
                    activeCourse = c;
                    chatHistory  = [];
                    // Update player.
                    $('#cs-player-panel', content).innerHTML = playerPanel(c);
                    wirePlayerButtons();
                    // Update active state in list.
                    $$('[data-cid]', content).forEach((b) => b.classList.toggle('active', b.dataset.cid === String(c.id)));
                    // Reset AI panel context.
                    const input = $('#cs-ai-input', content);
                    if (input) { input.disabled = false; input.placeholder = `Ask anything about ${c.topic}…`; }
                    const sendBtn = $('#cs-ai-send', content);
                    if (sendBtn) sendBtn.disabled = false;
                    // Add context message.
                    appendAiMsg('bot', `Switched to <strong>${esc(c.title)}</strong>. Ask me anything about <strong>${esc(c.topic)}</strong>!`);
                });
            });

            wirePlayerButtons();
            wireAiChat();
            wireCourseSearch();
        }

        function wirePlayerButtons() {
            // Mark watched.
            $('#cs-mark-watched', content)?.addEventListener('click', async (e) => {
                const btn = e.currentTarget;
                const id  = btn.dataset.id;
                busy(btn, true);
                try {
                    await api.markWatched(id);
                    updateCourse(id, { watched: true });
                    render();
                    toast('ok', 'Marked as watched', 'You can now claim your certificate.');
                } catch (err) { fail(err); } finally { busy(btn, false); }
            });

            // Get certificate.
            $('#cs-get-cert', content)?.addEventListener('click', async (e) => {
                const btn = e.currentTarget;
                const id  = btn.dataset.id;
                busy(btn, true);
                try {
                    const res = await api.certify(id);
                    updateCourse(id, { certified: true, certified_at: res.certified_at });
                    showCertificate(res.certificate);
                    render();
                } catch (err) { fail(err); } finally { busy(btn, false); }
            });

            // View existing certificate.
            $('#cs-view-cert', content)?.addEventListener('click', () => {
                if (!activeCourse) return;
                showCertificate({
                    student_name: user?.name || user?.email || 'Student',
                    course_title: activeCourse.title,
                    topic:        activeCourse.topic,
                    issued_at:    activeCourse.certified_at
                        ? new Date(activeCourse.certified_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
                        : 'Previously',
                });
            });
        }

        // ── AI chat wiring ────────────────────────────────────────────────
        function wireAiChat() {
            const form  = $('#cs-ai-form', content);
            const input = $('#cs-ai-input', content);
            if (!form || !input) return;

            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                const q = input.value.trim();
                if (!q || !activeCourse) return;

                input.value = '';
                appendAiMsg('user', esc(q));

                const sendBtn = $('#cs-ai-send', content);
                busy(sendBtn, true);
                input.disabled = true;

                // Typing indicator.
                const typingId = 'ai-typing-' + Date.now();
                appendAiMsg('bot', '<span class="cs-ai-typing"><span></span><span></span><span></span></span>', typingId);

                try {
                    const res = await api.aiChat(activeCourse.id, q);
                    removeAiMsg(typingId);
                    // Convert markdown-ish code fences to <pre><code>.
                    const formatted = escAndFormat(res.answer);
                    appendAiMsg('bot', formatted);
                } catch (err) {
                    removeAiMsg(typingId);
                    appendAiMsg('bot', `<span style="color:var(--bad)">Sorry, the AI assistant encountered an error. Please try again.</span>`);
                } finally {
                    busy(sendBtn, false);
                    input.disabled = false;
                    input.focus();
                }
            });
        }

        function wireCourseSearch() {
            const searchInput = $('#cs-search', content);
            if (!searchInput) return;
            searchInput.addEventListener('input', () => {
                const q = searchInput.value.toLowerCase();
                $$('.cs-course-item', content).forEach((btn) => {
                    const title = btn.querySelector('.cs-ci-title')?.textContent?.toLowerCase() ?? '';
                    btn.style.display = title.includes(q) ? '' : 'none';
                });
                // Show/hide topic group labels if all children hidden.
                $$('.cs-topic-group', content).forEach((grp) => {
                    const any = [...grp.querySelectorAll('.cs-course-item')].some((b) => b.style.display !== 'none');
                    grp.style.display = any ? '' : 'none';
                });
            });
        }

        // ── certificate modal ─────────────────────────────────────────────
        function showCertificate(cert) {
            sheet(`
                <div class="sheet-head" style="background:linear-gradient(135deg,#1a1660,#2d1b69);color:#fff;border-radius:var(--r-lg) var(--r-lg) 0 0">
                    <div style="font-size:32px">🏆</div>
                    <div>
                        <div class="section-title" style="color:#fff;font-size:18px">Certificate of Completion</div>
                        <div style="color:rgba(255,255,255,.7);font-size:13px;margin-top:2px">ProjectPort Learning</div>
                    </div>
                </div>
                <div class="sheet-body" style="text-align:center;padding:32px 28px">
                    <div style="color:var(--ink-3);font-size:13px;letter-spacing:.05em;text-transform:uppercase">This certifies that</div>
                    <div style="font-size:26px;font-weight:750;letter-spacing:-.02em;margin:10px 0">${esc(cert.student_name)}</div>
                    <div style="color:var(--ink-3);font-size:13px">has successfully completed</div>
                    <div style="font-size:18px;font-weight:680;margin:10px 0;color:var(--brand)">${esc(cert.course_title)}</div>
                    <div class="pill brand" style="margin:0 auto">${esc(cert.topic)}</div>
                    <div style="margin-top:20px;color:var(--ink-3);font-size:13px">Issued on <strong>${esc(cert.issued_at)}</strong></div>
                    <div style="margin-top:24px;border-top:1px solid var(--line);padding-top:20px">
                        <div style="display:flex;justify-content:center;gap:32px;flex-wrap:wrap">
                            <div style="text-align:center">
                                <div style="width:80px;height:2px;background:var(--ink-3);margin:0 auto 6px"></div>
                                <div style="font-size:12px;color:var(--ink-3)">Student Signature</div>
                            </div>
                            <div style="text-align:center">
                                <div style="font-size:28px;line-height:1">🎓</div>
                                <div style="font-size:12px;color:var(--ink-3);margin-top:4px">ProjectPort</div>
                            </div>
                            <div style="text-align:center">
                                <div style="width:80px;height:2px;background:var(--ink-3);margin:0 auto 6px"></div>
                                <div style="font-size:12px;color:var(--ink-3)">Platform Seal</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sheet-foot">
                    <button class="btn ghost" data-close>Close</button>
                    <button class="btn" id="cs-print-cert" style="background:var(--ok)">🖨 Print / Save PDF</button>
                </div>`);

            // Print/save certificate
            document.getElementById('cs-print-cert')?.addEventListener('click', () => window.print());
        }

        // ── AI message helpers ────────────────────────────────────────────
        function appendAiMsg(role, html, id = '') {
            const box = $('#cs-ai-messages', content);
            if (!box) return;
            const div = document.createElement('div');
            div.className = `cs-ai-msg cs-ai-msg--${role}`;
            if (id) div.id = id;
            div.innerHTML = role === 'bot' ? `${icon('bot', 13)}<div>${html}</div>` : `<div>${html}</div>`;
            box.append(div);
            box.scrollTop = box.scrollHeight;
        }

        function removeAiMsg(id) {
            document.getElementById(id)?.remove();
        }

        function escAndFormat(text) {
            // Split on code fences, escape non-code parts.
            const parts = text.split(/(```[\s\S]*?```)/g);
            return parts.map((part, i) => {
                if (i % 2 === 1) {
                    // Code block.
                    const code = part.replace(/^```\w*\n?/, '').replace(/```$/, '');
                    return `<pre class="cs-code"><code>${esc(code)}</code></pre>`;
                }
                // Regular text — escape then convert newlines to <br>.
                return esc(part).replace(/\n/g, '<br>');
            }).join('');
        }

        // ── utility: update local data without re-fetching ────────────────
        function updateCourse(id, patch) {
            const idx = data.courses.findIndex((c) => String(c.id) === String(id));
            if (idx !== -1) data.courses[idx] = { ...data.courses[idx], ...patch };
            // Also patch grouped.
            Object.keys(data.grouped).forEach((topic) => {
                const i = data.grouped[topic].findIndex((c) => String(c.id) === String(id));
                if (i !== -1) data.grouped[topic][i] = { ...data.grouped[topic][i], ...patch };
            });
            if (activeCourse && String(activeCourse.id) === String(id)) {
                activeCourse = { ...activeCourse, ...patch };
            }
        }

        render();
    }

    /* =============================== session ============================= */

    /** The session died server-side (revoked or unrecoverable): drop it and show the sign-in screen. */
    function signOutLocally() {
        if (!store.user) return;
        store.clear();
        setTimeout(() => {
            toast('err', 'Session expired', 'Please sign in again.');
            render();
        }, 0);
    }

    async function signOut() {
        try { await api.logout(); } catch { /* the session is discarded regardless */ }
        store.clear();
        toast('ok', 'Signed out');
        navigate('/');
        render();
    }

    function toggleTheme() {
        const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
        document.documentElement.dataset.theme = next;
        localStorage.setItem('pp.theme', next);
    }

    /* =============================== routing ============================= */

    const ROUTES = {
        '/profile':     profileScreen,
        '/projects':    projectsScreen,
        '/search':      searchScreen,
        '/admin':       adminScreen,
        '/marketplace': marketplaceScreen,
        '/courses':     coursesScreen,
    };

    function navigate(path) {
        if (location.hash === `#${path}`) render();
        else location.hash = `#${path}`;
    }

    function render() {
        const user = store.user;
        if (!user) { authScreen(); return; }

        const path = (location.hash || '').slice(1) || landingFor(user);
        const allowed = (NAV[user.role] || []).map(([href]) => href.slice(1));

        if (!allowed.includes(path)) { navigate(landingFor(user)); return; }

        (ROUTES[path] || (() => authScreen()))();
    }

    document.documentElement.dataset.theme = localStorage.getItem('pp.theme')
        || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');

    window.addEventListener('hashchange', render);
    render();
})();
