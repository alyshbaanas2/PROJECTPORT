<?php

use App\Http\Controllers\Api\AdminRegistrationController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CredentialsController;
use App\Http\Controllers\Api\CoursesController;
use App\Http\Controllers\Api\MarketplaceController;
use App\Http\Controllers\Api\ProjectController;
use App\Http\Controllers\Api\ProjectSourceCodeController;
use App\Http\Controllers\Api\SearchController;
use App\Http\Controllers\Api\StudentProfileController;
use App\Models\User;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| ProjectPort API
|--------------------------------------------------------------------------
| Every route traces to a functional requirement. Auth is stateless JWT
| (Architecture Decision auth_strategy = jwt_stateless) and rate limits come
| from NFR-02 (10 req/min per IP on auth endpoints, 100 req/min on reads).
*/

// FR-01, FR-02, FR-03 — public auth endpoints.
Route::middleware('throttle:auth')->prefix('auth')->group(function (): void {
    Route::post('/register', [AuthController::class, 'register_user']);                     // FR-01
    Route::get('/verify-email/{token}', [AuthController::class, 'verify_email_address']);   // FR-02
    Route::post('/verify-email/resend', [AuthController::class, 'resend_verification_email']); // FR-01, FR-02
    Route::post('/login', [AuthController::class, 'login_user']);                           // FR-03
    Route::post('/refresh', [AuthController::class, 'refresh']);                            // Checklist: rotation
});

Route::middleware(['jwt.auth', 'throttle:auth'])->group(function (): void {
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    // Implementation Checklist: session invalidation on password / email change.
    Route::patch('/me/credentials', [CredentialsController::class, 'update']);
});

// FR-04 — admin approval queue.
Route::middleware(['jwt.auth', 'role:'.User::ROLE_ADMIN, 'throttle:read'])
    ->prefix('admin/registrations')
    ->group(function (): void {
        Route::get('/', [AdminRegistrationController::class, 'index']);
        Route::post('/{registration}/approve', [AdminRegistrationController::class, 'approve_registration']);
        Route::post('/{registration}/reject', [AdminRegistrationController::class, 'reject_registration']);
    });

// FR-05 — student profile and project uploads.
Route::middleware(['jwt.auth', 'role:'.User::ROLE_STUDENT, 'throttle:read'])
    ->prefix('students/me')
    ->group(function (): void {
        Route::get('/profile', [StudentProfileController::class, 'show']);
        Route::patch('/profile', [StudentProfileController::class, 'update']);
        Route::post('/projects', [ProjectController::class, 'create_project']);
        Route::patch('/projects/{project}', [ProjectController::class, 'update_project']); // FR-05 update
        Route::delete('/projects/{project}', [ProjectController::class, 'delete_project']); // FR-05 delete
    });

// FR-05 / FR-06 — reviewing the source code behind a project.
Route::middleware([
    'jwt.auth',
    'role:'.User::ROLE_RECRUITER.','.User::ROLE_ADMIN.','.User::ROLE_STUDENT,
    'throttle:read',
])->prefix('projects/{project}/source-code')->group(function (): void {
    Route::get('/', [ProjectSourceCodeController::class, 'download']);
    Route::get('/contents', [ProjectSourceCodeController::class, 'contents']);
});

// FR-05 / FR-06 — a student profile reached from a recruiter's search results.
Route::middleware([
    'jwt.auth',
    'role:'.User::ROLE_RECRUITER.','.User::ROLE_ADMIN.','.User::ROLE_STUDENT,
    'throttle:read',
])->get('/students/{student}', [StudentProfileController::class, 'showStudent']);

// FR-06 — recruiter search.
Route::middleware(['jwt.auth', 'role:'.User::ROLE_RECRUITER, 'throttle:read'])
    ->prefix('search')
    ->group(function (): void {
        Route::get('/students', [SearchController::class, 'search_students']);
        Route::get('/projects', [SearchController::class, 'search_projects']);
    });

// Marketplace — visible to all authenticated roles.
$marketplaceRoles = User::ROLE_STUDENT.','.User::ROLE_RECRUITER.','.User::ROLE_ADMIN;
Route::middleware(['jwt.auth', "role:{$marketplaceRoles}", 'throttle:read'])
    ->group(function () use ($marketplaceRoles): void {
        // Project feed (search + filter + sort).
        Route::get('/marketplace', [MarketplaceController::class, 'index']);

        // Likes.
        Route::post('/projects/{project}/like',   [MarketplaceController::class, 'like']);
        Route::delete('/projects/{project}/like', [MarketplaceController::class, 'unlike']);

        // Comments.
        Route::post('/projects/{project}/comments', [MarketplaceController::class, 'addComment']);
        Route::delete('/comments/{comment}',        [MarketplaceController::class, 'deleteComment']);
    });

// Courses — available to students (and admins for testing).
$courseRoles = User::ROLE_STUDENT.','.User::ROLE_ADMIN;
Route::middleware(['jwt.auth', "role:{$courseRoles}", 'throttle:read'])
    ->group(function (): void {
        Route::get('/courses',                        [CoursesController::class, 'index']);
        Route::post('/courses/{course}/progress',     [CoursesController::class, 'markWatched']);
        Route::post('/courses/{course}/certify',      [CoursesController::class, 'certify']);
        Route::post('/courses/{course}/ai-chat',      [CoursesController::class, 'aiChat']);
    });
