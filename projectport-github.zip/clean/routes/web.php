<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| ProjectPort's API lives in routes/api.php. This route serves the single
| page client that consumes it; the framework health check (/up) is
| registered in bootstrap/app.php.
|
*/

Route::view('/', 'landing');
Route::view('/app', 'app');
