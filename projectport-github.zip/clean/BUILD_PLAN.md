# ProjectPort — Build Plan

Stack (locked): PHP 8.3 / Laravel / MySQL. Auth: `jwt_stateless`. Structure: monolith.
Every file below traces to a requirement in the Implementation Brief.

## Phase 1 — Foundation

| Item | Files | Satisfies |
|---|---|---|
| Config from env only | `.env.example`, `config/projectport.php`, `config/database.php`, `config/app.php` | Required Environment Variables |
| Error Response Contract | `app/Exceptions/ApiException.php`, `app/Support/ApiError.php`, `bootstrap/app.php` (exception renderer) | Error Response Contract |
| Data model | `app/Models/User.php`, `app/Models/Project.php`, `app/Models/Registration.php` | Data Model |
| Migrations | `database/migrations/*_create_users_table.php` (modified), `*_create_projects_table.php`, `*_create_registrations_table.php`, `*_create_refresh_tokens_table.php` | Data Model, Implementation Checklist |
| API routing | `routes/api.php`, `bootstrap/app.php` | all FRs |

Acceptance: app boots, `migrate` runs clean, forced error returns `{error,message,field?}`.

## Phase 2 — Authentication & Authorization

| Item | Files | Satisfies |
|---|---|---|
| JWT issue/verify (stateless) | `app/Services/JwtService.php` | Architecture Decision `auth_strategy=jwt_stateless` |
| Bearer auth middleware → 401 | `app/Http/Middleware/JwtAuthenticate.php` | Error Contract 401 |
| Role authorization → 403 | `app/Http/Middleware/EnsureRole.php` | Error Contract 403, FR-04/05/06 actors |
| Refresh token rotation | `app/Services/RefreshTokenService.php`, `app/Models/RefreshToken.php` | Implementation Checklist #1 |
| Token invalidation on password/email change | `users.token_version` + `App\Services\JwtService` claim check | Implementation Checklist #3 |

Acceptance: unauthenticated → 401 contract; wrong role → 403 contract.

## Phase 3 — FR-01 … FR-04

| FR | Files | Signals | Acceptance criteria covered |
|---|---|---|---|
| FR-01 Registration | `app/Http/Controllers/Api/AuthController.php` (`register_user`), `app/Http/Requests/RegisterUserRequest.php`, `app/Mail/VerifyEmailMail.php` (`verify_email`), `resources/views/emails/verify_email.blade.php` | `register_user`, `verify_email` | valid email → verification email sent; invalid/duplicate email → 400 contract with `field` |
| FR-02 Email verification | `AuthController::verify_email_address`, `app/Services/EmailVerificationService.php` | `verify_email_address` | valid token → `email_verified_at` set; invalid token → 400 contract |
| FR-03 Login | `AuthController::login_user`, `app/Http/Requests/LoginUserRequest.php` | `login_user` | valid creds → JWT issued; invalid creds → 401 contract; password min 8 → 400 |
| FR-04 Admin approval | `app/Http/Controllers/Api/AdminRegistrationController.php` (`approve_registration`, `reject_registration`) | `approve_registration`, `reject_registration` | approve → user status `active`; reject → status `inactive`; non-admin → 403 |

Tests: `tests/Feature/RegisterUserTest.php`, `VerifyEmailTest.php`, `LoginUserTest.php`, `AdminApprovalTest.php`.

## Phase 4 — FR-05, FR-06

| FR | Files | Signals | Acceptance criteria covered |
|---|---|---|---|
| FR-05 Student profile & projects | `app/Http/Controllers/Api/ProjectController.php` (`create_project`, `upload_source_code`), `app/Http/Controllers/Api/StudentProfileController.php`, `app/Http/Requests/CreateProjectRequest.php`, `app/Http/Requests/UploadSourceCodeRequest.php` | `create_project`, `upload_source_code` | valid project → appears on profile; invalid (name < 5 chars / bad file type) → 400 contract with `field` |
| FR-06 Recruiter search | `app/Http/Controllers/Api/SearchController.php` (`search_students`, `search_projects`), `app/Http/Requests/SearchRequest.php` | `search_students`, `search_projects` | valid query → matching students/projects; invalid query → 400 contract |

Tests: `tests/Feature/StudentProjectTest.php`, `tests/Feature/RecruiterSearchTest.php`.

## Phase 5 — Hardening

| NFR | Files |
|---|---|
| NFR-01 / NFR-04 indexes + pooling | migrations (composite indexes on `users(role,status)`, `projects(user_id)`, fulltext-style LIKE indexes), `config/database.php` (`PDO::ATTR_PERSISTENT`, pool env vars) |
| NFR-02 HSTS + rate limiting | `app/Http/Middleware/ForceHttps.php`, `app/Providers/AppServiceProvider.php` (RateLimiter: 10/min auth, 100/min read), 429 via contract |
| NFR-03 responsive + monitoring | `app/Http/Middleware/RequestTiming.php` (logs duration, alerts over threshold) |

Tests: `tests/Feature/ErrorContractTest.php`, `tests/Feature/RateLimitTest.php`, `tests/Feature/SecurityHeadersTest.php`, `tests/Feature/PerformanceTest.php`.

Deliverables: `DEFINITION_OF_DONE.md` (coverage report), `ASSUMPTIONS.md`.
