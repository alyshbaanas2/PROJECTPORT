<?php

namespace Database\Factories;

use App\Models\Registration;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Registration>
 */
class RegistrationFactory extends Factory
{
    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory()->student()->pending(),
            'approved' => null,
            'admin_id' => null,
            'decided_at' => null,
        ];
    }
}
