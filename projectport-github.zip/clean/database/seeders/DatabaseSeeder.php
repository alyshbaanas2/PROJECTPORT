<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * FR-04 requires at least one admin to decide registrations. Admin accounts
     * are not self-registerable, so the first one is seeded from the environment.
     */
    public function run(): void
    {
        $email = (string) env('ADMIN_EMAIL', 'admin@projectport.test');
        $password = (string) env('ADMIN_PASSWORD', '');

        if ($password === '') {
            $this->command?->warn('ADMIN_PASSWORD is not set — skipping admin seeding.');

            return;
        }

        User::updateOrCreate(
            ['email' => $email],
            [
                'password' => $password,
                'role' => User::ROLE_ADMIN,
                'status' => User::STATUS_ACTIVE,
                'name' => 'ProjectPort Admin',
                'email_verified_at' => Carbon::now(),
            ],
        );
    }
}
