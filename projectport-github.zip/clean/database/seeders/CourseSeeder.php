<?php

namespace Database\Seeders;

use App\Models\Course;
use Illuminate\Database\Seeder;

class CourseSeeder extends Seeder
{
    public function run(): void
    {
        $courses = [
            // Laravel
            ['title' => 'Laravel From Scratch', 'topic' => 'Laravel', 'description' => 'Build a full Laravel application from zero — routing, controllers, Eloquent, Blade, and more.', 'youtube_url' => 'https://www.youtube.com/watch?v=MFh0Fd7BsjE', 'sort_order' => 1],
            ['title' => 'Laravel RESTful API', 'topic' => 'Laravel', 'description' => 'Design and build a production-quality REST API with Laravel, Sanctum, and JSON resources.', 'youtube_url' => 'https://www.youtube.com/watch?v=YGqCZjdgJJk', 'sort_order' => 2],
            ['title' => 'Laravel Testing Masterclass', 'topic' => 'Laravel', 'description' => 'Feature tests, unit tests, factories, and fakes. Write tests you can trust.', 'youtube_url' => 'https://www.youtube.com/watch?v=DRhhfy2sG1E', 'sort_order' => 3],

            // PHP
            ['title' => 'PHP 8 Full Course', 'topic' => 'PHP', 'description' => 'Modern PHP 8 features: named arguments, match expressions, fibers, and null-safe operators.', 'youtube_url' => 'https://www.youtube.com/watch?v=OK_JCtrrv-c', 'sort_order' => 10],
            ['title' => 'Object-Oriented PHP', 'topic' => 'PHP', 'description' => 'Classes, interfaces, traits, abstract classes, and design patterns in PHP.', 'youtube_url' => 'https://www.youtube.com/watch?v=sNDq9KUMnCY', 'sort_order' => 11],

            // JavaScript
            ['title' => 'JavaScript Full Course', 'topic' => 'JavaScript', 'description' => 'ES6+, async/await, the event loop, DOM manipulation, and fetch API.', 'youtube_url' => 'https://www.youtube.com/watch?v=PkZNo7MFNFg', 'sort_order' => 20],
            ['title' => 'Async JavaScript Deep Dive', 'topic' => 'JavaScript', 'description' => 'Promises, async/await, error handling, and real-world async patterns.', 'youtube_url' => 'https://www.youtube.com/watch?v=ZYb_ZU8LNxs', 'sort_order' => 21],

            // React
            ['title' => 'React JS Full Course', 'topic' => 'React', 'description' => 'Hooks, state management, routing with React Router, and API integration.', 'youtube_url' => 'https://www.youtube.com/watch?v=bMknfKXIFA8', 'sort_order' => 30],

            // Python
            ['title' => 'Python for Beginners', 'topic' => 'Python', 'description' => 'Variables, data types, loops, functions, and file I/O in Python 3.', 'youtube_url' => 'https://www.youtube.com/watch?v=rfscVS0vtbw', 'sort_order' => 40],
            ['title' => 'Python Django Full Course', 'topic' => 'Python', 'description' => 'Build web applications with Django — models, views, templates, and authentication.', 'youtube_url' => 'https://www.youtube.com/watch?v=PtQiiknWUcI', 'sort_order' => 41],

            // Git & DevOps
            ['title' => 'Git & GitHub Full Course', 'topic' => 'Git', 'description' => 'Branching, merging, rebasing, pull requests, and collaborative workflows.', 'youtube_url' => 'https://www.youtube.com/watch?v=RGOj5yH7evk', 'sort_order' => 50],
            ['title' => 'Docker for Developers', 'topic' => 'DevOps', 'description' => 'Containers, images, Compose files, and deploying Laravel apps with Docker.', 'youtube_url' => 'https://www.youtube.com/watch?v=fqMOX6JJhGo', 'sort_order' => 51],

            // Databases
            ['title' => 'MySQL Full Course', 'topic' => 'Database', 'description' => 'Tables, joins, indexes, transactions, and query optimisation in MySQL.', 'youtube_url' => 'https://www.youtube.com/watch?v=7S_tz1z_5bA', 'sort_order' => 60],
        ];

        foreach ($courses as $data) {
            Course::firstOrCreate(['youtube_url' => $data['youtube_url']], $data);
        }
    }
}
