<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Data Model: Project (name, source_code, user_id) — belongs_to user.
 * FR-05 (create_project / upload_source_code), FR-06 (search_projects).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name', 191);                 // FR-05 validation: min 5 characters (191 = max utf8mb4 index length)
            $table->string('source_code', 191)->nullable(); // stored path of the uploaded archive
            $table->timestamps();

            // NFR-01 / NFR-04: profile listing (user_id + created_at) and keyword search (name).
            $table->index(['user_id', 'created_at'], 'projects_user_created_index');
            $table->index('name', 'projects_name_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
