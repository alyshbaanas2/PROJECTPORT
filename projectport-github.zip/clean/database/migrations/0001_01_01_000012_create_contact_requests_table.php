<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contact_requests', function (Blueprint $table) {
            $table->id();

            // The recruiter (or any user) who sent the request.
            $table->foreignId('sender_id')->constrained('users')->cascadeOnDelete();

            // The student being contacted.
            $table->foreignId('recipient_id')->constrained('users')->cascadeOnDelete();

            // Optional: the project the sender is interested in (purchase or hire context).
            $table->foreignId('project_id')->nullable()->constrained()->nullOnDelete();

            // hire | purchase | general
            $table->string('type')->default('hire');

            // The initial message from the recruiter.
            $table->text('message');

            // The student's reply (nullable until they respond).
            $table->text('reply')->nullable();

            // pending | read | replied | closed
            $table->string('status')->default('pending');

            $table->timestamp('read_at')->nullable();
            $table->timestamp('replied_at')->nullable();
            $table->timestamps();

            $table->index(['recipient_id', 'status']);
            $table->index(['sender_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contact_requests');
    }
};
