<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * FR-05: students can upload screenshots of their projects.
 * Screenshots are stored as a JSON array of relative public-disk paths.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            // Stored as a JSON array of relative paths on the public disk.
            // e.g. ["screenshots/1/abc.jpg", "screenshots/1/def.png"]
            $table->json('screenshots')->nullable()->after('source_code');
        });
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->dropColumn('screenshots');
        });
    }
};
