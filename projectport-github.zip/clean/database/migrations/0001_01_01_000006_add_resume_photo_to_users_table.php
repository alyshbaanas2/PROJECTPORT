<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * FR-05: students can upload a profile/resume picture.
 * The path is stored as a relative path on the public disk.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Relative path on the public disk.
            // e.g. "resume_photos/42/abc123.jpg"
            $table->string('resume_photo', 191)->nullable()->after('skills');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('resume_photo');
        });
    }
};
