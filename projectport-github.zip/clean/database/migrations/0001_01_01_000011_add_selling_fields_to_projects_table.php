<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->boolean('for_sale')->default(false)->after('screenshots');
            $table->decimal('price', 10, 2)->nullable()->after('for_sale');
            $table->text('sale_description')->nullable()->after('price');
        });
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->dropColumn(['for_sale', 'price', 'sale_description']);
        });
    }
};
