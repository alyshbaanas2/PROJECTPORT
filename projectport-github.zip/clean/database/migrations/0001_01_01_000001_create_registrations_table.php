<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Data Model: Registration (user_id, approved) — belongs_to user, belongs_to admin.
 * FR-01 (created on registration), FR-04 (admin approves / rejects).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('registrations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            // null = still pending an admin decision, true = approved, false = rejected.
            $table->boolean('approved')->nullable();
            $table->foreignId('admin_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('decided_at')->nullable();
            $table->timestamps();

            // NFR-01 / NFR-04: admin queues filter on approval state.
            $table->index(['approved', 'created_at'], 'registrations_approved_created_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('registrations');
    }
};
