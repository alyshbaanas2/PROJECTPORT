<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Data Model: User (email, password, role).
 * FR-01, FR-02, FR-03, FR-04, FR-05, FR-06.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('email', 191)->unique();           // FR-01 validation: unique (191 = max utf8mb4 index length)
            $table->string('password');                      // FR-03
            $table->string('role', 20);                       // admin | student | recruiter
            $table->string('status', 20)->default('pending'); // FR-04: pending | active | inactive

            // FR-05: student profile fields exposed through the profile endpoints.
            $table->string('name', 191)->nullable();
            $table->text('skills')->nullable();               // FR-06: searchable skills

            // FR-02: email verification.
            $table->timestamp('email_verified_at')->nullable();
            $table->string('email_verification_token', 191)->nullable()->index();
            $table->timestamp('email_verification_expires_at')->nullable();

            // Implementation Checklist: invalidate issued JWTs on password / email change.
            $table->unsignedInteger('token_version')->default(0);

            $table->timestamps();

            // NFR-01 / NFR-04: composite index for the multi-column WHERE clauses used
            // by recruiter search (role + status) and admin listings.
            $table->index(['role', 'status'], 'users_role_status_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
