# ProjectPort

A PHP / Laravel monolith on MySQL where students publish projects and source code, admins approve
registrations, and recruiters search for students and their work.

Built to the ProjectPort Implementation Brief. See [BUILD_PLAN.md](BUILD_PLAN.md),
[DEFINITION_OF_DONE.md](DEFINITION_OF_DONE.md) and [ASSUMPTIONS.md](ASSUMPTIONS.md).

## Requirements

- PHP 8.3+ with `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `zip`
- Composer
- MySQL 8

## Setup

```bash
composer install
cp .env.example .env
php artisan key:generate

# Required environment variables
#   PORT, NODE_ENV, JWT_SECRET, JWT_EXPIRE_MINUTES, DATABASE_URL
# Generate a 32-byte JWT secret:
php -r "echo bin2hex(random_bytes(32));"

php artisan migrate
ADMIN_PASSWORD=... php artisan db:seed   # creates the admin that approves registrations (FR-04)

php artisan serve --port=$PORT
```

## Web client

`GET /` serves a single page client ([resources/views/app.blade.php](resources/views/app.blade.php),
[public/assets/app.js](public/assets/app.js), [public/assets/app.css](public/assets/app.css)) that
consumes the API below. It has no build step and no external dependencies — Laravel serves it as-is.
It covers both journeys end to end: sign up → verify → sign in, the student profile and project
uploads, recruiter search with a student profile sheet, in-browser archive previews with downloads, and an admin console with review stats, a
filterable/searchable registration queue and per-row approve/reject with confirmation. It stores the JWT in `localStorage`,
sends it in the `Authorization` header, and rotates the refresh token automatically on expiry.

The client was added after the original API build, at request; see Assumption 24.

## Tests

```bash
php artisan test
```

## API

Authentication is stateless JWT. Send `Authorization: Bearer <access_token>`.

| Method | Route | Role | Requirement |
|---|---|---|---|
| POST | `/api/auth/register` | public | FR-01 |
| GET | `/api/auth/verify-email/{token}` | public | FR-02 |
| POST | `/api/auth/verify-email/resend` | public | FR-01 / FR-02 |
| POST | `/api/auth/login` | public | FR-03 |
| POST | `/api/auth/refresh` | public (refresh token) | Refresh token rotation |
| POST | `/api/auth/logout` | any | Session revocation |
| PATCH | `/api/me/credentials` | any | Password / email change + token invalidation |
| GET | `/api/admin/registrations?state=&q=` | admin | FR-04 |
| POST | `/api/admin/registrations/{id}/approve` | admin | FR-04 |
| POST | `/api/admin/registrations/{id}/reject` | admin | FR-04 |
| GET | `/api/students/me/profile` | student | FR-05 |
| PATCH | `/api/students/me/profile` | student | FR-05 |
| POST | `/api/students/me/projects` | student | FR-05 |
| GET | `/api/students/{id}` | recruiter, admin, student | FR-05 / FR-06 |
| GET | `/api/projects/{id}/source-code` | recruiter, admin, owner | FR-05 / FR-06 |
| GET | `/api/projects/{id}/source-code/contents` | recruiter, admin, owner | FR-05 / FR-06 |
| GET | `/api/search/students?q=` | recruiter | FR-06 |
| GET | `/api/search/projects?q=` | recruiter | FR-06 |

### Errors

Every error response uses one shape:

```json
{"error": "SNAKE_CASE_CODE", "message": "human readable", "field": "optional field name"}
```

Statuses in use: 400 validation, 401 missing/expired JWT, 403 not authorised, 404 not found,
409 conflict, 422 business rule violation, 429 rate limited, 500 unexpected (never leaks traces).

### Rate limits (NFR-02)

10 requests/minute per IP on auth endpoints, 100 requests/minute on read endpoints.
