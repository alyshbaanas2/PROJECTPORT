<?php

/*
|--------------------------------------------------------------------------
| ProjectPort application configuration
|--------------------------------------------------------------------------
|
| Every value here is loaded from the Required Environment Variables. No
| runtime value in the application is hardcoded.
|
*/

return [

    // Port the HTTP server binds to (PORT).
    'port' => (int) env('PORT', 3000),

    // Deployment mode (NODE_ENV) — mirrored onto the framework environment.
    'node_env' => env('NODE_ENV', 'production'),

    'jwt' => [
        // Signing key for stateless JWT auth (JWT_SECRET).
        'secret' => env('JWT_SECRET'),

        // Access token lifetime in minutes (JWT_EXPIRE_MINUTES).
        'expire_minutes' => (int) env('JWT_EXPIRE_MINUTES', 60),

        'algorithm' => 'HS256',

        // Refresh token lifetime in days (Implementation Checklist: refresh token rotation).
        'refresh_expire_days' => (int) env('JWT_REFRESH_EXPIRE_DAYS', 30),
    ],

    // FR-02: how long an email verification token stays usable.
    'email_verification' => [
        'token_ttl_minutes' => (int) env('EMAIL_VERIFICATION_TTL_MINUTES', 1440),
    ],

    // FR-05: source code upload constraints (validation rule: valid file type).
    'source_code' => [
        'allowed_extensions' => ['zip', 'tar', 'gz', 'tgz', 'rar', '7z'],
        'max_kilobytes' => (int) env('SOURCE_CODE_MAX_KB', 51200),
        'disk' => env('SOURCE_CODE_DISK', 'local'),
        'directory' => 'source_code',
    ],

    // FR-05: project screenshot upload constraints.
    'screenshots' => [
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'max_kilobytes' => (int) env('SCREENSHOT_MAX_KB', 5120),   // 5 MB per image
        'max_count' => (int) env('SCREENSHOT_MAX_COUNT', 5),        // up to 5 per project
        'disk' => env('SCREENSHOT_DISK', 'public'),
        'directory' => 'screenshots',
    ],

    // FR-05: student resume/profile picture upload constraints.
    'resume_photo' => [
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'webp'],
        'max_kilobytes' => (int) env('RESUME_PHOTO_MAX_KB', 2048),  // 2 MB
        'disk' => env('RESUME_PHOTO_DISK', 'public'),
        'directory' => 'resume_photos',
    ],

    // NFR-01/NFR-03: request duration budget in milliseconds; breaches are logged for alerting.
    'performance' => [
        'response_budget_ms' => (int) env('RESPONSE_BUDGET_MS', 2000),
        'query_budget_ms' => (int) env('QUERY_BUDGET_MS', 100),
    ],

    // NFR-02: HTTPS enforcement.
    'security' => [
        'force_https' => (bool) env('FORCE_HTTPS', true),
        'hsts_max_age' => (int) env('HSTS_MAX_AGE', 31536000),
    ],

    // NFR-02: rate limits.
    'rate_limits' => [
        'auth_per_minute' => (int) env('RATE_LIMIT_AUTH', 10),
        'read_per_minute' => (int) env('RATE_LIMIT_READ', 100),
    ],
];
